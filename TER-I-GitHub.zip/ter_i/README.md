# TER I

**TenIII Generation 3 Inference Runtime companion**

`ter-i` is the installable metadata and CLI companion for the TER I model/runtime line. It is intentionally not a general-purpose deep-learning library. The multimodal inference engine, provider catalog and local gateways live in the TER I application distribution.

## Install

```bash
pip install ter-i
```

## Inspect the runtime contract

```bash
ter-i model-card
ter-i version
```

The package does not contain model weights or shared credentials. Operators provide a model descriptor produced by TenMiNaTor III / TenMiNaTor III-II and configure their own local endpoints or provider accounts in TER I.

## Model identity

| Field | Value |
|---|---|
| Name | TER I |
| Generation | tenIII-generation-3 |
| Kind | inference-runtime |
| Version | 3.1.0 |
| General-purpose library | No |

The source project and web application are distributed separately as `TER-I-GitHub.zip`. See the project documentation for local deployment, encrypted user providers and channel setup.
