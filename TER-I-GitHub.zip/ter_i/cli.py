"""Command-line entry point for the TER I runtime companion."""

from __future__ import annotations

import argparse
import json

from . import model_card


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="ter-i",
        description="TER I — TenIII Generation 3 inference runtime companion",
    )
    parser.add_argument(
        "command",
        nargs="?",
        choices=("model-card", "version"),
        default="model-card",
        help="metadata command to print",
    )
    args = parser.parse_args(argv)
    card = model_card()
    if args.command == "version":
        print(card["version"])
    else:
        print(json.dumps(card, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
