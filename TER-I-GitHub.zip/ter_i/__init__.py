"""TER I — TenIII Generation 3 Inference Runtime companion package.

This package contains distribution metadata and a small local CLI companion.
The multimodal inference engine remains in the TER I web/runtime application.
"""

__title__ = "TER I"
__version__ = "3.1.0"
__description__ = "TenIII Generation 3 inference runtime companion"
__author__ = "TER I contributors"


def model_card() -> dict[str, str]:
    """Return stable metadata for tools that inspect the TER I runtime."""
    return {
        "name": __title__,
        "version": __version__,
        "generation": "tenIII-generation-3",
        "kind": "inference-runtime",
        "library": "false",
    }
