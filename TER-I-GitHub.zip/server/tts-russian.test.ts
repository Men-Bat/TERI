/**
 * Tests para validar soporte de Ruso en Kokoro, Coqui y Silero
 * Archivo: server/tts-russian.test.ts
 * Propósito: Verificar que Ruso (ru) funciona correctamente en todos los backends
 */

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import {
  synthesizeSpeech,
  kokoroTTS,
  coquiTTS,
  sileroTTS,
} from "./terminator/tts";
import type { TTSConfig } from "./terminator/tts";

describe("Russian (ru) Language Support in TTS", () => {
  beforeEach(() => {
    // Mock fetch globalmente
    global.fetch = vi.fn();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe("Kokoro Russian Support", () => {
    it("should NOT support Russian in Kokoro (ru not in KOKORO_LANGS)", async () => {
      // Kokoro solo soporta 11 idiomas: en, de, es, fr, hi, it, ja, ko, pt, zh
      // Ruso NO está incluido
      const config: TTSConfig = {
        preferredTts: "kokoro",
        kokoroUrl: "http://localhost:8880",
      };

      // Intentar sintetizar en ruso con Kokoro debería fallar o saltarse
      const result = await synthesizeSpeech(
        "Привет, мир!",
        config,
        "default",
        "ru"
      );

      // Debería ser null porque Kokoro no soporta ruso
      expect(result).toBeNull();
    });

    it("should fallback to Coqui when Russian is requested with auto mode", async () => {
      (global.fetch as any) = vi.fn(async (url: any) => {
        // Mock Coqui response
        const urlStr = typeof url === "string" ? url : url.toString();
        if (urlStr.includes("5002")) {
          const audioBuffer = Buffer.from("fake-coqui-audio");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        return { ok: true, status: 200, json: async () => ({ url: "data:audio/mp3;base64,fake" }), headers: { get: () => null } } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      // Con "auto", debería saltarse Kokoro y usar Coqui
      const result = await synthesizeSpeech(
        "Привет, мир!",
        config,
        "default",
        "ru"
      );

      // Debería usar Coqui
      expect(result).toBeTruthy();
      expect(result?.backend).toBe("coqui");
    });
  });

  describe("Coqui Russian Support", () => {
    it("should support Russian (ru) in Coqui XTTS", async () => {
      (global.fetch as any) = vi.fn(async (url: any) => {
        const urlStr = typeof url === "string" ? url : url.toString();
        if (urlStr.includes("5002")) {
          const audioBuffer = Buffer.from("fake-coqui-russian-audio");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        return { ok: true, status: 200, json: async () => ({ url: "data:audio/mp3;base64,fake" }), headers: { get: () => null } } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech(
        "Привет, мир!",
        config,
        "default",
        "ru"
      );

      expect(result).toBeTruthy();
      expect(result?.backend).toBe("coqui");
      expect(result?.url).toContain("data:");
    });

    it("should handle Russian text with Coqui", async () => {
      (global.fetch as any) = vi.fn(async (url: any) => {
        const urlStr = typeof url === "string" ? url : url.toString();
        if (urlStr.includes("5002")) {
          // Verificar que el request contiene texto ruso
          const audioBuffer = Buffer.from("fake-coqui-russian-audio");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        return { ok: true, status: 200, json: async () => ({ url: "data:audio/mp3;base64,fake" }), headers: { get: () => null } } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      const russianTexts = [
        "Привет",
        "Добро пожаловать",
        "Как дела?",
        "Спасибо",
      ];

      for (const text of russianTexts) {
        const result = await synthesizeSpeech(text, config, "default", "ru");
        expect(result).toBeTruthy();
        expect(result?.backend).toBe("coqui");
      }
    });

    it("should validate language code normalization for Russian", async () => {
      (global.fetch as any) = vi.fn(async (url: any) => {
        const urlStr = typeof url === "string" ? url : url.toString();
        if (urlStr.includes("5002")) {
          const audioBuffer = Buffer.from("fake-coqui-audio");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        return { ok: true, status: 200, json: async () => ({ url: "data:audio/mp3;base64,fake" }), headers: { get: () => null } } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      // Test with different Russian language codes
      const russianCodes = ["ru", "ru-RU", "ru-UA"];

      for (const langCode of russianCodes) {
        const result = await synthesizeSpeech(
          "Привет",
          config,
          "default",
          langCode
        );
        expect(result).toBeTruthy();
        expect(result?.backend).toBe("coqui");
      }
    });
  });

  describe("Silero Russian Support", () => {
    it("should support Russian (ru) in Silero TTS", async () => {
      (global.fetch as any) = vi.fn(async (url: any) => {
        const urlStr = typeof url === "string" ? url : url.toString();
        if (urlStr.includes("5003")) {
          const audioBuffer = Buffer.from("fake-silero-russian-audio");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        return { ok: true, status: 200, json: async () => ({ url: "data:audio/mp3;base64,fake" }), headers: { get: () => null } } as any;
      });

      const config: TTSConfig = {
        preferredTts: "silero",
        sileroUrl: "http://localhost:5003",
      };

      const result = await synthesizeSpeech(
        "Привет, мир!",
        config,
        "default",
        "ru"
      );

      expect(result).toBeTruthy();
      expect(result?.backend).toBe("silero");
      expect(result?.url).toContain("data:");
    });

    it("should handle Russian text with Silero", async () => {
      (global.fetch as any) = vi.fn(async (url: any) => {
        const urlStr = typeof url === "string" ? url : url.toString();
        if (urlStr.includes("5003")) {
          const audioBuffer = Buffer.from("fake-silero-russian-audio");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        return { ok: true, status: 200, json: async () => ({ url: "data:audio/mp3;base64,fake" }), headers: { get: () => null } } as any;
      });

      const config: TTSConfig = {
        preferredTts: "silero",
        sileroUrl: "http://localhost:5003",
      };

      const russianTexts = [
        "Привет",
        "Добро пожаловать",
        "Как дела?",
        "Спасибо",
      ];

      for (const text of russianTexts) {
        const result = await synthesizeSpeech(text, config, "default", "ru");
        expect(result).toBeTruthy();
        expect(result?.backend).toBe("silero");
      }
    });
  });

  describe("Russian Fallback Chain", () => {
    it("should use Coqui as first fallback when Kokoro fails for Russian", async () => {
      (global.fetch as any) = vi.fn(async (url: any) => {
        // Kokoro fails, Coqui succeeds
        const urlStr = typeof url === "string" ? url : url.toString();
        if (urlStr.includes("8880")) {
          throw new Error("Kokoro unavailable");
        }
        if (urlStr.includes("5002")) {
          const audioBuffer = Buffer.from("fake-coqui-audio");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        // Handle storagePut call
        if (urlStr.includes("s3") || urlStr.includes("storage")) {
          return {
            ok: true,
            status: 200,
            json: async () => ({ url: "data:audio/mp3;base64,fake" }),
            headers: { get: () => null },
          } as any;
        }
        throw new Error("Not mocked: " + urlStr);
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech(
        "Привет",
        config,
        "default",
        "ru"
      );

      expect(result).toBeTruthy();
      expect(result?.backend).toBe("coqui");
    });

    it("should use Silero as second fallback when Coqui fails for Russian", async () => {
      (global.fetch as any) = vi.fn(async (url: any) => {
        // Kokoro and Coqui fail, Silero succeeds
        const urlStr = typeof url === "string" ? url : url.toString();
        if (urlStr.includes("8880") || urlStr.includes("5002")) {
          throw new Error("Service unavailable");
        }
        if (urlStr.includes("5003")) {
          const audioBuffer = Buffer.from("fake-silero-audio");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        // Handle storagePut call
        if (urlStr.includes("s3") || urlStr.includes("storage")) {
          return {
            ok: true,
            status: 200,
            json: async () => ({ url: "data:audio/mp3;base64,fake" }),
            headers: { get: () => null },
          } as any;
        }
        throw new Error("Not mocked: " + urlStr);
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
        sileroUrl: "http://localhost:5003",
      };

      const result = await synthesizeSpeech(
        "Привет",
        config,
        "default",
        "ru"
      );

      expect(result).toBeTruthy();
      expect(result?.backend).toBe("silero");
    });
  });

  describe("Russian Language Validation", () => {
    it("should validate that Russian is in Coqui supported languages", async () => {
      // Verificar que 'ru' está en la lista de idiomas soportados por Coqui
      const coquiSupportedLangs = [
        "ar",
        "de",
        "en",
        "es",
        "fr",
        "hu",
        "it",
        "ja",
        "ko",
        "nl",
        "pl",
        "pt",
        "ru",
        "tr",
        "uk",
        "zh",
      ];
      expect(coquiSupportedLangs).toContain("ru");
    });

    it("should validate that Russian is in Silero supported languages", async () => {
      // Verificar que 'ru' está en la lista de idiomas soportados por Silero
      const sileroSupportedLangs = ["en", "de", "es", "fr", "ru", "uk", "hi"];
      expect(sileroSupportedLangs).toContain("ru");
    });

    it("should validate that Russian is NOT in Kokoro supported languages", async () => {
      // Verificar que 'ru' NO está en la lista de idiomas soportados por Kokoro
      const kokoroSupportedLangs = [
        "en",
        "de",
        "es",
        "fr",
        "hi",
        "it",
        "ja",
        "ko",
        "pt",
        "zh",
      ];
      expect(kokoroSupportedLangs).not.toContain("ru");
    });
  });

  describe("Russian Error Handling", () => {
    it("should return null when all backends fail for Russian", async () => {
      (global.fetch as any) = vi.fn(async () => {
        throw new Error("All services unavailable");
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
        sileroUrl: "http://localhost:5003",
      };

      const result = await synthesizeSpeech(
        "Привет",
        config,
        "default",
        "ru"
      );

      expect(result).toBeNull();
    });

    it("should handle empty Russian text gracefully", async () => {
      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("", config, "default", "ru");
      expect(result).toBeNull();
    });

    it("should handle whitespace-only Russian text gracefully", async () => {
      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("   ", config, "default", "ru");
      expect(result).toBeNull();
    });
  });
});
