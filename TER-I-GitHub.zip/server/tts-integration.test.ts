/**
 * TTS Integration Tests — Kokoro, Coqui, Silero, SSE Streaming
 * 
 * Tests de integración para verificar que los backends TTS funcionan correctamente
 * sin perder funcionalidades existentes.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import {
  synthesizeSpeech,
  getKokoroModels,
  getKokoroVoices,
  isKokoroLocalUrl,
  KokoroTTSOptions,
} from "../server/terminator/tts";
import type { TTSConfig } from "../server/terminator/tts";

// ─── Mock de storage.ts ──────────────────────────────────────────────────────

vi.mock("../server/storage.ts", () => ({
  storagePut: vi.fn(async (key: string, data: Buffer, mimeType: string) => {
    // Simular S3 upload
    const base64 = data.toString("base64");
    return {
      key,
      url: `data:${mimeType};base64,${base64}`,
    };
  }),
}));

// ─── Tests ──────────────────────────────────────────────────────────────────

describe("TTS Integration Tests", () => {
  let originalFetch: typeof global.fetch;

  beforeEach(() => {
    originalFetch = global.fetch;
  });

  afterEach(() => {
    global.fetch = originalFetch;
    vi.clearAllMocks();
  });

  // ─── Kokoro Tests ───────────────────────────────────────────────────────────

  describe("Kokoro TTS", () => {
    it("should synthesize Spanish with Kokoro", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("Hola mundo", config, "default", "es");
      expect(result).toBeTruthy();
      // Spanish is supported by Kokoro, so it should use Kokoro
      expect(result?.backend).toBe("kokoro");
      expect(result?.url).toContain("data:");
    });

    it("should apply volume_multiplier (0.1 to 2.0)", async () => {
      let requestBody: any;
      global.fetch = vi.fn(async (url: any, options: any) => {
        if (typeof url === "string" && url.includes("8880")) {
          requestBody = JSON.parse(options.body as string);
        }
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      // Test volume 0.5
      await synthesizeSpeech("Test", config, "default", "es", {
        volumeMultiplier: 0.5,
      });

      expect(requestBody.volume_multiplier).toBe(0.5);

      // Test clamping: 3.0 → 2.0
      await synthesizeSpeech("Test", config, "default", "es", {
        volumeMultiplier: 3.0,
      });

      expect(requestBody.volume_multiplier).toBe(2.0);

      // Test clamping: 0.05 → 0.1
      await synthesizeSpeech("Test", config, "default", "es", {
        volumeMultiplier: 0.05,
      });

      expect(requestBody.volume_multiplier).toBe(0.1);
    });

    it("should support SSE streaming format", async () => {
      let requestBody: any;
      global.fetch = vi.fn(async (url: any, options: any) => {
        if (typeof url === "string" && url.includes("8880")) {
          requestBody = JSON.parse(options.body as string);
        }
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      await synthesizeSpeech("Test", config, "default", "es", {
        useStreaming: true,
      });

      expect(requestBody.stream_format).toBe("sse");
    });

    it("should send a configured Kokoro bearer token", async () => {
      let requestHeaders: Record<string, string> | undefined;
      global.fetch = vi.fn(async (_url: any, options: any) => {
        requestHeaders = options.headers;
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      await synthesizeSpeech("Token test", {
        preferredTts: "kokoro",
        kokoroUrl: "http://localhost:8880",
        kokoroApiKey: "kokoro-secret",
      }, "default", "es");

      expect(requestHeaders?.Authorization).toBe("Bearer kokoro-secret");
    });

    it("should block remote Kokoro endpoints when local-only mode is active", async () => {
      const fetchSpy = vi.fn();
      global.fetch = fetchSpy as any;

      const result = await synthesizeSpeech("Local only", {
        preferredTts: "kokoro",
        kokoroUrl: "https://kokoro.example.test",
        kokoroLocalOnly: true,
      }, "default", "es");

      expect(result).toBeNull();
      expect(fetchSpy).not.toHaveBeenCalled();
      expect(isKokoroLocalUrl("http://localhost:8880")).toBe(true);
      expect(isKokoroLocalUrl("https://kokoro.example.test")).toBe(false);
    });

    it("should retrieve Kokoro voices and models with a bearer token", async () => {
      const calls: Array<{ url: string; headers: Record<string, string> }> = [];
      global.fetch = vi.fn(async (url: string, options: any) => {
        calls.push({ url, headers: options.headers });
        return {
          ok: true,
          status: 200,
          json: async () => url.endsWith("/voices")
            ? { data: [{ id: "em_alex" }] }
            : { data: [{ id: "kokoro" }] },
        } as any;
      });

      await expect(getKokoroVoices("http://localhost:8880/", "metadata-secret"))
        .resolves.toEqual({ data: [{ id: "em_alex" }] });
      await expect(getKokoroModels("http://localhost:8880", "metadata-secret"))
        .resolves.toEqual({ data: [{ id: "kokoro" }] });
      expect(calls).toEqual([
        { url: "http://localhost:8880/v1/voices", headers: { Accept: "application/json", Authorization: "Bearer metadata-secret" } },
        { url: "http://localhost:8880/v1/models", headers: { Accept: "application/json", Authorization: "Bearer metadata-secret" } },
      ]);
    });

    it("should fall back to the upstream /v1/audio/voices endpoint", async () => {
      const calls: string[] = [];
      global.fetch = vi.fn(async (url: string) => {
        calls.push(url);
        if (url.endsWith("/v1/voices")) {
          return { ok: false, status: 404, json: async () => ({}) } as any;
        }
        return { ok: true, status: 200, json: async () => ({ voices: [{ id: "af_bella" }] }) } as any;
      });

      await expect(getKokoroVoices("http://localhost:8880"))
        .resolves.toEqual({ voices: [{ id: "af_bella" }] });
      expect(calls).toEqual([
        "http://localhost:8880/v1/voices",
        "http://localhost:8880/v1/audio/voices",
      ]);
    });

    it("should support 11 Kokoro languages", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      const languages = ["en", "de", "es", "fr", "hi", "it", "ja", "ko", "pt", "zh"];

      for (const lang of languages) {
        const result = await synthesizeSpeech("Test", config, "default", lang);
        expect(result?.backend).toBe("kokoro");
      }
    });
  });

  // ─── Coqui Tests ────────────────────────────────────────────────────────────

  describe("Coqui XTTS", () => {
    it("should synthesize Arabic with Coqui", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("مرحبا", config, "default", "ar");
      expect(result).toBeTruthy();
      expect(result?.backend).toBe("coqui");
      expect(result?.backend).toBe("coqui");
    });

    it("should support 17 Coqui languages including Arabic and Russian", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      const languages = [
        "ar", // Arabic
        "de",
        "en",
        "es",
        "fr",
        "hu",
        "it",
        "ja",
        "ko",
        "nl",
        "pl",
        "pt",
        "ru", // Russian
        "tr",
        "uk",
        "zh",
      ];

      for (const lang of languages) {
        const result = await synthesizeSpeech("Test", config, "default", lang);
        expect(result?.backend).toBe("coqui");
      }
    });
  });

  // ─── Silero Tests ───────────────────────────────────────────────────────────

  describe("Silero TTS", () => {
    it("should synthesize Russian with Silero", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "silero",
        sileroUrl: "http://localhost:5003",
      };

      const result = await synthesizeSpeech("Привет", config, "default", "ru");
      expect(result).toBeTruthy();
      expect(result?.backend).toBe("silero");
    });

    it("should support 7 Silero languages", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "silero",
        sileroUrl: "http://localhost:5003",
      };

      const languages = ["en", "de", "es", "fr", "ru", "uk", "hi"];

      for (const lang of languages) {
        const result = await synthesizeSpeech("Test", config, "default", lang);
        expect(result?.backend).toBe("silero");
      }
    });
  });

  // ─── Fallback Chain Tests ────────────────────────────────────────────────────

  describe("Fallback Chain", () => {
    it("should fallback from Kokoro → Coqui when Kokoro unavailable", async () => {
      let callCount = 0;

      global.fetch = vi.fn(async (url: any) => {
        callCount++;

        // Kokoro fails
        if (typeof url === "string" && url.includes("8880")) {
          return {
            ok: false,
            status: 503,
            text: async () => "Service unavailable",
            headers: { get: () => null },
          } as any;
        }

        // Coqui succeeds
        if (typeof url === "string" && url.includes("5002")) {
          const audioBuffer = Buffer.from("fake-audio-data");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }

        throw new Error("Unexpected URL");
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("Test", config, "default", "ar");
      expect(result?.backend).toBe("coqui");
      expect(callCount).toBeGreaterThan(0);
    });

    it("should skip backends that are not configured", async () => {
      global.fetch = vi.fn(async (url: any) => {
        // Only Coqui is configured
        if (typeof url === "string" && url.includes("5002")) {
          const audioBuffer = Buffer.from("fake-audio-data");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        throw new Error("Unexpected URL");
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        coquiUrl: "http://localhost:5002",
        // kokoroUrl and sileroUrl are not set
      };

      const result = await synthesizeSpeech("Test", config, "default", "ar");
      expect(result?.backend).toBe("coqui");
    });
  });

  // ─── Edge Cases ─────────────────────────────────────────────────────────────

  describe("Edge Cases", () => {
    it("should handle empty text", async () => {
      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("", config, "default", "es");
      expect(result).toBeNull();
    });

    it("should handle whitespace-only text", async () => {
      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      // Whitespace-only text should return null
      const result = await synthesizeSpeech("   ", config, "default", "es");
      expect(result).toBeNull();
    });

    it("should handle network timeout", async () => {
      global.fetch = vi.fn(async () => {
        throw new Error("Network timeout");
      });

      const config: TTSConfig = {
        preferredTts: "kokoro",
        kokoroUrl: "http://localhost:8880",
      };

      const result = await synthesizeSpeech("Test", config, "default", "es");
      expect(result).toBeNull();
    });
  });

  // ─── Configuration Tests ────────────────────────────────────────────────────

  describe("Configuration", () => {
    it("should use default URLs when not provided", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        // kokoroUrl not provided, should use default
      };

      // Spanish is supported by Kokoro, so it should use Kokoro with default URL
      const result = await synthesizeSpeech("Test", config, "default", "es");
      expect(result).toBeTruthy();
      expect(result?.backend).toBe("kokoro");
    });

    it("should respect preferred TTS backend", async () => {
      global.fetch = vi.fn(async (url: any) => {
        // Only respond to Coqui
        if (typeof url === "string" && url.includes("5002")) {
          const audioBuffer = Buffer.from("fake-audio-data");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        return {
          ok: false,
          status: 503,
          text: async () => "Not available",
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("Test", config, "default", "es");
      expect(result?.backend).toBe("coqui");
    });
  });

  // ─── Language Support Tests ─────────────────────────────────────────────────

  describe("Language Support", () => {
    it("should handle all supported languages", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      const supportedLanguages = [
        "ar", "de", "en", "es", "fr", "hu", "it", "ja", "ko", "nl", "pl", "pt", "ru", "tr", "uk", "zh",
      ];

      for (const lang of supportedLanguages) {
        const result = await synthesizeSpeech("Test", config, "default", lang);
        expect(result).toBeTruthy();
      expect(result?.backend).toBe("coqui");
      }
    });

    it("should fallback gracefully for unsupported language", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      // Russian is not supported by Kokoro, should fallback to Coqui
      const result = await synthesizeSpeech("Test", config, "default", "ru");
      expect(result).toBeTruthy();
      expect(result?.backend).toBe("coqui");
    });
  });
});
