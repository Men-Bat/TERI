import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = resolve(import.meta.dirname, "..");
const composePath = resolve(projectRoot, "deploy/docker-compose.kokoro.yml");
const readmePath = resolve(projectRoot, "deploy/README_KOKORO_LOCAL.md");
const documentationIndexPath = resolve(projectRoot, "docs/INDEX.md");

describe("artefactos de despliegue Kokoro", () => {
  it("mantiene perfiles separados CPU y CUDA con descarga de pesos desactivada", () => {
    const compose = readFileSync(composePath, "utf8");
    expect(compose).toContain("kokoro-cpu:");
    expect(compose).toContain('profiles: ["cpu"]');
    expect(compose).toContain("kokoro-cuda:");
    expect(compose).toContain('profiles: ["cuda"]');
    expect(compose).toContain("gpus: all");
    expect((compose.match(/DOWNLOAD_MODEL: "false"/g) ?? [])).toHaveLength(2);
  });

  it("documenta que CUDA es opcional y que los otros gateways requieren wrappers propios", () => {
    const readme = readFileSync(readmePath, "utf8");
    expect(readme).toContain("NVIDIA Container Toolkit");
    expect(readme).toContain("Coqui XTTS, Silero ni Moshi");
    expect(readme).toContain("no intentan descargar pesos");
  });

  it("incluye un índice operativo para despliegue y proveedores de usuario", () => {
    const index = readFileSync(documentationIndexPath, "utf8");
    expect(index).toContain("Guía de despliegue local y API");
    expect(index).toContain("Auditoría local-first de proveedores");
    expect(index).toContain("PROVIDER_ENCRYPTION_KEY");
  });
});
