import { spawn, ChildProcess } from "child_process";
import * as path from "path";
import * as fs from "fs";

interface TrainingProcess {
  process: ChildProcess;
  sessionId: number;
  status: "running" | "paused" | "stopped";
}

class TrainingManager {
  private processes: Map<number, TrainingProcess> = new Map();

  async startTraining(
    sessionId: number,
    dataFilePath: string,
    config: unknown
  ): Promise<void> {
    if (this.processes.has(sessionId)) {
      // Idempotent: already running
      return;
    }

    const scriptPath = path.join("/tmp", `training_${sessionId}.py`);
    const trainingScript = this.generateTrainingScript(dataFilePath, config, sessionId);

    try {
      fs.writeFileSync(scriptPath, trainingScript, { mode: 0o600 });
    } catch (err) {
      throw new Error(`No se pudo escribir el script de entrenamiento: ${(err as Error).message}`);
    }

    const libPath = "/home/ubuntu/tenminator-web/tenminator_lib";
    const pythonProcess = spawn("python3.11", [scriptPath], {
      cwd: fs.existsSync(libPath) ? libPath : "/tmp",
      env: { ...process.env, PYTHONPATH: libPath },
      stdio: ["ignore", "pipe", "pipe"],
    });

    // Detect immediate spawn failure
    await new Promise<void>((resolve, reject) => {
      let started = false;

      pythonProcess.on("spawn", () => {
        started = true;
        resolve();
      });

      pythonProcess.on("error", (err) => {
        if (!started) reject(new Error(`No se pudo iniciar Python: ${err.message}`));
      });

      // Give it 2 s to spawn
      setTimeout(() => {
        if (!started) reject(new Error("Timeout al iniciar el proceso Python"));
      }, 2000);
    });

    this.processes.set(sessionId, {
      process: pythonProcess,
      sessionId,
      status: "running",
    });

    pythonProcess.stdout?.on("data", (data: Buffer) => {
      const line = data.toString().trim();
      if (line) console.log(`[Training ${sessionId}] ${line}`);
    });

    pythonProcess.stderr?.on("data", (data: Buffer) => {
      const line = data.toString().trim();
      if (line) console.error(`[Training ${sessionId} ERR] ${line}`);
    });

    pythonProcess.on("close", (code) => {
      console.log(`[Training ${sessionId}] exited with code ${code}`);
      this.processes.delete(sessionId);
      // Clean up temp script
      try { fs.unlinkSync(scriptPath); } catch { /* ignore */ }
    });
  }

  pauseTraining(sessionId: number): void {
    const training = this.processes.get(sessionId);
    if (!training || training.status !== "running") return;

    // SIGSTOP is Unix-only; on Windows we just mark it paused
    try {
      training.process.kill("SIGSTOP");
    } catch {
      // Ignore on platforms that don't support SIGSTOP
    }
    training.status = "paused";
  }

  resumeTraining(sessionId: number): void {
    const training = this.processes.get(sessionId);
    if (!training || training.status !== "paused") return;

    try {
      training.process.kill("SIGCONT");
    } catch {
      // Ignore on platforms that don't support SIGCONT
    }
    training.status = "running";
  }

  stopTraining(sessionId: number): void {
    const training = this.processes.get(sessionId);
    if (!training) return;

    // Try graceful shutdown first, then force-kill
    try {
      training.process.kill("SIGTERM");
    } catch {
      try { training.process.kill("SIGKILL"); } catch { /* ignore */ }
    }
    training.status = "stopped";
    this.processes.delete(sessionId);
  }

  getStatus(sessionId: number): string {
    const training = this.processes.get(sessionId);
    return training ? training.status : "not_found";
  }

  /** Gracefully stop all running processes on server shutdown. */
  shutdown(): void {
    Array.from(this.processes.keys()).forEach((id) => this.stopTraining(id));
  }

  private generateTrainingScript(
    dataFilePath: string,
    config: unknown,
    sessionId: number
  ): string {
    const cfg = (config ?? {}) as Record<string, number>;
    const epochs = Number(cfg.epochs) || 10;
    const lr = Number(cfg.learningRate) || 0.01;
    const hiddenSize = Number(cfg.hiddenSize) || 64;
    const maxIter = Number(cfg.maxIterations) || 100;
    const patience = Number(cfg.earlyStopPatience) || 12;

    // Sanitize dataFilePath to avoid shell injection
    const safePath = dataFilePath.replace(/'/g, "\\'");

    return `
import sys
import json
import time

sys.path.insert(0, '/home/ubuntu/tenminator-web/tenminator_lib')

try:
    import numpy as np
    from tensor import Tensor
    from nn import Module, Linear, ReLU
    from optim import Adam
    from training import TrainingController

    class SimpleModel(Module):
        def __init__(self, input_size, hidden_size, output_size):
            super().__init__()
            self.fc1 = Linear(input_size, hidden_size)
            self.relu = ReLU()
            self.fc2 = Linear(hidden_size, output_size)

        def forward(self, x):
            x = self.fc1(x)
            x = self.relu(x)
            x = self.fc2(x)
            return x

    print(f"Loading data from '${safePath}'", flush=True)
    data = np.loadtxt('${safePath}', delimiter=',', skiprows=1)
    if data.ndim == 1:
        data = data.reshape(1, -1)
    X = data[:, :-1]
    y = data[:, -1:]

    model = SimpleModel(X.shape[1], ${hiddenSize}, 1)
    optimizer = Adam(model.parameters(), lr=${lr})
    controller = TrainingController(
        max_iterations=${maxIter},
        early_stop_patience=${patience},
        checkpoint_dir='/tmp/training_${sessionId}'
    )

    print("Starting training...", flush=True)
    for epoch in range(${epochs}):
        X_t = Tensor(X, requires_grad=False)
        y_t = Tensor(y, requires_grad=False)
        predictions = model(X_t)
        loss = ((predictions - y_t) ** 2).sum() / max(len(y), 1)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        print(json.dumps({
            'epoch': epoch + 1,
            'loss': float(loss.data),
            'session_id': ${sessionId}
        }), flush=True)

        if controller.should_stop(float(loss.data)):
            print("Early stopping triggered", flush=True)
            break

        time.sleep(0.1)

    print("Training completed!", flush=True)

except Exception as e:
    print(json.dumps({'error': str(e), 'session_id': ${sessionId}}), flush=True)
    sys.exit(1)
`;
  }
}

export const trainingManager = new TrainingManager();

// Graceful shutdown on process exit
process.on("SIGTERM", () => trainingManager.shutdown());
process.on("SIGINT", () => trainingManager.shutdown());
