import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = resolve(import.meta.dirname, "..");

describe("artefactos TER I", () => {
  it("declara TER I como runtime de inferencia tenIII y no como librería genérica", () => {
    const readme = readFileSync(resolve(projectRoot, "README.md"), "utf8");
    expect(readme).toContain("# TER I");
    expect(readme).toContain("TenIII Generation 3 Inference Runtime");
    expect(readme).toContain("not a generic deep-learning library");
  });

  it("contiene el companion PyPI ter-i con CLI y metadatos del modelo", () => {
    const pyproject = readFileSync(resolve(projectRoot, "pyproject.toml"), "utf8");
    const init = readFileSync(resolve(projectRoot, "ter_i/__init__.py"), "utf8");
    const cli = readFileSync(resolve(projectRoot, "ter_i/cli.py"), "utf8");
    expect(pyproject).toContain('name = "ter-i"');
    expect(pyproject).toContain('ter-i = "ter_i.cli:main"');
    expect(init).toContain('__title__ = "TER I"');
    expect(init).toContain('"kind": "inference-runtime"');
    expect(cli).toContain('choices=("model-card", "version")');
  });
});
