import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("training endpoints", () => {
  it("creates a training session", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.training.create({
      name: "Test Training",
      dataFileUrl: "https://example.com/data.csv",
      config: {
        epochs: 10,
        learningRate: 0.01,
        hiddenSize: 64,
        maxIterations: 100,
        earlyStopPatience: 12,
      },
    });

    expect(result).toHaveProperty("sessionId");
    expect(typeof result.sessionId).toBe("number");
  });

  it("lists user training sessions", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const sessions = await caller.training.list();

    expect(Array.isArray(sessions)).toBe(true);
  });
});

describe("file upload endpoints", () => {
  it("uploads a file", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const testContent = "col1,col2,col3\n1,2,3\n4,5,6";
    const base64Content = Buffer.from(testContent).toString("base64");

    const result = await caller.files.upload({
      filename: "test.csv",
      content: base64Content,
      fileType: "text/csv",
    });

    expect(result).toHaveProperty("fileId");
    expect(result).toHaveProperty("url");
    expect(result).toHaveProperty("fileKey");
    expect(typeof result.fileId).toBe("number");
    expect(typeof result.url).toBe("string");
  });

  it("lists user uploaded files", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const files = await caller.files.list();

    expect(Array.isArray(files)).toBe(true);
  });
});
