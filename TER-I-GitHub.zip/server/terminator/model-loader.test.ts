import { describe, expect, it, vi } from "vitest";
import { composeAdapters } from "./adapter-manager";
import { checkModelConnectivity, loadRegisteredModel, supportsLanguage } from "./model-loader";

const baseModel = { id: 7, userId: 1, name: "tenIII local", kind: "llm" as const, format: "gguf", modelPath: "/models/teniii-q4.gguf", endpoint: null, languages: ["es", "ru"], capabilities: ["chat"], resourceProfile: null, enabled: "true" };

describe("ModelLoader y AdapterManager tenIII", () => {
  it("resuelve un modelo GGUF local y sus idiomas", () => {
    const descriptor = loadRegisteredModel(baseModel);
    expect(descriptor.transport).toBe("local-runtime");
    expect(supportsLanguage(descriptor, "ru-RU")).toBe(true);
    expect(supportsLanguage(descriptor, "ar")).toBe(false);
  });

  it("rechaza rutas que intentan salir del runtime local", () => {
    expect(() => loadRegisteredModel({ ...baseModel, modelPath: "../secrets/model.gguf" })).toThrow("safe endpoint or runtime path");
  });

  it("compone adaptadores LoRA y steering dentro del rango de seguridad", () => {
    const descriptor = loadRegisteredModel(baseModel);
    const composition = composeAdapters(descriptor, [
      { id: 1, userId: 1, modelId: 7, name: "ruso", kind: "qlora", format: "safetensors", pathOrUrl: "/adapters/ru", weight: 0.8, enabled: "true" },
      { id: 2, userId: 1, modelId: 7, name: "seguridad", kind: "steering", format: "json", pathOrUrl: "/adapters/safety", weight: 0.25, enabled: "true" },
    ]);
    expect(composition.adapters).toHaveLength(2);
  });

  it("comprueba un gateway HTTP y bloquea el endpoint de metadatos reservado", async () => {
    global.fetch = vi.fn(async () => ({ status: 204 })) as any;
    const descriptor = loadRegisteredModel({ ...baseModel, format: "api", endpoint: "http://127.0.0.1:8000/health", modelPath: null });
    await expect(checkModelConnectivity(descriptor)).resolves.toMatchObject({ reachable: true, status: 204 });
    const reserved = loadRegisteredModel({ ...baseModel, format: "api", endpoint: "http://169.254.169.254/", modelPath: null });
    await expect(checkModelConnectivity(reserved)).resolves.toMatchObject({ reachable: false, error: "Endpoint reservado no permitido" });
  });
});
