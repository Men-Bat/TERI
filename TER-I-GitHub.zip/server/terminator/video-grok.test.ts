import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("../storage", () => ({ storagePut: vi.fn(async () => ({ url: "https://storage.example/video.mp4" })) }));
vi.mock("nanoid", () => ({ nanoid: () => "fixed-id" }));

import { generateVideo } from "./video";

describe("Grok Video con referencias", () => {
  afterEach(() => vi.restoreAllMocks());

  it("incluye imagen de referencia y vídeo previo al crear el trabajo", async () => {
    vi.spyOn(global, "setTimeout").mockImplementation(((callback: TimerHandler) => {
      if (typeof callback === "function") callback();
      return 0 as any;
    }) as any);
    const fetchMock = vi.fn()
      .mockResolvedValueOnce({ ok: true, json: async () => ({ id: "job-1" }) })
      .mockResolvedValueOnce({ ok: true, json: async () => ({ status: "completed", video: { url: "https://x.ai/result.mp4" } }) })
      .mockResolvedValueOnce({ ok: true, arrayBuffer: async () => new Uint8Array([1, 2, 3]).buffer });
    global.fetch = fetchMock as any;

    await expect(generateVideo({ prompt: "continúa la escena", referenceImageUrl: "https://img.example/ref.png", previousVideoUrl: "https://video.example/previous.mp4" }, { preferredVideo: "grok", xaiApiKey: "secret" }))
      .resolves.toEqual({ url: "https://storage.example/video.mp4", backend: "grok-video" });

    const submitted = JSON.parse(fetchMock.mock.calls[0][1].body);
    expect(submitted).toMatchObject({
      model: "grok-imagine-video",
      reference_images: [{ url: "https://img.example/ref.png" }],
      extend_video: { url: "https://video.example/previous.mp4" },
    });
  });
});
