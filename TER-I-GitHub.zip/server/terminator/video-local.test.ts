import { describe, expect, it, vi } from "vitest";
import { generateVideo } from "./video";

describe("vídeo local configurable", () => {
  it("envía prompt y workflow al gateway local y devuelve su URL", async () => {
    global.fetch = vi.fn(async () => ({ ok: true, json: async () => ({ video_url: "http://gateway/output.mp4" }) })) as any;
    const result = await generateVideo({ prompt: "robot caminando" }, { preferredVideo: "custom", localVideoEndpoint: "http://127.0.0.1:8188", localVideoWorkflow: "ltx-t2v" });
    expect(result).toEqual({ url: "http://gateway/output.mp4", backend: "local-video" });
    expect(global.fetch).toHaveBeenCalledWith("http://127.0.0.1:8188/generate", expect.objectContaining({ method: "POST" }));
  });

  it("devuelve null sin credencial cloud cuando el gateway local falla", async () => {
    global.fetch = vi.fn(async () => ({ ok: false, status: 503 })) as any;
    await expect(generateVideo({ prompt: "robot" }, { preferredVideo: "custom", localVideoEndpoint: "http://127.0.0.1:8188" })).resolves.toBeNull();
  });
});
