import { describe, expect, it, vi } from "vitest";
import { callLLM } from "./llm";

describe("LM Studio local", () => {
  it("selecciona el gateway OpenAI-compatible y procesa una respuesta", async () => {
    global.fetch = vi.fn(async (url: string) => {
      if (url.endsWith("/v1/models")) return { ok: true, json: async () => ({ data: [{ id: "local-model" }] }) } as any;
      if (url.endsWith("/v1/chat/completions")) return { ok: true, json: async () => ({ choices: [{ message: { content: "respuesta local" } }] }) } as any;
      throw new Error("URL inesperada");
    });
    const result = await callLLM([{ role: "user", content: "hola" }], { lmstudioUrl: "http://localhost:1234", preferredBackend: "lmstudio" });
    expect(result).toMatchObject({ text: "respuesta local", backend: "lmstudio" });
  });
});
