/**
 * Terminator II — tRPC Router
 *
 * Procedures:
 *   terminator.chat          — web chat (text/audio/image)
 *   terminator.getHistory    — conversation history
 *   terminator.getConfig     — current config (masked keys)
 *   terminator.saveConfig    — save API keys and defaults
 *   terminator.checkBackends — check which LLM backends are available
 *   terminator.getConversations — list all conversations
 */

import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { processMessage } from "./orchestrator";
import { checkLLMBackends } from "./llm";
import twilio from "twilio";
import {
  getTerminatorConfig,
  upsertTerminatorConfig,
  getConversationHistory,
  getOrCreateConversation,
  createCustomModel,
  createModelAdapter,
  deleteCustomModel,
  getCustomModel,
  getUserProvider,
  listCustomModels,
  listModelAdapters,
  updateCustomModel,
  createUserProvider,
  deleteUserProvider,
  listUserProviders,
  updateUserProvider,
} from "./db";
import { nanoid } from "nanoid";
import { transcribeAudio, checkKokoro } from "./tts";
import { createRealtimeTicket } from "./realtime-session-store";
import { createDefaultTranslatorManager } from "./translator-factory";
import { checkModelConnectivity, loadRegisteredModel } from "./model-loader";
import { composeAdapters } from "./adapter-manager";
import { selectInferencePlan } from "./resource-manager";
import { checkUserProviderConnectivity } from "./provider-connectivity";

export const terminatorRouter = router({
  // ── Catálogo de proveedores externos que cada usuario administra ────────────
  listUserProviders: protectedProcedure.query(async ({ ctx }) => {
    const providers = await listUserProviders(ctx.user.id);
    return providers.map(({ secret: _secret, ...provider }) => ({ ...provider, hasSecret: Boolean(_secret) }));
  }),

  testUserProvider: protectedProcedure
    .input(z.object({ providerId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const provider = await getUserProvider(ctx.user.id, input.providerId);
      if (!provider) throw new TRPCError({ code: "NOT_FOUND", message: "Proveedor no encontrado" });
      return checkUserProviderConnectivity(provider.endpoint);
    }),

  registerUserProvider: protectedProcedure.input(z.object({
    name: z.string().min(1).max(160),
    category: z.enum(["llm", "tts", "stt", "video", "realtime", "translation", "channel", "social", "custom"]),
    providerKey: z.string().min(1).max(96),
    authType: z.enum(["api_key", "bearer", "oauth", "none"]).default("api_key"),
    endpoint: z.string().max(500).optional(),
    secret: z.string().max(4000).optional(),
    resourceId: z.string().max(255).optional(),
    metadata: z.record(z.string(), z.unknown()).optional(),
  })).mutation(async ({ ctx, input }) => {
    const id = await createUserProvider(ctx.user.id, { ...input, enabled: "true" });
    if (!id) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "No se pudo registrar el proveedor" });
    return { id };
  }),

  updateUserProvider: protectedProcedure.input(z.object({
    providerId: z.number().int().positive(), name: z.string().min(1).max(160).optional(),
    endpoint: z.string().max(500).optional(), secret: z.string().max(4000).optional(),
    resourceId: z.string().max(255).optional(), metadata: z.record(z.string(), z.unknown()).optional(),
    enabled: z.enum(["true", "false"]).optional(),
  })).mutation(async ({ ctx, input }) => {
    const { providerId, ...data } = input;
    if (!await updateUserProvider(ctx.user.id, providerId, data)) throw new TRPCError({ code: "NOT_FOUND", message: "Proveedor no encontrado" });
    return { success: true };
  }),

  deleteUserProvider: protectedProcedure.input(z.object({ providerId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
    if (!await deleteUserProvider(ctx.user.id, input.providerId)) throw new TRPCError({ code: "NOT_FOUND", message: "Proveedor no encontrado" });
    return { success: true };
  }),

  // ── Registro tenIII de modelos locales ──────────────────────────────────────
  listModels: protectedProcedure.query(({ ctx }) => listCustomModels(ctx.user.id)),

  registerModel: protectedProcedure
    .input(z.object({
      name: z.string().min(1).max(160),
      kind: z.enum(["llm", "tts", "stt", "video", "avatar", "embedding"]),
      format: z.string().min(1).max(64),
      endpoint: z.string().max(500).optional(),
      modelPath: z.string().max(1000).optional(),
      languages: z.array(z.string().max(16)).optional(),
      capabilities: z.array(z.string().max(64)).optional(),
      resourceProfile: z.record(z.string(), z.unknown()).optional(),
      config: z.record(z.string(), z.unknown()).optional(),
    }).refine((input) => Boolean(input.endpoint || input.modelPath), { message: "Se requiere endpoint o ruta de runtime" }))
    .mutation(async ({ ctx, input }) => {
      const id = await createCustomModel(ctx.user.id, { ...input, enabled: "true" });
      if (!id) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "No se pudo registrar el modelo" });
      return { id };
    }),

  registerAdapter: protectedProcedure
    .input(z.object({
      modelId: z.number().int().positive(), name: z.string().min(1).max(160),
      kind: z.enum(["lora", "qlora", "steering", "custom"]), format: z.string().min(1).max(64),
      pathOrUrl: z.string().min(1).max(1000), weight: z.number().min(-2).max(2).default(1),
      config: z.record(z.string(), z.unknown()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const model = await getCustomModel(ctx.user.id, input.modelId);
      if (!model) throw new TRPCError({ code: "NOT_FOUND", message: "Modelo no encontrado" });
      const id = await createModelAdapter(ctx.user.id, { ...input, enabled: "true" });
      if (!id) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "No se pudo registrar el adaptador" });
      return { id };
    }),

  updateModel: protectedProcedure.input(z.object({ modelId: z.number().int().positive(), name: z.string().min(1).max(160).optional(), format: z.string().min(1).max(64).optional(), endpoint: z.string().max(500).optional(), modelPath: z.string().max(1000).optional(), enabled: z.enum(["true", "false"]).optional() })).mutation(async ({ ctx, input }) => {
    const { modelId, ...data } = input;
    if (!await updateCustomModel(ctx.user.id, modelId, data)) throw new TRPCError({ code: "NOT_FOUND", message: "Modelo no encontrado" });
    return { success: true };
  }),

  deleteModel: protectedProcedure.input(z.object({ modelId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
    if (!await deleteCustomModel(ctx.user.id, input.modelId)) throw new TRPCError({ code: "NOT_FOUND", message: "Modelo no encontrado" });
    return { success: true };
  }),

  resolveModelRuntime: protectedProcedure
    .input(z.object({ modelId: z.number().int().positive(), language: z.string().max(16).optional() }))
    .query(async ({ ctx, input }) => {
      const model = await getCustomModel(ctx.user.id, input.modelId);
      if (!model) throw new TRPCError({ code: "NOT_FOUND", message: "Modelo no encontrado" });
      try {
        const descriptor = loadRegisteredModel(model);
        const adapters = descriptor.kind === "llm" ? composeAdapters(descriptor, await listModelAdapters(ctx.user.id, model.id)) : null;
        const resourceProfile = model.resourceProfile && typeof model.resourceProfile === "object" ? model.resourceProfile : {};
        return { descriptor, adapters, inferencePlan: selectInferencePlan(resourceProfile) };
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Configuración de modelo inválida" });
      }
    }),

  checkModelConnectivity: protectedProcedure
    .input(z.object({ modelId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const model = await getCustomModel(ctx.user.id, input.modelId);
      if (!model) throw new TRPCError({ code: "NOT_FOUND", message: "Modelo no encontrado" });
      return checkModelConnectivity(loadRegisteredModel(model));
    }),

  // ── Web chat ────────────────────────────────────────────────────────────────
  chat: publicProcedure
    .input(
      z.object({
        sessionId: z.string().optional(),
        text: z.string().optional(),
        audioUrl: z.string().url().optional(),
        imageUrl: z.string().url().optional(),
        videoUrl: z.string().url().optional(),
        personaId: z.string().default("default"),
        language: z.string().default("es"),
        withVideo: z.boolean().default(false),
        withAudio: z.boolean().default(true),
        llmBackend: z.string().default("auto"),
        ttsBackend: z.string().default("auto"),
        videoBackend: z.string().default("none"),
        customModelId: z.number().int().positive().optional(),
        userProviderId: z.number().int().positive().optional(),
        userTtsProviderId: z.number().int().positive().optional(),
        userVideoProviderId: z.number().int().positive().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (!input.text && !input.audioUrl) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Se requiere texto o audio" });
      }

      const userId = ctx.user?.id ?? 0;
      const cfg = userId ? await getTerminatorConfig(userId) : null;

      // Override config with per-request backends
      const effectiveCfg = cfg
        ? {
            ...cfg,
            defaultLlm: input.llmBackend,
            defaultTts: input.ttsBackend,
            defaultVideo: input.videoBackend,
          }
        : null;

      const sessionId = input.sessionId ?? `web:${nanoid()}`;
      let text = input.text;
      const customModel = input.customModelId && userId ? await getCustomModel(userId, input.customModelId) : null;
      if (input.customModelId && (!customModel || customModel.kind !== "llm")) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Modelo LLM registrado no encontrado" });
      }
      const customDescriptor = customModel ? loadRegisteredModel(customModel) : null;
      const userProvider = input.userProviderId && userId ? await getUserProvider(userId, input.userProviderId) : null;
      if (input.userProviderId && (!userProvider || userProvider.category !== "llm" || userProvider.enabled !== "true" || !userProvider.endpoint)) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Proveedor LLM habilitado no encontrado" });
      }
      const userTtsProvider = input.userTtsProviderId && userId ? await getUserProvider(userId, input.userTtsProviderId) : null;
      if (input.userTtsProviderId && (!userTtsProvider || userTtsProvider.category !== "tts" || userTtsProvider.enabled !== "true" || !userTtsProvider.endpoint)) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Proveedor TTS habilitado no encontrado" });
      }
      const userVideoProvider = input.userVideoProviderId && userId ? await getUserProvider(userId, input.userVideoProviderId) : null;
      if (input.userVideoProviderId && (!userVideoProvider || userVideoProvider.category !== "video" || userVideoProvider.enabled !== "true" || !userVideoProvider.endpoint)) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Proveedor de vídeo habilitado no encontrado" });
      }

      // If audio provided, transcribe first
      if (!text && input.audioUrl && cfg) {
        const stt = await transcribeAudio(
          input.audioUrl,
          { xaiApiKey: cfg.xaiApiKey ?? undefined, openaiApiKey: cfg.openaiApiKey ?? undefined },
          input.language
        );
        text = stt?.text;
      }

      const result = await processMessage(
        {
          channelId: sessionId,
          channel: "web",
          text,
          audioUrl: input.audioUrl,
          imageUrl: input.imageUrl,
          videoUrl: input.videoUrl,
          language: input.language,
        },
        effectiveCfg,
        {
          withVideo: input.withVideo,
          withAudio: input.withAudio,
          personaId: input.personaId,
          language: input.language,
          customLlmEndpoint: userProvider?.endpoint ?? (customDescriptor?.transport === "http" ? customDescriptor.target : undefined),
          customLlmApiKey: userProvider?.secret ?? undefined,
          customLlmModel: userProvider?.resourceId ?? undefined,
          customTtsEndpoint: userTtsProvider?.endpoint ?? undefined,
          customTtsApiKey: userTtsProvider?.secret ?? undefined,
          customTtsVoice: userTtsProvider?.resourceId ?? undefined,
          customVideoEndpoint: userVideoProvider?.endpoint ?? undefined,
          customVideoApiKey: userVideoProvider?.secret ?? undefined,
          customVideoWorkflow: userVideoProvider?.resourceId ?? undefined,
          persistConversation: Boolean(ctx.user),
        }
      );

      return result;
    }),

  // ── Conversation history ─────────────────────────────────────────────────────
  getHistory: publicProcedure
    .input(
      z.object({
        sessionId: z.string(),
        limit: z.number().int().min(1).max(100).default(20),
      })
    )
    .query(async ({ input }) => {
      const conv = await getOrCreateConversation(input.sessionId, "web");
      if (!conv) return [];
      return getConversationHistory(conv.id, input.limit);
    }),

  // ── Config ──────────────────────────────────────────────────────────────────
  getConfig: protectedProcedure.query(async ({ ctx }) => {
    const cfg = await getTerminatorConfig(ctx.user.id);
    if (!cfg) return null;
    // Mask API keys
    const mask = (key: string | null | undefined) =>
      key ? `${key.slice(0, 4)}${"*".repeat(Math.max(0, key.length - 8))}${key.slice(-4)}` : null;
    return {
      ...cfg,
      xaiApiKey: mask(cfg.xaiApiKey),
      openaiApiKey: mask(cfg.openaiApiKey),
      moonshotApiKey: mask(cfg.moonshotApiKey),
      deepseekApiKey: mask(cfg.deepseekApiKey),
      geminiApiKey: mask(cfg.geminiApiKey),
      elevenlabsApiKey: mask(cfg.elevenlabsApiKey),
      realtimeCustomApiKey: mask(cfg.realtimeCustomApiKey),
      googleTranslateApiKey: mask(cfg.googleTranslateApiKey),
      deeplApiKey: mask(cfg.deeplApiKey),
      kokoroApiKey: mask(cfg.kokoroApiKey),
      twilioAuthToken: mask(cfg.twilioAuthToken),
      whatsappToken: mask(cfg.whatsappToken),
      whatsappAppSecret: mask(cfg.whatsappAppSecret),
      telegramBotToken: mask(cfg.telegramBotToken),
      telegramWebhookSecret: mask(cfg.telegramWebhookSecret),
    };
  }),

  saveConfig: protectedProcedure
    .input(
      z.object({
        ollamaUrl: z.string().optional(),
        lmstudioUrl: z.string().optional(),
        xaiApiKey: z.string().optional(),
        openaiApiKey: z.string().optional(),
        moonshotApiKey: z.string().optional(),
        deepseekApiKey: z.string().optional(),
        geminiApiKey: z.string().optional(),
        elevenlabsApiKey: z.string().optional(),
        realtimeCustomApiKey: z.string().optional(),
        googleTranslateApiKey: z.string().optional(),
        deeplApiKey: z.string().optional(),
        kokoroUrl: z.string().optional(),
        kokoroApiKey: z.string().optional(),
        kokoroLocalOnly: z.enum(["true", "false"]).optional(),
        coquiUrl: z.string().optional(),
        sileroUrl: z.string().optional(),
        piperUrl: z.string().optional(),
        twilioAccountSid: z.string().optional(),
        twilioAuthToken: z.string().optional(),
        twilioApiKeySid: z.string().optional(),
        twilioApiKeySecret: z.string().optional(),
        twilioPhoneNumber: z.string().optional(),
        whatsappToken: z.string().optional(),
        whatsappPhoneNumberId: z.string().optional(),
        whatsappVerifyToken: z.string().optional(),
        whatsappAppSecret: z.string().optional(),
        telegramBotToken: z.string().optional(),
        telegramWebhookSecret: z.string().optional(),
        defaultPersona: z.string().optional(),
        defaultLlm: z.string().optional(),
        defaultTts: z.string().optional(),
        defaultStt: z.string().optional(),
        defaultVideo: z.string().optional(),
        defaultAvatar: z.string().optional(),
        localVideoEndpoint: z.string().max(500).optional(),
        localVideoWorkflow: z.string().max(160).optional(),
        defaultLanguage: z.string().optional(),
        realtimeBackend: z.string().optional(),
        realtimeEndpoint: z.string().optional(),
        realtimeModel: z.string().optional(),
        realtimeFallbackJson: z.string().optional(),
        realtimeAllowFallback: z.string().optional(),
        translatorBackend: z.string().optional(),
        translatorEndpoint: z.string().optional(),
        translatorFallbackJson: z.string().optional(),
        translatorAllowFallback: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await upsertTerminatorConfig(ctx.user.id, input);
      return { success: true };
    }),

  // ── Check backends ───────────────────────────────────────────────────────────
  checkBackends: publicProcedure
    .input(
      z.object({
        ollamaUrl: z.string().default("http://localhost:11434"),
        lmstudioUrl: z.string().default("http://localhost:1234"),
        kokoroUrl: z.string().default("http://localhost:8880"),
        kokoroApiKey: z.string().optional(),
        kokoroLocalOnly: z.enum(["true", "false"]).optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      const userId = ctx.user?.id ?? 0;
      const cfg = userId ? await getTerminatorConfig(userId) : null;
      const [llmBackends, kokoroActive] = await Promise.all([
        checkLLMBackends({
          ollamaUrl: input.ollamaUrl,
          lmstudioUrl: input.lmstudioUrl,
          xaiApiKey: cfg?.xaiApiKey ?? undefined,
          openaiApiKey: cfg?.openaiApiKey ?? undefined,
          moonshotApiKey: cfg?.moonshotApiKey ?? undefined,
          deepseekApiKey: cfg?.deepseekApiKey ?? undefined,
        }),
        checkKokoro(
          input.kokoroUrl,
          input.kokoroApiKey ?? cfg?.kokoroApiKey ?? process.env.KOKORO_API_KEY,
          input.kokoroLocalOnly === "true" || cfg?.kokoroLocalOnly === "true" || process.env.KOKORO_LOCAL_ONLY === "true",
        ),
      ]);
      return { ...llmBackends, kokoro: kokoroActive };
    }),

  // ── Traducción opcional para turnos Realtime ───────────────────────────────────
  translateRealtime: publicProcedure
    .input(z.object({
      text: z.string().min(1).max(20_000),
      sourceLanguage: z.string().max(16).optional(),
      targetLanguage: z.string().min(2).max(16),
      backend: z.string().optional(),
      userProviderId: z.number().int().positive().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.user?.id ?? 0;
      const cfg = userId ? await getTerminatorConfig(userId) : null;
      const userTranslator = input.userProviderId && userId ? await getUserProvider(userId, input.userProviderId) : null;
      if (input.userProviderId && (!userTranslator || userTranslator.category !== "translation" || userTranslator.enabled !== "true" || !userTranslator.endpoint)) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Traductor habilitado no encontrado" });
      }
      const backend = userTranslator ? "custom-translator" : input.backend ?? cfg?.translatorBackend ?? process.env.TERMINATOR_TRANSLATOR_BACKEND ?? "none";
      if (backend === "none") {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "La traducción en tiempo real está desactivada" });
      }
      try {
        const manager = createDefaultTranslatorManager({
          activeBackend: backend,
          translatorEndpoint: userTranslator?.endpoint ?? cfg?.translatorEndpoint ?? undefined,
          translatorApiKey: userTranslator?.secret ?? undefined,
          googleApiKey: cfg?.googleTranslateApiKey ?? process.env.GOOGLE_TRANSLATE_API_KEY,
          deeplApiKey: cfg?.deeplApiKey ?? process.env.DEEPL_API_KEY,
          allowFallback: cfg?.translatorAllowFallback === "true" || process.env.TERMINATOR_TRANSLATOR_ALLOW_FALLBACK === "true",
        });
        return await manager.translate(input);
      } catch (error) {
        throw new TRPCError({ code: "BAD_GATEWAY", message: error instanceof Error ? error.message : "Error de traducción" });
      }
    }),

  // ── Realtime session ticket ───────────────────────────────────────────────────
  createRealtimeSession: protectedProcedure
    .input(z.object({
      backend: z.enum(["openai-realtime", "moshi-local", "gemini-live", "elevenlabs-agents"]).optional(),
      model: z.string().max(128).optional(),
      language: z.string().max(16).optional(),
      instructions: z.string().max(4_000).optional(),
      userRealtimeProviderId: z.number().int().positive().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const cfg = await getTerminatorConfig(ctx.user.id);
      const userRealtime = input.userRealtimeProviderId ? await getUserProvider(ctx.user.id, input.userRealtimeProviderId) : null;
      const supportedRealtimeBackends = ["openai-realtime", "moshi-local", "gemini-live", "elevenlabs-agents"] as const;
      if (input.userRealtimeProviderId && (!userRealtime || userRealtime.category !== "realtime" || userRealtime.enabled !== "true" || !supportedRealtimeBackends.includes(userRealtime.providerKey as typeof supportedRealtimeBackends[number]))) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Backend Realtime habilitado no encontrado o no compatible" });
      }
      const backend = userRealtime?.providerKey ?? input.backend ?? cfg?.realtimeBackend ?? "openai-realtime";
      const configuredApiKey = backend === "openai-realtime"
        ? (cfg?.openaiApiKey ?? process.env.OPENAI_API_KEY)
        : backend === "gemini-live"
          ? (cfg?.geminiApiKey ?? process.env.GEMINI_API_KEY)
          : backend === "elevenlabs-agents"
            ? (cfg?.elevenlabsApiKey ?? process.env.ELEVENLABS_API_KEY)
            : backend === "moshi-local"
              ? undefined
              : (cfg?.realtimeCustomApiKey ?? process.env.REALTIME_CUSTOM_API_KEY);
      const apiKey = userRealtime?.secret ?? configuredApiKey;
      const endpoint = userRealtime?.endpoint ?? cfg?.realtimeEndpoint ?? undefined;
      if (backend !== "moshi-local" && !apiKey && !endpoint) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: `Falta la credencial o endpoint para ${backend}` });
      }
      const ticket = createRealtimeTicket({
        apiKey,
        endpoint,
        model: userRealtime?.resourceId ?? input.model ?? cfg?.realtimeModel ?? undefined,
        language: input.language ?? cfg?.defaultLanguage ?? "es",
        instructions: input.instructions,
        metadata: { backend },
      });
      return { ticket, backend, expiresInMs: 60_000 };
    }),

  // ── Twilio Video token ────────────────────────────────────────────────────────
  getVideoToken: publicProcedure
    .input(
      z.object({
        roomName: z.string().default("terminator-room"),
        identity: z.string().default("user"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.user?.id ?? 0;
      const cfg = userId ? await getTerminatorConfig(userId) : null;
      const accountSid = cfg?.twilioAccountSid ?? process.env.TWILIO_ACCOUNT_SID;
      const authToken  = cfg?.twilioAuthToken  ?? process.env.TWILIO_AUTH_TOKEN;
      // Prefer API Key (recommended) over Auth Token for AccessToken signing
      const apiKeySid    = cfg?.twilioApiKeySid    ?? process.env.TWILIO_API_KEY_SID    ?? authToken;
      const apiKeySecret = cfg?.twilioApiKeySecret ?? process.env.TWILIO_API_KEY_SECRET ?? authToken;
      if (!accountSid || !apiKeySid || !apiKeySecret) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Twilio no configurado: falta Account SID o API Key" });
      }
      const AccessToken = twilio.jwt.AccessToken;
      const VideoGrant  = AccessToken.VideoGrant;
      // Correct constructor: AccessToken(accountSid, apiKeySid, apiKeySecret, options)
      const token = new AccessToken(accountSid, apiKeySid, apiKeySecret, {
        identity: input.identity,
        ttl: 3600,
      });
      token.addGrant(new VideoGrant({ room: input.roomName }));
      return { token: token.toJwt(), roomName: input.roomName };
    }),

  // ── Webhook: WhatsApp ────────────────────────────────────────────────────────
  // Note: WhatsApp webhooks are handled as raw Express routes (see server/index.ts extension)
  // This procedure is for testing/manual trigger only
  testWebhook: protectedProcedure
    .input(z.object({ channel: z.enum(["whatsapp", "telegram", "sms"]), payload: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const cfg = await getTerminatorConfig(ctx.user.id);
      const parsed = JSON.parse(input.payload) as Record<string, unknown>;
      console.log(`[Webhook Test] channel=${input.channel}`, parsed);
      return { received: true, cfg: !!cfg };
    }),
});
