export type ComputeDevice = "cpu" | "cuda" | "mps" | "rocm";
export type Quantization = "fp16" | "q8" | "q6" | "q5" | "q4" | "q3" | "q2" | "q1";

export interface ResourceProfile { device?: ComputeDevice; ramGb?: number; vramGb?: number; preferLowMemory?: boolean; }
export interface InferencePlan { device: ComputeDevice; quantization: Quantization; offloadLayers: number; reason: string; }

export function selectInferencePlan(profile: ResourceProfile = {}): InferencePlan {
  const device = profile.device ?? "cpu";
  const memory = device === "cuda" || device === "rocm" ? (profile.vramGb ?? 0) : (profile.ramGb ?? 0);
  const quantization: Quantization = profile.preferLowMemory || memory < 4 ? "q2" : memory < 8 ? "q4" : memory < 16 ? "q6" : "q8";
  const offloadLayers = device === "cpu" ? 0 : memory < 8 ? 16 : 32;
  return { device, quantization, offloadLayers, reason: `${device} con ${memory} GB declarados` };
}
