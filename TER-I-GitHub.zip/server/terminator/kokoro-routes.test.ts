import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getTerminatorConfig: vi.fn(),
  getKokoroModels: vi.fn(),
  getKokoroVoices: vi.fn(),
  isKokoroLocalUrl: vi.fn(),
}));

vi.mock("./db", () => ({
  getTerminatorConfig: mocks.getTerminatorConfig,
}));

vi.mock("./tts", () => ({
  synthesizeSpeech: vi.fn(),
  getKokoroModels: mocks.getKokoroModels,
  getKokoroVoices: mocks.getKokoroVoices,
  isKokoroLocalUrl: mocks.isKokoroLocalUrl,
}));

import { registerKokoroMetadata } from "./webhooks";

type Handler = (request: unknown, response: ReturnType<typeof createResponse>) => Promise<void> | void;

function createResponse() {
  const response = {
    status: vi.fn(),
    json: vi.fn(),
  };
  response.status.mockReturnValue(response);
  return response;
}

function registerHandlers(): Map<string, Handler> {
  const handlers = new Map<string, Handler>();
  const fakeApp = {
    get: (path: string, handler: Handler) => handlers.set(path, handler),
  };
  registerKokoroMetadata(fakeApp as never);
  return handlers;
}

describe("rutas HTTP de metadata Kokoro", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.getTerminatorConfig.mockResolvedValue({
      kokoroUrl: "http://localhost:8880",
      kokoroApiKey: "server-token",
      kokoroLocalOnly: "false",
    });
    mocks.isKokoroLocalUrl.mockReturnValue(true);
    mocks.getKokoroModels.mockResolvedValue({ data: [{ id: "kokoro" }] });
    mocks.getKokoroVoices.mockResolvedValue({ data: [{ id: "af_bella" }] });
  });

  it("registra health, voices y models bajo el prefijo de Terminator", () => {
    expect(Array.from(registerHandlers().keys())).toEqual([
      "/api/terminator/kokoro/voices",
      "/api/terminator/kokoro/models",
      "/api/terminator/kokoro/health",
    ]);
  });

  it("devuelve voices y reenvía la credencial solo al gateway desde el servidor", async () => {
    const handler = registerHandlers().get("/api/terminator/kokoro/voices");
    const response = createResponse();

    await handler?.({}, response);

    expect(mocks.getKokoroVoices).toHaveBeenCalledWith("http://localhost:8880", "server-token");
    expect(response.status).toHaveBeenCalledWith(200);
    expect(response.json).toHaveBeenCalledWith({ backend: "kokoro", localOnly: false, data: [{ id: "af_bella" }] });
  });

  it("bloquea health sin contactar el gateway cuando está activo local-only para una URL remota", async () => {
    mocks.getTerminatorConfig.mockResolvedValue({
      kokoroUrl: "https://remote.example",
      kokoroApiKey: "server-token",
      kokoroLocalOnly: "true",
    });
    mocks.isKokoroLocalUrl.mockReturnValue(false);
    const handler = registerHandlers().get("/api/terminator/kokoro/health");
    const response = createResponse();

    await handler?.({}, response);

    expect(mocks.getKokoroModels).not.toHaveBeenCalled();
    expect(response.status).toHaveBeenCalledWith(503);
    expect(response.json).toHaveBeenCalledWith({ status: "blocked", backend: "kokoro", localOnly: true });
  });

  it("convierte un fallo upstream de models en un error HTTP 502 controlado", async () => {
    mocks.getKokoroModels.mockRejectedValue(new Error("Kokoro /v1/models HTTP 503"));
    const handler = registerHandlers().get("/api/terminator/kokoro/models");
    const response = createResponse();

    await handler?.({}, response);

    expect(response.status).toHaveBeenCalledWith(502);
    expect(response.json).toHaveBeenCalledWith({
      error: "Kokoro metadata unavailable",
      detail: "Kokoro /v1/models HTTP 503",
    });
  });
});
