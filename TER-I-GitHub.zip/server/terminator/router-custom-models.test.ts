import { beforeEach, describe, expect, it, vi } from "vitest";

const db = vi.hoisted(() => ({
  listCustomModels: vi.fn(),
  createCustomModel: vi.fn(),
  updateCustomModel: vi.fn(),
  deleteCustomModel: vi.fn(),
  getCustomModel: vi.fn(),
  createModelAdapter: vi.fn(),
  getTerminatorConfig: vi.fn(),
  upsertTerminatorConfig: vi.fn(),
  listUserProviders: vi.fn(),
  getUserProvider: vi.fn(),
  createUserProvider: vi.fn(),
  updateUserProvider: vi.fn(),
  deleteUserProvider: vi.fn(),
  getConversationHistory: vi.fn(),
  getOrCreateConversation: vi.fn(),
  processMessage: vi.fn(),
}));
const translator = vi.hoisted(() => ({ createDefaultTranslatorManager: vi.fn() }));
const tickets = vi.hoisted(() => ({ createRealtimeTicket: vi.fn(() => "ticket-realtime-prueba") }));
const providerConnectivity = vi.hoisted(() => ({ checkUserProviderConnectivity: vi.fn() }));

vi.mock("./db", () => db);
vi.mock("./orchestrator", () => ({ processMessage: db.processMessage }));
vi.mock("./llm", () => ({ checkLLMBackends: vi.fn() }));
vi.mock("./tts", () => ({ transcribeAudio: vi.fn(), checkKokoro: vi.fn() }));
vi.mock("./realtime-session-store", () => tickets);
vi.mock("./translator-factory", () => translator);
vi.mock("./provider-connectivity", () => providerConnectivity);
vi.mock("./model-loader", () => ({ checkModelConnectivity: vi.fn(), loadRegisteredModel: vi.fn() }));
vi.mock("./adapter-manager", () => ({ composeAdapters: vi.fn() }));
vi.mock("./resource-manager", () => ({ selectInferencePlan: vi.fn() }));

import { terminatorRouter } from "./router";

describe("CRUD tRPC de modelos tenIII", () => {
  const caller = () => terminatorRouter.createCaller({ user: { id: 42 } } as any);

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("registra y lista únicamente los modelos del usuario autenticado", async () => {
    db.createCustomModel.mockResolvedValue(9);
    db.listCustomModels.mockResolvedValue([{ id: 9, userId: 42, name: "Modelo local", kind: "llm", format: "gguf" }]);

    await expect(caller().registerModel({ name: "Modelo local", kind: "llm", format: "gguf", modelPath: "/models/local.gguf" })).resolves.toEqual({ id: 9 });
    await expect(caller().listModels()).resolves.toEqual([{ id: 9, userId: 42, name: "Modelo local", kind: "llm", format: "gguf" }]);
    expect(db.createCustomModel).toHaveBeenCalledWith(42, expect.objectContaining({ name: "Modelo local", modelPath: "/models/local.gguf", enabled: "true" }));
    expect(db.listCustomModels).toHaveBeenCalledWith(42);
  });

  it("actualiza y elimina un modelo restringiendo cada operación al usuario autenticado", async () => {
    db.updateCustomModel.mockResolvedValue(true);
    db.deleteCustomModel.mockResolvedValue(true);

    await expect(caller().updateModel({ modelId: 9, name: "Modelo ajustado", format: "safetensors", enabled: "false" })).resolves.toEqual({ success: true });
    await expect(caller().deleteModel({ modelId: 9 })).resolves.toEqual({ success: true });
    expect(db.updateCustomModel).toHaveBeenCalledWith(42, 9, { name: "Modelo ajustado", format: "safetensors", enabled: "false" });
    expect(db.deleteCustomModel).toHaveBeenCalledWith(42, 9);
  });

  it("rechaza registros que no incluyen un runtime HTTP ni una ruta local", async () => {
    await expect(caller().registerModel({ name: "Incompleto", kind: "llm", format: "gguf" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(db.createCustomModel).not.toHaveBeenCalled();
  });

  it("transmite un vídeo previo de la sesión web al orquestador", async () => {
    db.getTerminatorConfig.mockResolvedValue(null);
    db.processMessage.mockResolvedValue({ text: "continuación", backend: {} });

    await caller().chat({ text: "continúa este vídeo", videoUrl: "https://video.example/previous.mp4", withAudio: false, withVideo: true });

    expect(db.processMessage).toHaveBeenCalledWith(
      expect.objectContaining({ videoUrl: "https://video.example/previous.mp4" }),
      null,
      expect.objectContaining({ withVideo: true }),
    );
  });

  it("persiste las preferencias de STT y avatar del usuario autenticado", async () => {
    await expect(caller().saveConfig({ defaultStt: "openai", defaultAvatar: "custom" })).resolves.toEqual({ success: true });
    expect(db.upsertTerminatorConfig).toHaveBeenCalledWith(42, { defaultStt: "openai", defaultAvatar: "custom" });
  });

  it("registra, enmascara y aísla proveedores opcionales por usuario", async () => {
    db.createUserProvider.mockResolvedValue(12);
    db.listUserProviders.mockResolvedValue([{ id: 12, userId: 42, name: "ElevenLabs privado", category: "tts", providerKey: "elevenlabs", authType: "api_key", endpoint: "https://api.elevenlabs.io", secret: "xi-secret", resourceId: "voice_abc", enabled: "true" }]);
    db.updateUserProvider.mockResolvedValue(true);
    db.deleteUserProvider.mockResolvedValue(true);

    await expect(caller().registerUserProvider({ name: "ElevenLabs privado", category: "tts", providerKey: "elevenlabs", endpoint: "https://api.elevenlabs.io", secret: "xi-secret", resourceId: "voice_abc" })).resolves.toEqual({ id: 12 });
    await expect(caller().listUserProviders()).resolves.toEqual([expect.objectContaining({ id: 12, userId: 42, hasSecret: true })]);
    expect((await caller().listUserProviders())[0]).not.toHaveProperty("secret");
    await expect(caller().updateUserProvider({ providerId: 12, enabled: "false" })).resolves.toEqual({ success: true });
    await expect(caller().deleteUserProvider({ providerId: 12 })).resolves.toEqual({ success: true });
    expect(db.createUserProvider).toHaveBeenCalledWith(42, expect.objectContaining({ providerKey: "elevenlabs", secret: "xi-secret", enabled: "true" }));
    expect(db.updateUserProvider).toHaveBeenCalledWith(42, 12, { enabled: "false" });
    expect(db.deleteUserProvider).toHaveBeenCalledWith(42, 12);
  });

  it("permite usar únicamente un proveedor LLM habilitado perteneciente al usuario", async () => {
    db.getUserProvider.mockResolvedValue({ id: 31, userId: 42, category: "llm", providerKey: "gateway-propio", endpoint: "http://127.0.0.1:8080", secret: "clave-descifrada", resourceId: "modelo-local", enabled: "true" });
    await caller().chat({ text: "hola", userProviderId: 31 });
    expect(db.processMessage).toHaveBeenCalledWith(expect.any(Object), null, expect.objectContaining({ customLlmEndpoint: "http://127.0.0.1:8080", customLlmApiKey: "clave-descifrada", customLlmModel: "modelo-local" }));
  });

  it("permite usar únicamente una voz propia habilitada perteneciente al usuario", async () => {
    db.getUserProvider.mockResolvedValue({ id: 32, userId: 42, category: "tts", providerKey: "elevenlabs-compatible", endpoint: "http://127.0.0.1:9000", secret: "clave-voz", resourceId: "voz-autorizada", enabled: "true" });
    await caller().chat({ text: "hola", userTtsProviderId: 32 });
    expect(db.processMessage).toHaveBeenCalledWith(expect.any(Object), null, expect.objectContaining({ customTtsEndpoint: "http://127.0.0.1:9000", customTtsApiKey: "clave-voz", customTtsVoice: "voz-autorizada" }));
  });

  it("permite usar únicamente un gateway de vídeo propio habilitado perteneciente al usuario", async () => {
    db.getUserProvider.mockResolvedValue({ id: 33, userId: 42, category: "video", providerKey: "wan-gateway", endpoint: "http://127.0.0.1:8188", secret: "clave-video", resourceId: "wan22-ti2v", enabled: "true" });
    await caller().chat({ text: "genera vídeo", withVideo: true, userVideoProviderId: 33 });
    expect(db.processMessage).toHaveBeenCalledWith(expect.any(Object), null, expect.objectContaining({ customVideoEndpoint: "http://127.0.0.1:8188", customVideoApiKey: "clave-video", customVideoWorkflow: "wan22-ti2v" }));
  });

  it("resuelve un traductor propio habilitado solo para el usuario autenticado", async () => {
    const translate = vi.fn().mockResolvedValue({ text: "hello", backend: "custom-translator", cached: false });
    translator.createDefaultTranslatorManager.mockReturnValue({ translate });
    db.getUserProvider.mockResolvedValue({ id: 34, userId: 42, category: "translation", providerKey: "alia-propia", endpoint: "http://127.0.0.1:7000", secret: "clave-traductor", resourceId: null, enabled: "true" });
    await expect(caller().translateRealtime({ text: "hola", sourceLanguage: "es", targetLanguage: "en", userProviderId: 34 })).resolves.toEqual({ text: "hello", backend: "custom-translator", cached: false });
    expect(translator.createDefaultTranslatorManager).toHaveBeenCalledWith(expect.objectContaining({ activeBackend: "custom-translator", translatorEndpoint: "http://127.0.0.1:7000", translatorApiKey: "clave-traductor" }));
    expect(translate).toHaveBeenCalledWith(expect.objectContaining({ text: "hola", targetLanguage: "en" }));
  });

  it("emite un ticket Realtime usando solo el backend y secreto propios del usuario", async () => {
    db.getUserProvider.mockResolvedValue({ id: 35, userId: 42, category: "realtime", providerKey: "gemini-live", endpoint: "wss://realtime.example.test/live", secret: "clave-realtime", resourceId: "gemini-live-personal", enabled: "true" });
    await expect(caller().createRealtimeSession({ userRealtimeProviderId: 35, language: "es" })).resolves.toEqual({ ticket: "ticket-realtime-prueba", backend: "gemini-live", expiresInMs: 60_000 });
    expect(tickets.createRealtimeTicket).toHaveBeenCalledWith(expect.objectContaining({ apiKey: "clave-realtime", endpoint: "wss://realtime.example.test/live", model: "gemini-live-personal", language: "es", metadata: { backend: "gemini-live" } }));
    expect(db.getUserProvider).toHaveBeenCalledWith(42, 35);
  });

  it("comprueba un proveedor propio sin entregar su secreto al verificador", async () => {
    providerConnectivity.checkUserProviderConnectivity.mockResolvedValue({ reachable: true, status: 204, latencyMs: 10 });
    db.getUserProvider.mockResolvedValue({ id: 36, userId: 42, category: "custom", providerKey: "gateway", endpoint: "http://127.0.0.1:8100/health", secret: "secreto-nunca-enviado", enabled: "true" });
    await expect(caller().testUserProvider({ providerId: 36 })).resolves.toMatchObject({ reachable: true, status: 204 });
    expect(providerConnectivity.checkUserProviderConnectivity).toHaveBeenCalledWith("http://127.0.0.1:8100/health");
  });
});
