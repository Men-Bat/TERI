import { describe, expect, it } from "vitest";
import { consumeRealtimeTicket, createRealtimeTicket } from "./realtime-session-store";

describe("Realtime session store", () => {
  it("permite consumir un ticket una sola vez", () => {
    const ticket = createRealtimeTicket({ apiKey: "server-only", metadata: { backend: "openai-realtime" } });

    expect(consumeRealtimeTicket(ticket)?.apiKey).toBe("server-only");
    expect(consumeRealtimeTicket(ticket)).toBeNull();
  });

  it("rechaza tickets expirados", () => {
    const ticket = createRealtimeTicket({ metadata: { backend: "moshi-local" } }, 0);

    expect(consumeRealtimeTicket(ticket)).toBeNull();
  });
});
