/**
 * Terminator II — contratos comunes para conversación Realtime.
 *
 * El contrato desacopla el orquestador de un proveedor concreto. Los
 * adaptadores pueden ser locales, cloud o WebSocket personalizados.
 */

export type RealtimeBackendKind =
  | "openai"
  | "moshi"
  | "ultravox"
  | "gemini"
  | "elevenlabs"
  | "custom";

export type RealtimeConnectionState = "disconnected" | "connecting" | "connected" | "error";

export interface RealtimeConfig {
  endpoint?: string;
  apiKey?: string;
  model?: string;
  language?: string;
  sampleRate?: number;
  inputEncoding?: "pcm16" | "opus" | "base64";
  outputEncoding?: "pcm16" | "opus" | "base64";
  headers?: Record<string, string>;
  instructions?: string;
  metadata?: Record<string, unknown>;
}

export interface RealtimeAudioChunk {
  data: Uint8Array;
  sampleRate?: number;
  encoding?: "pcm16" | "opus" | "base64";
  isFinal?: boolean;
}

export interface RealtimeEvent {
  type:
    | "connected"
    | "disconnected"
    | "error"
    | "audio"
    | "transcript"
    | "response"
    | "interrupted"
    | "metadata";
  text?: string;
  audio?: RealtimeAudioChunk;
  error?: string;
  data?: unknown;
}

export interface RealtimeStatus {
  state: RealtimeConnectionState;
  backend: string;
  latencyMs: number | null;
  lastError: string | null;
  connectedAt: number | null;
}

export interface RealtimeMetrics {
  sentAudioChunks: number;
  receivedAudioChunks: number;
  sentTextMessages: number;
  receivedTranscripts: number;
  receivedResponses: number;
  errorCount: number;
  averageLatencyMs: number | null;
}

export type RealtimeEventHandler = (event: RealtimeEvent) => void;

export interface RealtimeBackend {
  readonly name: string;
  readonly kind: RealtimeBackendKind;

  connect(config?: RealtimeConfig): Promise<void>;
  disconnect(): Promise<void>;
  sendAudio(chunk: RealtimeAudioChunk): Promise<void>;
  sendText(text: string): Promise<void>;
  interrupt(): Promise<void>;
  onEvent(handler: RealtimeEventHandler): () => void;
  getStatus(): RealtimeStatus;
  getMetrics(): RealtimeMetrics;
}

export class RealtimeBackendError extends Error {
  readonly code: "INVALID_CONFIG" | "NOT_CONNECTED" | "CONNECTION_FAILED" | "PROTOCOL_ERROR" | "SEND_FAILED";

  constructor(
    message: string,
    code: "INVALID_CONFIG" | "NOT_CONNECTED" | "CONNECTION_FAILED" | "PROTOCOL_ERROR" | "SEND_FAILED"
  ) {
    super(message);
    this.name = "RealtimeBackendError";
    this.code = code;
  }
}

export function bytesToBase64(data: Uint8Array): string {
  return Buffer.from(data).toString("base64");
}

export function base64ToBytes(value: string): Uint8Array {
  return new Uint8Array(Buffer.from(value, "base64"));
}

export function resolveRealtimeEndpoint(endpoint: string | undefined, fallback: string): string {
  const value = endpoint?.trim() || fallback;
  if (!/^wss?:\/\//i.test(value)) {
    throw new RealtimeBackendError(`El endpoint Realtime debe usar ws:// o wss://: ${value}`, "INVALID_CONFIG");
  }
  return value;
}
