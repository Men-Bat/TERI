import { describe, expect, it, vi } from "vitest";
import { registerSMS } from "./webhooks";

vi.mock("./db", async (importOriginal) => ({ ...(await importOriginal<typeof import("./db")>()), getTerminatorConfig: vi.fn(async () => ({ twilioAuthToken: "auth-token" })) }));
vi.mock("twilio", () => ({ default: { validateRequest: vi.fn(() => true) } }));

describe("webhook SMS", () => {
  it("responde TwiML vacío de inmediato ante una entrada SMS", async () => {
    let handler: ((req: any, res: any) => Promise<void>) | undefined;
    registerSMS({ post: (_path: string, callback: typeof handler) => { handler = callback; } } as any);
    const res = { set: vi.fn(), send: vi.fn(), sendStatus: vi.fn() };
    await handler!({ body: { From: "+34600000001", Body: "hola" }, get: (name: string) => name === "host" ? "ter-i.example" : name === "x-twilio-signature" ? "signed" : undefined, originalUrl: "/webhook/sms", protocol: "https" }, res);
    expect(res.set).toHaveBeenCalledWith("Content-Type", "text/xml");
    expect(res.send).toHaveBeenCalledWith("<Response></Response>");
  });
});
