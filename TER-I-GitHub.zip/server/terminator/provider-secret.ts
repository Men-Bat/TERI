import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";

const PREFIX = "enc:v1";

export const TERMINATOR_SECRET_FIELDS = [
  "xaiApiKey", "openaiApiKey", "moonshotApiKey", "deepseekApiKey", "geminiApiKey",
  "elevenlabsApiKey", "realtimeCustomApiKey", "googleTranslateApiKey", "deeplApiKey",
  "kokoroApiKey", "twilioAccountSid", "twilioAuthToken", "twilioApiKeySid", "twilioApiKeySecret",
  "whatsappToken", "whatsappVerifyToken", "whatsappAppSecret", "telegramBotToken", "telegramWebhookSecret",
] as const;

function getKey(): Buffer {
  const material = process.env.PROVIDER_ENCRYPTION_KEY || process.env.JWT_SECRET;
  if (!material) throw new Error("Falta PROVIDER_ENCRYPTION_KEY o JWT_SECRET para cifrar proveedores");
  return createHash("sha256").update(material).digest();
}

export function encryptProviderSecret(secret: string): string {
  if (!secret || secret.startsWith(`${PREFIX}:`)) return secret;
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", getKey(), iv);
  const encrypted = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
  return `${PREFIX}:${iv.toString("base64url")}:${cipher.getAuthTag().toString("base64url")}:${encrypted.toString("base64url")}`;
}

export function decryptProviderSecret(value: string): string {
  if (!value.startsWith(`${PREFIX}:`)) return value;
  const [, , ivValue, tagValue, payload] = value.split(":");
  if (!ivValue || !tagValue || !payload) throw new Error("Secreto de proveedor cifrado inválido");
  const decipher = createDecipheriv("aes-256-gcm", getKey(), Buffer.from(ivValue, "base64url"));
  decipher.setAuthTag(Buffer.from(tagValue, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(payload, "base64url")), decipher.final()]).toString("utf8");
}

export function isEncryptedProviderSecret(value: string | null | undefined): boolean {
  return Boolean(value?.startsWith(`${PREFIX}:`));
}

export function encryptTerminatorConfigSecrets<T extends Record<string, unknown>>(data: T): T {
  const next = { ...data } as Record<string, unknown>;
  for (const field of TERMINATOR_SECRET_FIELDS) {
    if (typeof next[field] === "string" && next[field]) next[field] = encryptProviderSecret(next[field] as string);
  }
  return next as T;
}

export function decryptTerminatorConfigSecrets<T extends Record<string, unknown>>(data: T): T {
  const next = { ...data } as Record<string, unknown>;
  for (const field of TERMINATOR_SECRET_FIELDS) {
    if (typeof next[field] === "string" && isEncryptedProviderSecret(next[field] as string)) next[field] = decryptProviderSecret(next[field] as string);
  }
  return next as T;
}
