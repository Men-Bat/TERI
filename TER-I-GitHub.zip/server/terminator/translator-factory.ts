import { DeepLTranslatorAdapter } from "./translator-adapters/deepl";
import { GoogleTranslateAdapter } from "./translator-adapters/google-translate";
import { HttpTranslatorAdapter } from "./translator-adapters/http-translator";
import { TranslatorManager, type TranslatorManagerConfig } from "./translator-manager";

export interface TranslatorFactoryOptions extends TranslatorManagerConfig {
  translatorEndpoint?: string;
  translatorApiKey?: string;
  googleApiKey?: string;
  deeplApiKey?: string;
}

export function createDefaultTranslatorManager(options: TranslatorFactoryOptions = {}): TranslatorManager {
  const activeBackend = options.activeBackend ?? process.env.TERMINATOR_TRANSLATOR_BACKEND ??
    (options.translatorEndpoint ?? process.env.TERMINATOR_LOCAL_TRANSLATOR_URL ? "local-translator" : "google-translate");
  const fallbackBackends = options.fallbackBackends ?? (process.env.TERMINATOR_TRANSLATOR_FALLBACKS ?? "")
    .split(",")
    .map(value => value.trim())
    .filter(Boolean);
  const allowFallback = options.allowFallback ?? process.env.TERMINATOR_TRANSLATOR_ALLOW_FALLBACK === "true";
  const endpoint = options.translatorEndpoint ?? process.env.TERMINATOR_LOCAL_TRANSLATOR_URL;

  const manager = new TranslatorManager({
    activeBackend,
    fallbackBackends,
    allowFallback,
    cacheSize: options.cacheSize,
  });
  if (endpoint) {
    manager.registerBackend(new HttpTranslatorAdapter({
      name: "local-translator",
      kind: "local",
      endpoint,
      apiKey: options.translatorApiKey ?? process.env.TERMINATOR_LOCAL_TRANSLATOR_API_KEY,
    }));
    manager.registerBackend(new HttpTranslatorAdapter({
      name: "custom-translator",
      kind: "custom",
      endpoint,
      apiKey: options.translatorApiKey ?? process.env.TERMINATOR_CUSTOM_TRANSLATOR_API_KEY,
    }));
  }
  manager.registerBackend(new GoogleTranslateAdapter(options.googleApiKey));
  manager.registerBackend(new DeepLTranslatorAdapter(options.deeplApiKey));
  return manager;
}
