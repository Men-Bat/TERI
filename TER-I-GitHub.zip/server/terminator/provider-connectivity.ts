export interface ProviderConnectivityResult {
  reachable: boolean;
  status?: number;
  latencyMs: number;
  error?: string;
}

const RESERVED_HOSTS = new Set(["169.254.169.254", "metadata.google.internal", "metadata.aws.internal"]);

/**
 * Comprueba únicamente la disponibilidad del endpoint. Nunca envía el secreto
 * guardado por el usuario, ni sigue redirecciones hacia destinos inesperados.
 */
export async function checkUserProviderConnectivity(endpoint: string | null | undefined, timeoutMs = 3_000): Promise<ProviderConnectivityResult> {
  if (!endpoint) return { reachable: false, latencyMs: 0, error: "El proveedor no tiene endpoint configurado" };
  let url: URL;
  try {
    url = new URL(endpoint);
  } catch {
    return { reachable: false, latencyMs: 0, error: "Endpoint inválido" };
  }
  if (!["http:", "https:"].includes(url.protocol)) {
    return { reachable: false, latencyMs: 0, error: "La comprobación requiere un endpoint HTTP(S)" };
  }
  if (RESERVED_HOSTS.has(url.hostname.toLowerCase())) {
    return { reachable: false, latencyMs: 0, error: "Endpoint reservado no permitido" };
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const started = Date.now();
  try {
    const response = await fetch(url, { method: "HEAD", signal: controller.signal, redirect: "manual" });
    return { reachable: response.status < 500, status: response.status, latencyMs: Date.now() - started };
  } catch (error) {
    return { reachable: false, latencyMs: Date.now() - started, error: error instanceof Error ? error.message : "No disponible" };
  } finally {
    clearTimeout(timer);
  }
}
