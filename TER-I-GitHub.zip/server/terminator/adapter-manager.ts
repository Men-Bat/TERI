import type { ModelLoadDescriptor } from "./model-loader";

export interface RegisteredAdapter {
  id: number;
  userId: number;
  modelId: number;
  name: string;
  kind: "lora" | "qlora" | "steering" | "custom";
  format: string;
  pathOrUrl: string;
  weight: number;
  enabled: string;
}

export interface AdapterComposition {
  baseModelId: number;
  adapters: Array<{ id: number; name: string; kind: RegisteredAdapter["kind"]; target: string; weight: number }>;
}

export function composeAdapters(model: ModelLoadDescriptor, adapters: RegisteredAdapter[]): AdapterComposition {
  if (model.kind !== "llm") throw new Error("Adapters are only valid for LLM models");
  const active = adapters.filter((adapter) => adapter.enabled === "true");
  const composition = active.map((adapter) => {
    if (adapter.modelId !== model.modelId) throw new Error(`Adapter ${adapter.id} does not belong to model ${model.modelId}`);
    if (!adapter.pathOrUrl || adapter.pathOrUrl.includes("\0") || adapter.pathOrUrl.includes("../")) throw new Error(`Adapter ${adapter.id} has unsafe target`);
    if (!Number.isFinite(adapter.weight) || adapter.weight < -2 || adapter.weight > 2) throw new Error(`Adapter ${adapter.id} has invalid weight`);
    return { id: adapter.id, name: adapter.name, kind: adapter.kind, target: adapter.pathOrUrl, weight: adapter.weight };
  });
  return { baseModelId: model.modelId, adapters: composition };
}
