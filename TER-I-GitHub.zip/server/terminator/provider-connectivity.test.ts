import { afterEach, describe, expect, it, vi } from "vitest";
import { checkUserProviderConnectivity } from "./provider-connectivity";

describe("checkUserProviderConnectivity", () => {
  afterEach(() => vi.unstubAllGlobals());

  it("consulta un endpoint HTTP sin adjuntar cabeceras de autenticación", async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response(null, { status: 405 }));
    vi.stubGlobal("fetch", fetchMock);
    await expect(checkUserProviderConnectivity("http://127.0.0.1:8100/health")).resolves.toMatchObject({ reachable: true, status: 405 });
    expect(fetchMock).toHaveBeenCalledWith(expect.any(URL), expect.objectContaining({ method: "HEAD", redirect: "manual" }));
    expect(fetchMock.mock.calls[0][1]).not.toHaveProperty("headers");
  });

  it("bloquea destinos de metadatos reservados antes de enviar una petición", async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
    await expect(checkUserProviderConnectivity("http://169.254.169.254/latest/meta-data")).resolves.toMatchObject({ reachable: false, error: "Endpoint reservado no permitido" });
    expect(fetchMock).not.toHaveBeenCalled();
  });
});
