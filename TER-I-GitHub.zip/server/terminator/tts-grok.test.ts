import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("../storage", () => ({ storagePut: vi.fn(async () => ({ url: "https://storage.example/audio.mp3" })) }));
vi.mock("nanoid", () => ({ nanoid: () => "fixed-id" }));

import { synthesizeSpeech } from "./tts";

describe("Grok TTS", () => {
  afterEach(() => vi.restoreAllMocks());

  it("usa el contrato actual de xAI y mapea la persona Ani a la voz Ara", async () => {
    const fetchMock = vi.fn(async () => ({ ok: true, arrayBuffer: async () => new Uint8Array([1, 2, 3]).buffer }));
    global.fetch = fetchMock as any;

    await expect(synthesizeSpeech("Hola", { preferredTts: "grok", xaiApiKey: "secret" }, "ani", "es"))
      .resolves.toEqual({ url: "https://storage.example/audio.mp3", backend: "grok-tts" });

    expect(fetchMock).toHaveBeenCalledWith("https://api.x.ai/v1/tts", expect.objectContaining({ method: "POST" }));
    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toEqual({ text: "Hola", voice_id: "ara", language: "es-ES" });
  });

  it("acepta los alias de las cinco voces originales", async () => {
    const fetchMock = vi.fn(async () => ({ ok: true, arrayBuffer: async () => new Uint8Array([1]).buffer }));
    global.fetch = fetchMock as any;

    await synthesizeSpeech("Привет", { preferredTts: "grok", xaiApiKey: "secret" }, "eve", "ru");

    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toMatchObject({ voice_id: "eve", language: "ru" });
  });
});
