import { AddressInfo } from "node:net";
import { describe, expect, it, afterEach } from "vitest";
import { WebSocketServer } from "ws";
import { OpenAIRealtimeAdapter } from "./realtime-adapters/openai-realtime";
import { MoshiRealtimeAdapter } from "./realtime-adapters/moshi-realtime";

const servers: WebSocketServer[] = [];

afterEach(async () => {
  await Promise.all(
    servers.splice(0).map(server => new Promise<void>(resolve => server.close(() => resolve())))
  );
});

async function createServer(onMessage: (socket: WebSocket, payload: Record<string, unknown>) => void): Promise<string> {
  const server = new WebSocketServer({ port: 0 });
  servers.push(server);
  await new Promise<void>(resolve => server.once("listening", () => resolve()));
  server.on("connection", socket => {
    socket.on("message", data => {
      const payload = JSON.parse(data.toString()) as Record<string, unknown>;
      onMessage(socket as unknown as WebSocket, payload);
    });
  });
  const address = server.address() as AddressInfo;
  return `ws://127.0.0.1:${address.port}`;
}

describe("Realtime adapters", () => {
  it("conecta OpenAI Realtime y traduce eventos de texto/audio", async () => {
    const endpoint = await createServer((socket, payload) => {
      if (payload.type === "session.update") {
        socket.send(JSON.stringify({ type: "response.output_text.delta", delta: "hola" }));
        socket.send(JSON.stringify({ type: "response.done" }));
      }
    });
    const adapter = new OpenAIRealtimeAdapter();
    const events: string[] = [];
    adapter.onEvent(event => {
      if (event.type === "transcript" && event.text) events.push(event.text);
      if (event.type === "response") events.push("done");
    });

    await adapter.connect({ endpoint, apiKey: "test-key", language: "es" });
    await adapter.sendText("hola");
    await new Promise(resolve => setTimeout(resolve, 15));
    await adapter.disconnect();

    expect(events).toContain("hola");
    expect(events).toContain("done");
  });

  it("conecta Moshi local mediante el gateway configurable y envía audio base64", async () => {
    const received: Record<string, unknown>[] = [];
    const endpoint = await createServer((socket, payload) => {
      received.push(payload);
      if (payload.type === "session.start") {
        socket.send(JSON.stringify({ type: "transcript", text: "Привет" }));
      }
    });
    const adapter = new MoshiRealtimeAdapter();
    const transcripts: string[] = [];
    adapter.onEvent(event => {
      if (event.type === "transcript" && event.text) transcripts.push(event.text);
    });

    await adapter.connect({ endpoint, language: "ru", sampleRate: 24_000 });
    await adapter.sendAudio({ data: new Uint8Array([1, 2, 3]), sampleRate: 24_000 });
    await new Promise(resolve => setTimeout(resolve, 15));
    await adapter.disconnect();

    expect(received[0]?.type).toBe("session.start");
    expect(received[1]?.type).toBe("audio");
    expect(received[1]?.data).toBe("AQID");
    expect(transcripts).toEqual(["Привет"]);
  });
});


import { ElevenLabsRealtimeAdapter } from "./realtime-adapters/elevenlabs-realtime";
import { GeminiLiveAdapter } from "./realtime-adapters/gemini-live";

describe("Realtime cloud adapters", () => {
  it("mapea respuestas de audio y transcripción de Gemini Live", async () => {
    const endpoint = await createServer((socket, payload) => {
      if (payload.setup) {
        socket.send(JSON.stringify({
          serverContent: {
            modelTurn: { parts: [{ inlineData: { data: "AQI=", mimeType: "audio/pcm" } }] },
            outputTranscription: { text: "respuesta" },
            turnComplete: true,
          },
        }));
      }
    });
    const adapter = new GeminiLiveAdapter();
    const events: string[] = [];
    adapter.onEvent(event => {
      if (event.type === "transcript" && event.text) events.push(event.text);
      if (event.type === "response") events.push("done");
    });

    await adapter.connect({ endpoint, apiKey: "test-key", model: "gemini-test" });
    await adapter.sendText("hola");
    await new Promise(resolve => setTimeout(resolve, 15));
    await adapter.disconnect();

    expect(events).toContain("respuesta");
    expect(events).toContain("done");
  });

  it("mapea audio y respuesta de ElevenLabs Agents", async () => {
    const endpoint = await createServer((socket, payload) => {
      if (payload.type === "conversation_initiation_client_data") {
        socket.send(JSON.stringify({
          type: "audio",
          audio_event: { audio_base_64: "AQI=", event_id: 1 },
        }));
        socket.send(JSON.stringify({
          type: "user_transcript",
          user_transcription_event: { user_transcript: "hola" },
        }));
        socket.send(JSON.stringify({
          type: "agent_response",
          agent_response_event: { agent_response: "respuesta" },
        }));
      }
    });
    const adapter = new ElevenLabsRealtimeAdapter();
    const events: string[] = [];
    adapter.onEvent(event => {
      if (event.type === "transcript" && event.text) events.push(event.text);
      if (event.type === "response" && event.text) events.push(event.text);
    });

    await adapter.connect({ endpoint, apiKey: "test-key" });
    await adapter.sendText("hola");
    await new Promise(resolve => setTimeout(resolve, 15));
    await adapter.disconnect();

    expect(events).toEqual(["hola", "respuesta"]);
  });
});
