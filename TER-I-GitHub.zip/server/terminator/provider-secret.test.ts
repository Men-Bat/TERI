import { describe, expect, it } from "vitest";
import { decryptProviderSecret, decryptTerminatorConfigSecrets, encryptProviderSecret, encryptTerminatorConfigSecrets, isEncryptedProviderSecret } from "./provider-secret";

describe("protección de secretos de proveedores", () => {
  it("cifra secretos de forma no determinista y los recupera solo con la clave del servidor", () => {
    const original = "clave-personal-elevenlabs";
    const first = encryptProviderSecret(original);
    const second = encryptProviderSecret(original);
    expect(first).not.toBe(original);
    expect(first).not.toBe(second);
    expect(isEncryptedProviderSecret(first)).toBe(true);
    expect(decryptProviderSecret(first)).toBe(original);
  });

  it("protege las claves históricas de configuración y conserva los endpoints locales", () => {
    const stored = encryptTerminatorConfigSecrets({ xaiApiKey: "xai-propia", telegramBotToken: "bot-token", telegramWebhookSecret: "telegram-secret", whatsappAppSecret: "meta-secret", ollamaUrl: "http://localhost:11434" });
    expect(stored.xaiApiKey).not.toBe("xai-propia");
    expect(stored.telegramBotToken).not.toBe("bot-token");
    expect(stored.telegramWebhookSecret).not.toBe("telegram-secret");
    expect(stored.whatsappAppSecret).not.toBe("meta-secret");
    expect(stored.ollamaUrl).toBe("http://localhost:11434");
    expect(decryptTerminatorConfigSecrets(stored)).toEqual({ xaiApiKey: "xai-propia", telegramBotToken: "bot-token", telegramWebhookSecret: "telegram-secret", whatsappAppSecret: "meta-secret", ollamaUrl: "http://localhost:11434" });
  });
});
