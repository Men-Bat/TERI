import {
  bytesToBase64,
  base64ToBytes,
  RealtimeBackendError,
  type RealtimeAudioChunk,
  type RealtimeConfig,
} from "../realtime";
import { WebSocketRealtimeAdapter, type WebSocketConnectionOptions } from "./websocket-realtime-base";

/** Adaptador server-to-server para OpenAI Realtime vía WebSocket. */
export class OpenAIRealtimeAdapter extends WebSocketRealtimeAdapter {
  readonly name = "openai-realtime";
  readonly kind = "openai" as const;

  protected buildConnection(config: RealtimeConfig): WebSocketConnectionOptions {
    const model = encodeURIComponent(config.model ?? "gpt-realtime-2.1");
    const apiKey = config.apiKey ?? process.env.OPENAI_API_KEY;
    if (!apiKey) {
      throw new RealtimeBackendError("OPENAI_API_KEY es obligatorio para OpenAI Realtime", "INVALID_CONFIG");
    }
    return {
      url: this.endpoint(config, `wss://api.openai.com/v1/realtime?model=${model}`),
      headers: {
        Authorization: `Bearer ${apiKey}`,
        ...config.headers,
      },
    };
  }

  protected buildAudioEvent(chunk: RealtimeAudioChunk): unknown {
    return {
      type: "input_audio_buffer.append",
      audio: bytesToBase64(chunk.data),
    };
  }

  protected buildTextEvent(text: string): unknown {
    return {
      type: "conversation.item.create",
      item: {
        type: "message",
        role: "user",
        content: [{ type: "input_text", text }],
      },
    };
  }

  protected buildInterruptEvent(): unknown {
    return { type: "response.cancel" };
  }

  protected async sendHandshake(): Promise<void> {
    await this.sendJson({
      type: "session.update",
      session: {
        type: "realtime",
        instructions: this.config.instructions,
        input_audio_format: this.config.inputEncoding === "opus" ? "opus" : "pcm16",
        output_audio_format: this.config.outputEncoding === "opus" ? "opus" : "pcm16",
        modalities: ["text", "audio"],
        ...(this.config.language ? { input_audio_transcription: { language: this.config.language } } : {}),
      },
    });
  }

  protected handleIncoming(raw: string): void {
    const event = this.parseJson(raw);
    if (!event) {
      this.emit({ type: "metadata", data: { raw } });
      return;
    }

    const type = typeof event.type === "string" ? event.type : "unknown";
    const delta = typeof event.delta === "string" ? event.delta : undefined;

    if (type === "response.audio.delta" && delta) {
      this.emit({
        type: "audio",
        audio: {
          data: base64ToBytes(delta),
          sampleRate: 24_000,
          encoding: "pcm16",
        },
        data: event,
      });
      return;
    }

    if (
      type === "response.audio_transcript.delta" ||
      type === "response.output_text.delta" ||
      type === "response.text.delta"
    ) {
      if (delta) this.emit({ type: "transcript", text: delta, data: event });
      return;
    }

    if (type === "conversation.item.input_audio_transcription.completed") {
      const transcript = typeof event.transcript === "string" ? event.transcript : "";
      this.emit({ type: "transcript", text: transcript, data: event });
      return;
    }

    if (type === "response.done") {
      this.emit({ type: "response", data: event });
      return;
    }

    if (type === "error") {
      const errorValue = event.error;
      const message = errorValue && typeof errorValue === "object" && "message" in errorValue
        ? String((errorValue as { message?: unknown }).message ?? "OpenAI Realtime error")
        : "OpenAI Realtime error";
      this.emit({ type: "error", error: message, data: event });
      return;
    }

    this.emit({ type: "metadata", data: event });
  }
}
