import {
  bytesToBase64,
  base64ToBytes,
  RealtimeBackendError,
  type RealtimeAudioChunk,
  type RealtimeConfig,
} from "../realtime";
import { WebSocketRealtimeAdapter, type WebSocketConnectionOptions } from "./websocket-realtime-base";

/** Adaptador opcional para Gemini Live API vía WebSocket. */
export class GeminiLiveAdapter extends WebSocketRealtimeAdapter {
  readonly name = "gemini-live";
  readonly kind = "gemini" as const;

  protected buildConnection(config: RealtimeConfig): WebSocketConnectionOptions {
    const apiKey = config.apiKey ?? process.env.GEMINI_API_KEY;
    const model = config.model ?? "gemini-3.1-flash-live-preview";
    if (!apiKey && !config.endpoint) {
      throw new RealtimeBackendError("GEMINI_API_KEY es obligatorio para Gemini Live", "INVALID_CONFIG");
    }
    const endpoint = config.endpoint ??
      `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=${encodeURIComponent(apiKey!)}`;
    return { url: endpoint, headers: config.headers };
  }

  protected buildAudioEvent(chunk: RealtimeAudioChunk): unknown {
    const sampleRate = chunk.sampleRate ?? this.config.sampleRate ?? 16_000;
    return {
      realtimeInput: {
        audio: {
          data: bytesToBase64(chunk.data),
          mimeType: `audio/pcm;rate=${sampleRate}`,
        },
      },
    };
  }

  protected buildTextEvent(text: string): unknown {
    return { realtimeInput: { text } };
  }

  protected buildInterruptEvent(): unknown {
    return { realtimeInput: { activityEnd: {} } };
  }

  protected async sendHandshake(): Promise<void> {
    await this.sendJson({
      setup: {
        model: `models/${this.config.model ?? "gemini-3.1-flash-live-preview"}`,
        responseModalities: ["AUDIO"],
        ...(this.config.instructions
          ? { systemInstruction: { parts: [{ text: this.config.instructions }] } }
          : {}),
        ...(this.config.language
          ? { outputAudioTranscription: {}, inputAudioTranscription: {} }
          : {}),
      },
    });
  }

  protected handleIncoming(raw: string): void {
    const event = this.parseJson(raw);
    if (!event) {
      this.emit({ type: "metadata", data: { raw } });
      return;
    }

    const serverContent = event.serverContent;
    if (serverContent && typeof serverContent === "object") {
      const content = serverContent as Record<string, unknown>;
      const modelTurn = content.modelTurn;
      if (modelTurn && typeof modelTurn === "object") {
        const parts = (modelTurn as { parts?: unknown }).parts;
        if (Array.isArray(parts)) {
          for (const part of parts) {
            if (!part || typeof part !== "object") continue;
            const inlineData = (part as { inlineData?: unknown }).inlineData;
            if (!inlineData || typeof inlineData !== "object") continue;
            const audioData = (inlineData as { data?: unknown }).data;
            if (typeof audioData === "string") {
              this.emit({
                type: "audio",
                audio: { data: base64ToBytes(audioData), sampleRate: 24_000, encoding: "pcm16" },
                data: event,
              });
            }
          }
        }
      }

      for (const field of ["inputTranscription", "outputTranscription"]) {
        const transcription = content[field];
        if (transcription && typeof transcription === "object" && "text" in transcription) {
          const text = (transcription as { text?: unknown }).text;
          if (typeof text === "string") this.emit({ type: "transcript", text, data: event });
        }
      }

      if (content.turnComplete === true) this.emit({ type: "response", data: event });
      return;
    }

    if (event.error) {
      const error = event.error;
      const message = error && typeof error === "object" && "message" in error
        ? String((error as { message?: unknown }).message ?? "Gemini Live error")
        : "Gemini Live error";
      this.emit({ type: "error", error: message, data: event });
      return;
    }

    this.emit({ type: "metadata", data: event });
  }
}
