import WebSocket from "ws";
import {
  RealtimeBackendError,
  type RealtimeBackend,
  type RealtimeBackendKind,
  type RealtimeAudioChunk,
  type RealtimeConfig,
  type RealtimeEvent,
  type RealtimeEventHandler,
  type RealtimeMetrics,
  type RealtimeStatus,
  resolveRealtimeEndpoint,
} from "../realtime";

export interface WebSocketConnectionOptions {
  url: string;
  headers?: Record<string, string>;
  protocols?: string | string[];
}

/** Base común para backends Realtime transportados por WebSocket. */
export abstract class WebSocketRealtimeAdapter implements RealtimeBackend {
  protected socket: WebSocket | null = null;
  protected config: RealtimeConfig = {};
  protected status: RealtimeStatus;
  protected metrics: RealtimeMetrics = {
    sentAudioChunks: 0,
    receivedAudioChunks: 0,
    sentTextMessages: 0,
    receivedTranscripts: 0,
    receivedResponses: 0,
    errorCount: 0,
    averageLatencyMs: null,
  };
  private readonly handlers = new Set<RealtimeEventHandler>();
  private requestStartedAt: number | null = null;

  abstract readonly name: string;
  abstract readonly kind: RealtimeBackendKind;

  constructor() {
    this.status = {
      state: "disconnected",
      backend: "realtime",
      latencyMs: null,
      lastError: null,
      connectedAt: null,
    };
  }

  async connect(config: RealtimeConfig = {}): Promise<void> {
    if (this.socket && this.status.state === "connected") return;
    this.config = { ...this.config, ...config };
    this.status = { ...this.status, state: "connecting", lastError: null };

    let connection: WebSocketConnectionOptions;
    try {
      connection = this.buildConnection(this.config);
    } catch (error) {
      this.fail(error);
      throw error;
    }

    await new Promise<void>((resolve, reject) => {
      const socket = new WebSocket(connection.url, connection.protocols, {
        headers: connection.headers,
      });
      this.socket = socket;
      const timeout = setTimeout(() => {
        socket.terminate();
        const error = new RealtimeBackendError(`Timeout conectando a ${this.name}`, "CONNECTION_FAILED");
        this.fail(error);
        reject(error);
      }, 10_000);

      socket.once("open", () => {
        clearTimeout(timeout);
        this.status = {
          ...this.status,
          state: "connected",
          connectedAt: Date.now(),
          lastError: null,
        };
        this.emit({ type: "connected", data: { backend: this.name } });
        void this.sendHandshake().then(resolve).catch(reject);
      });

      socket.on("message", data => {
        try {
          this.handleIncoming(this.rawToText(data));
        } catch (error) {
          this.fail(error);
        }
      });

      socket.on("error", error => {
        clearTimeout(timeout);
        this.fail(error);
        if (this.status.state === "connecting") reject(error);
      });

      socket.once("close", () => {
        clearTimeout(timeout);
        const wasConnected = this.status.state === "connected";
        this.status = { ...this.status, state: "disconnected" };
        this.socket = null;
        if (wasConnected) this.emit({ type: "disconnected", data: { backend: this.name } });
        if (this.status.state === "connecting") {
          reject(new RealtimeBackendError(`La conexión Realtime se cerró: ${this.name}`, "CONNECTION_FAILED"));
        }
      });
    });
  }

  async disconnect(): Promise<void> {
    const socket = this.socket;
    if (!socket) return;
    await new Promise<void>(resolve => {
      socket.once("close", () => resolve());
      socket.close(1000, "client disconnect");
      setTimeout(() => {
        socket.terminate();
        resolve();
      }, 1_000);
    });
    this.status = { ...this.status, state: "disconnected" };
    this.socket = null;
  }

  async sendAudio(chunk: RealtimeAudioChunk): Promise<void> {
    this.ensureConnected();
    this.metrics.sentAudioChunks += 1;
    this.requestStartedAt ??= Date.now();
    await this.sendJson(this.buildAudioEvent(chunk));
  }

  async sendText(text: string): Promise<void> {
    if (!text.trim()) throw new RealtimeBackendError("El texto Realtime no puede estar vacío", "INVALID_CONFIG");
    this.ensureConnected();
    this.metrics.sentTextMessages += 1;
    this.requestStartedAt ??= Date.now();
    await this.sendJson(this.buildTextEvent(text));
  }

  async interrupt(): Promise<void> {
    this.ensureConnected();
    await this.sendJson(this.buildInterruptEvent());
    this.emit({ type: "interrupted", data: { backend: this.name } });
  }

  onEvent(handler: RealtimeEventHandler): () => void {
    this.handlers.add(handler);
    return () => this.handlers.delete(handler);
  }

  getStatus(): RealtimeStatus {
    return { ...this.status };
  }

  getMetrics(): RealtimeMetrics {
    return { ...this.metrics };
  }

  protected abstract buildConnection(config: RealtimeConfig): WebSocketConnectionOptions;
  protected abstract buildAudioEvent(chunk: RealtimeAudioChunk): unknown;
  protected abstract buildTextEvent(text: string): unknown;
  protected abstract buildInterruptEvent(): unknown;
  protected abstract sendHandshake(): Promise<void>;
  protected abstract handleIncoming(raw: string): void;

  protected emit(event: RealtimeEvent): void {
    if (event.type === "audio") this.metrics.receivedAudioChunks += 1;
    if (event.type === "transcript") this.metrics.receivedTranscripts += 1;
    if (event.type === "response") this.metrics.receivedResponses += 1;
    if (event.type === "response" && this.requestStartedAt !== null) {
      const latencyMs = Date.now() - this.requestStartedAt;
      this.status = { ...this.status, latencyMs };
      this.metrics.averageLatencyMs = this.metrics.averageLatencyMs === null
        ? latencyMs
        : (this.metrics.averageLatencyMs + latencyMs) / 2;
      this.requestStartedAt = null;
    }
    for (const handler of Array.from(this.handlers)) handler(event);
  }

  protected parseJson(raw: string): Record<string, unknown> | null {
    try {
      const parsed: unknown = JSON.parse(raw);
      return parsed && typeof parsed === "object" ? (parsed as Record<string, unknown>) : null;
    } catch {
      return null;
    }
  }

  protected ensureConnected(): void {
    if (!this.socket || this.status.state !== "connected") {
      throw new RealtimeBackendError(`Backend Realtime no conectado: ${this.name}`, "NOT_CONNECTED");
    }
  }

  protected async sendJson(payload: unknown): Promise<void> {
    this.ensureConnected();
    await new Promise<void>((resolve, reject) => {
      this.socket!.send(JSON.stringify(payload), error => (error ? reject(error) : resolve()));
    });
  }

  protected endpoint(config: RealtimeConfig, fallback: string): string {
    return resolveRealtimeEndpoint(config.endpoint, fallback);
  }

  private rawToText(data: unknown): string {
    if (typeof data === "string") return data;
    if (Buffer.isBuffer(data)) return data.toString("utf8");
    if (data instanceof ArrayBuffer) return Buffer.from(data).toString("utf8");
    return String(data);
  }

  private fail(error: unknown): void {
    const message = error instanceof Error ? error.message : String(error);
    this.metrics.errorCount += 1;
    this.status = { ...this.status, state: "error", lastError: message };
    this.emit({ type: "error", error: message, data: { backend: this.name } });
  }
}
