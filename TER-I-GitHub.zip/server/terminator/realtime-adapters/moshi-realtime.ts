import {
  bytesToBase64,
  base64ToBytes,
  RealtimeBackendError,
  type RealtimeAudioChunk,
  type RealtimeConfig,
} from "../realtime";
import { WebSocketRealtimeAdapter, type WebSocketConnectionOptions } from "./websocket-realtime-base";

/**
 * Adaptador local para Moshi.
 *
 * Moshi se ejecuta localmente con su servidor oficial; este adaptador habla con
 * un gateway WebSocket configurable (`MOSHI_REALTIME_URL`) que expone el
 * contrato pequeño de Terminator II. No se asume que el UI Gradio oficial sea
 * una API pública estable.
 */
export class MoshiRealtimeAdapter extends WebSocketRealtimeAdapter {
  readonly name = "moshi-local";
  readonly kind = "moshi" as const;

  protected buildConnection(config: RealtimeConfig): WebSocketConnectionOptions {
    return {
      url: this.endpoint(config, process.env.MOSHI_REALTIME_URL ?? "ws://localhost:8998/ws"),
      headers: config.headers,
    };
  }

  protected buildAudioEvent(chunk: RealtimeAudioChunk): unknown {
    return {
      type: "audio",
      data: bytesToBase64(chunk.data),
      encoding: chunk.encoding ?? "pcm16",
      sample_rate: chunk.sampleRate ?? this.config.sampleRate ?? 24_000,
      final: chunk.isFinal ?? false,
    };
  }

  protected buildTextEvent(text: string): unknown {
    return { type: "text", text };
  }

  protected buildInterruptEvent(): unknown {
    return { type: "interrupt" };
  }

  protected async sendHandshake(): Promise<void> {
    await this.sendJson({
      type: "session.start",
      model: this.config.model,
      language: this.config.language,
      sample_rate: this.config.sampleRate ?? 24_000,
      instructions: this.config.instructions,
      metadata: this.config.metadata,
    });
  }

  protected handleIncoming(raw: string): void {
    const event = this.parseJson(raw);
    if (!event) {
      this.emit({ type: "metadata", data: { raw } });
      return;
    }

    const type = typeof event.type === "string" ? event.type : "unknown";
    const data = typeof event.data === "string" ? event.data : undefined;
    const text = typeof event.text === "string" ? event.text : undefined;

    if ((type === "audio" || type === "audio.delta") && data) {
      this.emit({
        type: "audio",
        audio: {
          data: base64ToBytes(data),
          sampleRate: typeof event.sample_rate === "number" ? event.sample_rate : 24_000,
          encoding: "pcm16",
          isFinal: event.final === true,
        },
        data: event,
      });
      return;
    }

    if (type === "transcript" || type === "transcript.delta" || type === "text.delta") {
      if (text) this.emit({ type: "transcript", text, data: event });
      return;
    }

    if (type === "response" || type === "response.done" || type === "done") {
      this.emit({ type: "response", text, data: event });
      return;
    }

    if (type === "error") {
      const message = typeof event.error === "string" ? event.error : "Moshi gateway error";
      this.emit({ type: "error", error: message, data: event });
      return;
    }

    this.emit({ type: "metadata", data: event });
  }
}
