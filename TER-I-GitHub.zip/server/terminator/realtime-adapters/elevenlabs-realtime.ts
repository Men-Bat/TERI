import {
  bytesToBase64,
  base64ToBytes,
  RealtimeBackendError,
  type RealtimeAudioChunk,
  type RealtimeConfig,
} from "../realtime";
import { WebSocketRealtimeAdapter, type WebSocketConnectionOptions } from "./websocket-realtime-base";

/** Adaptador opcional para ElevenLabs ElevenAgents por WebSocket. */
export class ElevenLabsRealtimeAdapter extends WebSocketRealtimeAdapter {
  readonly name = "elevenlabs-agents";
  readonly kind = "elevenlabs" as const;

  protected buildConnection(config: RealtimeConfig): WebSocketConnectionOptions {
    const agentId = typeof config.metadata?.agentId === "string"
      ? config.metadata.agentId
      : process.env.ELEVENLABS_AGENT_ID;
    const endpoint = config.endpoint ?? process.env.ELEVENLABS_REALTIME_URL;
    const url = endpoint ?? (agentId
      ? `wss://api.elevenlabs.io/v1/convai/conversation?agent_id=${encodeURIComponent(agentId)}`
      : undefined);
    if (!url) {
      throw new RealtimeBackendError(
        "ElevenLabs requiere ELEVENLABS_AGENT_ID o una signed URL en endpoint",
        "INVALID_CONFIG"
      );
    }

    return {
      url,
      headers: {
        ...(config.apiKey ? { "xi-api-key": config.apiKey } : {}),
        ...config.headers,
      },
    };
  }

  protected buildAudioEvent(chunk: RealtimeAudioChunk): unknown {
    return { user_audio_chunk: bytesToBase64(chunk.data) };
  }

  protected buildTextEvent(text: string): unknown {
    return { type: "user_message", text };
  }

  protected buildInterruptEvent(): unknown {
    return { type: "user_activity" };
  }

  protected async sendHandshake(): Promise<void> {
    await this.sendJson({
      type: "conversation_initiation_client_data",
      conversation_config_override: {
        agent: {
          ...(this.config.language ? { language: this.config.language } : {}),
          ...(this.config.instructions ? { prompt: { prompt: this.config.instructions } } : {}),
        },
      },
    });
  }

  protected handleIncoming(raw: string): void {
    const event = this.parseJson(raw);
    if (!event) {
      this.emit({ type: "metadata", data: { raw } });
      return;
    }

    const type = typeof event.type === "string" ? event.type : "unknown";
    if (type === "audio") {
      const audioEvent = event.audio_event;
      const audioBase64 = audioEvent && typeof audioEvent === "object" && "audio_base_64" in audioEvent
        ? (audioEvent as { audio_base_64?: unknown }).audio_base_64
        : undefined;
      if (typeof audioBase64 === "string") {
        this.emit({
          type: "audio",
          audio: { data: base64ToBytes(audioBase64), sampleRate: 16_000, encoding: "pcm16" },
          data: event,
        });
      }
      return;
    }

    if (type === "user_transcript") {
      const transcript = event.user_transcription_event;
      const text = transcript && typeof transcript === "object" && "user_transcript" in transcript
        ? (transcript as { user_transcript?: unknown }).user_transcript
        : undefined;
      if (typeof text === "string") this.emit({ type: "transcript", text, data: event });
      return;
    }

    if (type === "agent_response") {
      const response = event.agent_response_event;
      const text = response && typeof response === "object" && "agent_response" in response
        ? (response as { agent_response?: unknown }).agent_response
        : undefined;
      if (typeof text === "string") this.emit({ type: "response", text, data: event });
      return;
    }

    if (type === "ping") {
      const ping = event.ping_event;
      const eventId = ping && typeof ping === "object" && "event_id" in ping
        ? (ping as { event_id?: unknown }).event_id
        : undefined;
      void this.sendJson({ type: "pong", event_id: eventId });
      return;
    }

    this.emit({ type: "metadata", data: event });
  }
}
