import { afterEach, describe, expect, it, vi } from "vitest";
import { DeepLTranslatorAdapter } from "./translator-adapters/deepl";
import { GoogleTranslateAdapter } from "./translator-adapters/google-translate";
import { HttpTranslatorAdapter } from "./translator-adapters/http-translator";

const originalEnv = { ...process.env };

afterEach(() => {
  vi.unstubAllGlobals();
  process.env = { ...originalEnv };
});

describe("Translator adapters", () => {
  it("consume la respuesta de Google Translate", async () => {
    process.env.GOOGLE_TRANSLATE_API_KEY = "google-test";
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({
      data: { translations: [{ translatedText: "Hola", detectedSourceLanguage: "en" }] },
    }), { status: 200, headers: { "content-type": "application/json" } })));

    const result = await new GoogleTranslateAdapter().translate({ text: "Hello", sourceLanguage: "en", targetLanguage: "es" });

    expect(result.text).toBe("Hola");
    expect(result.sourceLanguage).toBe("en");
  });

  it("consume la respuesta form-urlencoded de DeepL", async () => {
    process.env.DEEPL_API_KEY = "deepl-test";
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({
      translations: [{ text: "Hola", detected_source_language: "EN" }],
    }), { status: 200, headers: { "content-type": "application/json" } })));

    const result = await new DeepLTranslatorAdapter().translate({ text: "Hello", sourceLanguage: "en", targetLanguage: "es" });

    expect(result.text).toBe("Hola");
    expect(result.backend).toBe("deepl");
  });

  it("consume una respuesta local/custom compatible con Alia, NLLB o Marian", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({ translatedText: "Hola local" }), { status: 200 })));
    const adapter = new HttpTranslatorAdapter({ name: "alia-local", kind: "local", endpoint: "http://localhost:8000/translate" });

    const result = await adapter.translate({ text: "Hello", sourceLanguage: "en", targetLanguage: "es" });

    expect(result.text).toBe("Hola local");
    expect(result.backend).toBe("alia-local");
  });
});
