/**
 * Terminator II — Express Webhook Routes
 *
 * Registers raw Express routes for:
 *   POST /webhook/whatsapp   — WhatsApp Business API
 *   GET  /webhook/whatsapp   — WhatsApp verification challenge
 *   POST /webhook/telegram   — Telegram Bot
 *   POST /webhook/sms        — Twilio SMS/MMS
 *   POST /twiml              — Twilio Voice (ConversationRelay TwiML)
 *   WS   /ws/voice           — Twilio ConversationRelay WebSocket
 *   POST /webhook/video/token — Twilio Video room token
 */

import type { Express, Request, Response } from "express";
import { WebSocketServer, WebSocket } from "ws";
import type { Server } from "http";
import { createHmac, timingSafeEqual } from "crypto";
import twilio from "twilio";
import { getTerminatorConfig } from "./db";
import { processMessage } from "./orchestrator";
import {
  parseWhatsAppWebhook,
  sendWhatsAppMessage,
  parseTelegramWebhook,
  sendTelegramMessage,
  parseTwilioSMS,
  sendTwilioSMS,
  type WhatsAppWebhookBody,
  type TelegramWebhookBody,
  type TwilioSMSBody,
} from "./channels";
import { callLLM } from "./llm";
import {
  synthesizeSpeech,
  getKokoroVoices,
  getKokoroModels,
  isKokoroLocalUrl,
} from "./tts";
import { createDefaultRealtimeManager } from "./realtime-factory";
import { base64ToBytes, type RealtimeConfig, type RealtimeEvent } from "./realtime";
import { consumeRealtimeTicket } from "./realtime-session-store";

// Owner user ID = 1 (first user, the owner of the Terminator instance)
const OWNER_USER_ID = 1;

type RawBodyRequest = Request & { rawBody?: Buffer };

export function verifyWhatsAppSignature(req: RawBodyRequest, appSecret: string | null | undefined): boolean {
  const received = req.get("x-hub-signature-256");
  if (!appSecret || !received || !req.rawBody) return false;
  const expected = `sha256=${createHmac("sha256", appSecret).update(req.rawBody).digest("hex")}`;
  const expectedBuffer = Buffer.from(expected);
  const receivedBuffer = Buffer.from(received);
  return expectedBuffer.length === receivedBuffer.length && timingSafeEqual(expectedBuffer, receivedBuffer);
}

export function getCanonicalWebhookUrl(req: Request): string {
  const protocol = req.get("x-forwarded-proto")?.split(",")[0]?.trim() || req.protocol || "https";
  const host = req.get("host");
  if (!host) return "";
  return `${protocol}://${host}${req.originalUrl || req.url || ""}`;
}

export function verifyTwilioSignature(req: Request, authToken: string | null | undefined): boolean {
  const signature = req.get("x-twilio-signature");
  const url = getCanonicalWebhookUrl(req);
  if (!authToken || !signature || !url) return false;
  return twilio.validateRequest(authToken, signature, url, req.body as Record<string, string>);
}

// ─── WhatsApp ─────────────────────────────────────────────────────────────────

export function registerWhatsApp(app: Express) {
  // Verification challenge
  app.get("/webhook/whatsapp", async (req: Request, res: Response) => {
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];

    const cfg = await getTerminatorConfig(OWNER_USER_ID);
    if (mode === "subscribe" && challenge && cfg?.whatsappVerifyToken && token === cfg.whatsappVerifyToken) {
      console.log("[WhatsApp] Webhook verified");
      res.status(200).send(challenge);
    } else {
      res.sendStatus(403);
    }
  });

  app.post("/webhook/whatsapp", async (req: Request, res: Response) => {
    try {
      const cfg = await getTerminatorConfig(OWNER_USER_ID);
      if (!verifyWhatsAppSignature(req as RawBodyRequest, cfg?.whatsappAppSecret)) {
        res.sendStatus(401);
        return;
      }
      res.sendStatus(200); // Acknowledge only after signature validation
      const body = req.body as WhatsAppWebhookBody;
      const msg = parseWhatsAppWebhook(body);
      if (!msg) return;

      const result = await processMessage(msg, cfg, { withAudio: true });

      const from = msg.channelId.replace("whatsapp:", "");
      if (cfg?.whatsappToken && cfg?.whatsappPhoneNumberId) {
        await sendWhatsAppMessage(from, cfg.whatsappPhoneNumberId, cfg.whatsappToken, {
          text: result.text,
          audioUrl: result.audioUrl ?? undefined,
          videoUrl: result.videoUrl ?? undefined,
        });
      }
    } catch (err) {
      console.error("[WhatsApp] Webhook error:", err);
    }
  });
}

// ─── Telegram ─────────────────────────────────────────────────────────────────

export function registerTelegram(app: Express) {
  app.post("/webhook/telegram", async (req: Request, res: Response) => {
    try {
      const cfg = await getTerminatorConfig(OWNER_USER_ID);
      if (!cfg?.telegramWebhookSecret || req.get("x-telegram-bot-api-secret-token") !== cfg.telegramWebhookSecret) {
        res.sendStatus(401);
        return;
      }
      res.sendStatus(200);
      const body = req.body as TelegramWebhookBody;
      const msg = parseTelegramWebhook(body);
      if (!msg) return;

      const result = await processMessage(msg, cfg, { withAudio: true });

      const chatId = msg.channelId.replace("telegram:", "");
      if (cfg?.telegramBotToken) {
        await sendTelegramMessage(chatId, cfg.telegramBotToken, {
          text: result.text,
          audioUrl: result.audioUrl ?? undefined,
          videoUrl: result.videoUrl ?? undefined,
        });
      }
    } catch (err) {
      console.error("[Telegram] Webhook error:", err);
    }
  });
}

// ─── SMS/MMS (Twilio) ─────────────────────────────────────────────────────────

export function registerSMS(app: Express) {
  app.post("/webhook/sms", async (req: Request, res: Response) => {
    try {
      const cfg = await getTerminatorConfig(OWNER_USER_ID);
      if (!verifyTwilioSignature(req, cfg?.twilioAuthToken)) {
        res.sendStatus(401);
        return;
      }
      res.set("Content-Type", "text/xml");
      res.send("<Response></Response>"); // Acknowledge after signature validation
      const body = req.body as TwilioSMSBody;
      const msg = parseTwilioSMS(body);
      if (!msg) return;

      const result = await processMessage(msg, cfg, { withAudio: false });

      const to = msg.channelId.replace("sms:", "");
      if (cfg?.twilioAccountSid && cfg?.twilioAuthToken && cfg?.twilioPhoneNumber) {
        await sendTwilioSMS(to, cfg.twilioPhoneNumber, cfg.twilioAccountSid, cfg.twilioAuthToken, {
          text: result.text,
          imageUrl: undefined, // MMS image only in US/CA
          videoUrl: result.videoUrl ?? undefined,
        });
      }
    } catch (err) {
      console.error("[SMS] Webhook error:", err);
    }
  });
}

// ─── Twilio Voice (ConversationRelay) ─────────────────────────────────────────

function registerVoice(app: Express) {
  // TwiML endpoint: tells Twilio to connect to our WebSocket
  app.post("/twiml", async (req: Request, res: Response) => {
    const cfg = await getTerminatorConfig(OWNER_USER_ID);
    if (!verifyTwilioSignature(req, cfg?.twilioAuthToken)) {
      res.sendStatus(401);
      return;
    }
    const host = req.headers.host ?? "localhost";
    const wsUrl = `wss://${host}/ws/voice`;
    res.set("Content-Type", "text/xml");
    res.send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Connect>
    <ConversationRelay url="${wsUrl}" welcomeGreeting="Hola, soy el Terminator. ¿En qué puedo ayudarte?" ttsProvider="Google" voice="es-ES-Standard-A" language="es-ES" />
  </Connect>
</Response>`);
  });
}

// ─── Twilio Video token ───────────────────────────────────────────────────────

function registerVideo(app: Express) {
  app.post("/webhook/video/token", async (req: Request, res: Response) => {
    try {
      const cfg = await getTerminatorConfig(OWNER_USER_ID);
      if (!cfg?.twilioAccountSid || !cfg?.twilioAuthToken) {
        res.status(503).json({ error: "Twilio not configured" });
        return;
      }

      const roomName = (req.body as { roomName?: string }).roomName ?? `terminator-${Date.now()}`;
      const identity = (req.body as { identity?: string }).identity ?? "user";

      // Generate Twilio Video Access Token
      // Using Twilio's REST API to create a room token
      const { AccessToken } = await import("twilio").then((m) => m.jwt);
      const { VideoGrant } = AccessToken;

      const apiKey = cfg.twilioAccountSid;
      const apiSecret = cfg.twilioAuthToken;

      const token = new AccessToken(cfg.twilioAccountSid, apiKey, apiSecret, {
        identity,
        ttl: 3600,
      });
      const grant = new VideoGrant({ room: roomName });
      token.addGrant(grant);

      res.json({ token: token.toJwt(), roomName, identity });
    } catch (err) {
      console.error("[Video] Token error:", err);
      res.status(500).json({ error: "Failed to generate token" });
    }
  });
}

// ─── WebSocket: Twilio ConversationRelay ──────────────────────────────────────

interface VoiceSession {
  callSid: string;
  history: Array<{ role: "user" | "assistant"; content: string }>;
}

function registerVoiceWebSocket(server: Server) {
  const wss = new WebSocketServer({ server, path: "/ws/voice" });

  wss.on("connection", (ws: WebSocket) => {
    let session: VoiceSession | null = null;

    ws.on("message", async (data: Buffer) => {
      try {
        const msg = JSON.parse(data.toString()) as {
          type: string;
          callSid?: string;
          voicePrompt?: string;
        };

        if (msg.type === "setup") {
          session = { callSid: msg.callSid ?? "unknown", history: [] };
          console.log(`[Voice WS] Call started: ${session.callSid}`);
        } else if (msg.type === "prompt" && session && msg.voicePrompt) {
          const cfg = await getTerminatorConfig(OWNER_USER_ID);
          session.history.push({ role: "user", content: msg.voicePrompt });

          const llmResult = await callLLM(
            session.history,
            {
              ollamaUrl: cfg?.ollamaUrl ?? "http://localhost:11434",
              lmstudioUrl: cfg?.lmstudioUrl ?? "http://localhost:1234",
              xaiApiKey: cfg?.xaiApiKey ?? undefined,
              openaiApiKey: cfg?.openaiApiKey ?? undefined,
              moonshotApiKey: cfg?.moonshotApiKey ?? undefined,
              deepseekApiKey: cfg?.deepseekApiKey ?? undefined,
              preferredBackend: cfg?.defaultLlm ?? "auto",
            },
            cfg?.defaultPersona ?? "default",
            false // no multimodal in voice calls
          );

          session.history.push({ role: "assistant", content: llmResult.text });

          ws.send(
            JSON.stringify({
              type: "text",
              token: llmResult.text,
              last: true,
            })
          );
        } else if (msg.type === "interrupt") {
          console.log(`[Voice WS] Interrupted: ${session?.callSid}`);
        }
      } catch (err) {
        console.error("[Voice WS] Error:", err);
      }
    });

    ws.on("close", () => {
      console.log(`[Voice WS] Call ended: ${session?.callSid}`);
    });
  });

  console.log("[Voice WS] ConversationRelay WebSocket registered at /ws/voice");
}

// ─── Generic Realtime WebSocket ────────────────────────────────────────────────

function serializeRealtimeEvent(event: RealtimeEvent): Record<string, unknown> {
  return {
    type: event.type,
    text: event.text,
    error: event.error,
    data: event.data,
    audio: event.audio
      ? {
          data: Buffer.from(event.audio.data).toString("base64"),
          encoding: event.audio.encoding,
          sampleRate: event.audio.sampleRate,
          isFinal: event.audio.isFinal,
        }
      : undefined,
  };
}

export function buildSecureRealtimeConfig(
  sessionConfig: RealtimeConfig | null,
  clientConfig: RealtimeConfig,
): RealtimeConfig {
  return {
    ...(sessionConfig ?? {}),
    ...clientConfig,
    // El cliente nunca puede inyectar ni reemplazar una credencial o el backend bloqueado.
    apiKey: sessionConfig?.apiKey,
    metadata: sessionConfig?.metadata,
  };
}

function registerRealtimeWebSocket(server: Server) {
  const wss = new WebSocketServer({ server, path: "/ws/realtime" });

  wss.on("connection", ws => {
    const manager = createDefaultRealtimeManager();
    let sessionConfig: RealtimeConfig | null = null;
    let lockedBackend: string | null = null;
    const unsubscribe = manager.onEvent(event => {
      if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(serializeRealtimeEvent(event)));
    });

    ws.on("message", async data => {
      try {
        const message = JSON.parse(data.toString()) as {
          type?: string;
          ticket?: string;
          backend?: string;
          text?: string;
          data?: string;
          encoding?: "pcm16" | "opus" | "base64";
          sampleRate?: number;
          final?: boolean;
          config?: RealtimeConfig;
        };

        if (message.type === "start") {
          if (message.ticket) {
            sessionConfig = consumeRealtimeTicket(message.ticket);
            if (!sessionConfig) throw new Error("Ticket Realtime inválido, usado o expirado");
            const configuredBackend = sessionConfig.metadata?.backend;
            lockedBackend = typeof configuredBackend === "string" ? configuredBackend : null;
          }
          if (message.backend && lockedBackend && message.backend !== lockedBackend) {
            throw new Error("El backend solicitado no coincide con el ticket Realtime");
          }
          const selectedBackend = message.backend ?? lockedBackend;
          if (selectedBackend) manager.selectBackend(selectedBackend);
          const config = buildSecureRealtimeConfig(sessionConfig, message.config ?? {});
          const backend = await manager.connect(config);
          ws.send(JSON.stringify({ type: "ready", backend: backend.name, status: manager.getStatus() }));
          return;
        }

        if (message.type === "audio") {
          if (!message.data) throw new Error("Falta data base64 en el mensaje de audio");
          await manager.sendAudio({
            data: base64ToBytes(message.data),
            encoding: message.encoding ?? "pcm16",
            sampleRate: message.sampleRate,
            isFinal: message.final,
          });
          return;
        }

        if (message.type === "text") {
          await manager.sendText(message.text ?? "");
          return;
        }

        if (message.type === "interrupt") {
          await manager.interrupt();
          return;
        }

        if (message.type === "status") {
          ws.send(JSON.stringify({ type: "status", status: manager.getStatus(), metrics: manager.getMetrics() }));
          return;
        }

        throw new Error(`Tipo de mensaje Realtime no soportado: ${message.type ?? "undefined"}`);
      } catch (error) {
        const message = error instanceof Error ? error.message : "Error Realtime";
        if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "error", error: message }));
      }
    });

    ws.once("close", () => {
      unsubscribe();
      void manager.disconnect();
    });
  });

  console.log("[Realtime] WebSocket registered at /ws/realtime");
}

// ─── Audio upload endpoint (for video-call page STT) ─────────────────────────────────────────────────────────────────────────────────────

import multer from "multer";
import { storagePut } from "../storage";
import { nanoid } from "nanoid";

function registerAudioUpload(app: Express) {
  // multer stores file in memory (max 16 MB)
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 16 * 1024 * 1024 } });

  app.post("/api/terminator/upload-audio", upload.single("audio"), async (req: Request, res: Response) => {
    try {
      const file = (req as Request & { file?: { buffer: Buffer; originalname: string; mimetype: string; size: number } }).file;
      if (!file) {
        res.status(400).json({ error: "No audio file provided" });
        return;
      }
      const key = `terminator-audio/${nanoid()}.webm`;
      const { url } = await storagePut(key, new Uint8Array(file.buffer), "audio/webm");
      res.json({ url });
    } catch (err) {
      console.error("[AudioUpload] Error:", err);
      res.status(500).json({ error: "Upload failed" });
    }
  });

  console.log("[Terminator] Audio upload endpoint registered at /api/terminator/upload-audio");
}

// ─── Kokoro metadata proxy ──────────────────────────────────────────────────────────────────────────────────

export function registerKokoroMetadata(app: Express) {
  const resolveConfig = async () => {
    const config = await getTerminatorConfig(OWNER_USER_ID);
    return {
      url: config?.kokoroUrl ?? process.env.KOKORO_URL ?? "http://localhost:8880",
      apiKey: config?.kokoroApiKey ?? process.env.KOKORO_API_KEY,
      localOnly: config?.kokoroLocalOnly === "true" || process.env.KOKORO_LOCAL_ONLY === "true",
    };
  };

  const proxy = async (kind: "voices" | "models", _req: Request, res: Response) => {
    try {
      const config = await resolveConfig();
      if (config.localOnly && !isKokoroLocalUrl(config.url)) {
        res.status(503).json({
          error: "Kokoro local-only policy blocked the configured endpoint",
          localOnly: true,
        });
        return;
      }
      const payload = kind === "voices"
        ? await getKokoroVoices(config.url, config.apiKey)
        : await getKokoroModels(config.url, config.apiKey);
      res.status(200).json({ backend: "kokoro", localOnly: config.localOnly, ...payload });
    } catch (error) {
      res.status(502).json({
        error: "Kokoro metadata unavailable",
        detail: error instanceof Error ? error.message : "Unknown error",
      });
    }
  };

  app.get("/api/terminator/kokoro/voices", (req, res) => proxy("voices", req, res));
  app.get("/api/terminator/kokoro/models", (req, res) => proxy("models", req, res));
  app.get("/api/terminator/kokoro/health", async (_req, res) => {
    try {
      const config = await resolveConfig();
      if (config.localOnly && !isKokoroLocalUrl(config.url)) {
        res.status(503).json({ status: "blocked", backend: "kokoro", localOnly: true });
        return;
      }
      const models = await getKokoroModels(config.url, config.apiKey);
      res.status(200).json({
        status: "ok",
        backend: "kokoro",
        localOnly: config.localOnly,
        capabilities: ["speech", "voices", "models", "sse", "volume_multiplier"],
        models,
      });
    } catch (error) {
      res.status(502).json({
        status: "unavailable",
        backend: "kokoro",
        detail: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });
  console.log("[Terminator] Kokoro metadata proxy registered at /api/terminator/kokoro/{health,voices,models}");
}

// ─── Main registration ──────────────────────────────────────────────────────────────────────────────────────

export function registerTerminatorWebhooks(app: Express, server: Server) {
  registerWhatsApp(app);
  registerTelegram(app);
  registerSMS(app);
  registerVoice(app);
  registerVideo(app);
  registerVoiceWebSocket(server);
  registerRealtimeWebSocket(server);
  registerAudioUpload(app);
  registerKokoroMetadata(app);
  console.log("[Terminator] Webhooks registered");
}
