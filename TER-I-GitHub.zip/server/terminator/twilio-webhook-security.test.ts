import { describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ validateRequest: vi.fn() }));
vi.mock("twilio", () => ({ default: { validateRequest: mocks.validateRequest } }));

import { getCanonicalWebhookUrl, verifyTwilioSignature } from "./webhooks";

describe("seguridad de webhook Twilio", () => {
  it("construye una URL canónica con el host y protocolo públicos", () => {
    const req = { get: (name: string) => name === "host" ? "ter-i.example" : name === "x-forwarded-proto" ? "https" : undefined, originalUrl: "/webhook/sms?x=1", protocol: "http" } as any;
    expect(getCanonicalWebhookUrl(req)).toBe("https://ter-i.example/webhook/sms?x=1");
  });

  it("rechaza peticiones sin firma y delega la firma válida al SDK de Twilio", () => {
    const unsigned = { get: (name: string) => name === "host" ? "ter-i.example" : undefined, originalUrl: "/webhook/sms", protocol: "https", body: {} } as any;
    expect(verifyTwilioSignature(unsigned, "auth-token")).toBe(false);
    const signed = { ...unsigned, get: (name: string) => name === "host" ? "ter-i.example" : name === "x-twilio-signature" ? "signed" : undefined } as any;
    mocks.validateRequest.mockReturnValue(true);
    expect(verifyTwilioSignature(signed, "auth-token")).toBe(true);
    expect(mocks.validateRequest).toHaveBeenCalledWith("auth-token", "signed", "https://ter-i.example/webhook/sms", {});
  });
});
