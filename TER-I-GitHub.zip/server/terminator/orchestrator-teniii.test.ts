import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ callLLM: vi.fn(), generateVideo: vi.fn() }));
const dbMocks = vi.hoisted(() => ({ getOrCreateConversation: vi.fn(async () => null), addMessage: vi.fn(), getConversationHistory: vi.fn(async () => []) }));
vi.mock("./llm", () => ({ callLLM: mocks.callLLM }));
vi.mock("./tts", () => ({ synthesizeSpeech: vi.fn() }));
vi.mock("./video", () => ({ generateVideo: mocks.generateVideo }));
vi.mock("./db", () => ({
  getOrCreateConversation: dbMocks.getOrCreateConversation, addMessage: dbMocks.addMessage, getConversationHistory: dbMocks.getConversationHistory,
}));

import { processMessage } from "./orchestrator";

describe("fallback de LLM tenIII HTTP", () => {
  beforeEach(() => {
    mocks.callLLM.mockReset();
    mocks.generateVideo.mockReset();
    dbMocks.getOrCreateConversation.mockClear();
    dbMocks.addMessage.mockClear();
    dbMocks.getConversationHistory.mockClear();
  });

  it("reintenta con el backend estándar si el runtime custom falla", async () => {
    mocks.callLLM.mockRejectedValueOnce(new Error("gateway tenIII caído")).mockResolvedValueOnce({ text: "respuesta estándar", backend: "ollama", audioPrompt: null, videoPrompt: null });
    const response = await processMessage({ channelId: "test", channel: "web", text: "hola" }, null, { withAudio: false, withVideo: false, customLlmEndpoint: "http://127.0.0.1:8000" });
    expect(response.text).toBe("respuesta estándar");
    expect(mocks.callLLM).toHaveBeenCalledTimes(2);
    expect(mocks.callLLM.mock.calls[0][1]).toMatchObject({ customUrl: "http://127.0.0.1:8000", preferredBackend: "custom" });
    expect(mocks.callLLM.mock.calls[1][1]).toMatchObject({ preferredBackend: "auto" });
  });

  it("no persiste conversación para una sesión web standalone efímera", async () => {
    mocks.callLLM.mockResolvedValueOnce({ text: "efímero", backend: "ollama", audioPrompt: null, videoPrompt: null });
    await processMessage({ channelId: "anon", channel: "web", text: "hola" }, null, { withAudio: false, withVideo: false, persistConversation: false });
    expect(dbMocks.getOrCreateConversation).not.toHaveBeenCalled();
    expect(dbMocks.addMessage).not.toHaveBeenCalled();
  });

  it("propaga el gateway local persistido al generador de vídeo", async () => {
    mocks.callLLM.mockResolvedValueOnce({ text: "respuesta", backend: "ollama", audioPrompt: null, videoPrompt: "un robot caminando" });
    mocks.generateVideo.mockResolvedValueOnce({ url: "http://gateway/output.mp4", backend: "local-video" });

    await processMessage(
      { channelId: "local-video", channel: "web", text: "genera un vídeo", imageUrl: "https://img.example/ref.png", videoUrl: "https://video.example/previous.mp4" },
      { defaultVideo: "wan2", localVideoEndpoint: "http://127.0.0.1:8188", localVideoWorkflow: "wan2-t2v" } as any,
      { withAudio: false, withVideo: true, persistConversation: false },
    );

    expect(mocks.generateVideo).toHaveBeenCalledWith(
      {
        prompt: "un robot caminando",
        referenceImageUrl: "https://img.example/ref.png",
        previousVideoUrl: "https://video.example/previous.mp4",
      },
      expect.objectContaining({
        preferredVideo: "wan2",
        localVideoEndpoint: "http://127.0.0.1:8188",
        localVideoWorkflow: "wan2-t2v",
      }),
    );
  });
});
