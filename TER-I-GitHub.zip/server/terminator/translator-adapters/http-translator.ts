import {
  TranslatorError,
  normalizeLanguageCode,
  type TranslationRequest,
  type TranslationResult,
  type TranslatorBackend,
  type TranslatorBackendKind,
  type TranslatorStatus,
} from "../translator";

export interface HttpTranslatorOptions {
  name: string;
  kind: Extract<TranslatorBackendKind, "local" | "custom">;
  endpoint: string;
  apiKey?: string;
  headers?: Record<string, string>;
  timeoutMs?: number;
}

/** Adaptador para Ollama/Alia/NLLB/Marian u otra API HTTP propia. */
export class HttpTranslatorAdapter implements TranslatorBackend {
  readonly name: string;
  readonly kind: Extract<TranslatorBackendKind, "local" | "custom">;
  private readonly options: HttpTranslatorOptions;
  private lastError: string | null = null;

  constructor(options: HttpTranslatorOptions) {
    this.options = options;
    this.name = options.name;
    this.kind = options.kind;
  }

  async translate(request: TranslationRequest): Promise<TranslationResult> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.options.timeoutMs ?? 15_000);
    try {
      const response = await fetch(this.options.endpoint, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          ...(this.options.apiKey ? { authorization: `Bearer ${this.options.apiKey}` } : {}),
          ...this.options.headers,
        },
        body: JSON.stringify({
          text: request.text,
          sourceLanguage: request.sourceLanguage,
          targetLanguage: request.targetLanguage,
          source_language: request.sourceLanguage,
          target_language: request.targetLanguage,
          context: request.context,
        }),
        signal: controller.signal,
      });
      if (!response.ok) throw new TranslatorError(`HTTP ${response.status} en ${this.name}`, "PROVIDER_ERROR");
      const payload = (await response.json()) as unknown;
      const text = extractTranslationText(payload);
      if (!text) throw new TranslatorError(`Respuesta no reconocida de ${this.name}`, "PROVIDER_ERROR");
      this.lastError = null;
      return {
        text,
        sourceLanguage: normalizeLanguageCode(request.sourceLanguage ?? "und"),
        targetLanguage: normalizeLanguageCode(request.targetLanguage),
        backend: this.name,
        cached: false,
        metadata: { provider: this.name },
      };
    } catch (error) {
      this.lastError = error instanceof Error ? error.message : String(error);
      if (error instanceof TranslatorError) throw error;
      throw new TranslatorError(this.lastError, "NETWORK_ERROR");
    } finally {
      clearTimeout(timeout);
    }
  }

  getStatus(): TranslatorStatus {
    return { backend: this.name, kind: this.kind, healthy: this.lastError === null, lastError: this.lastError };
  }
}

function extractTranslationText(payload: unknown): string | null {
  if (!payload || typeof payload !== "object") return null;
  const record = payload as Record<string, unknown>;
  for (const key of ["translatedText", "translation", "text"]) {
    if (typeof record[key] === "string") return record[key] as string;
  }
  const nested = record.data;
  if (nested && typeof nested === "object") {
    const nestedRecord = nested as Record<string, unknown>;
    for (const key of ["translatedText", "translation", "text"]) {
      if (typeof nestedRecord[key] === "string") return nestedRecord[key] as string;
    }
  }
  return null;
}
