import {
  TranslatorError,
  normalizeLanguageCode,
  type TranslationRequest,
  type TranslationResult,
  type TranslatorBackend,
  type TranslatorStatus,
} from "../translator";

export class DeepLTranslatorAdapter implements TranslatorBackend {
  readonly name = "deepl";
  readonly kind = "deepl" as const;
  private lastError: string | null = null;

  constructor(private readonly apiKey?: string, private readonly endpoint?: string) {}

  async translate(request: TranslationRequest): Promise<TranslationResult> {
    const apiKey = this.apiKey ?? process.env.DEEPL_API_KEY;
    if (!apiKey) throw new TranslatorError("DEEPL_API_KEY no está configurada", "INVALID_CONFIG");
    try {
      const body = new URLSearchParams({
        text: request.text,
        target_lang: normalizeLanguageCode(request.targetLanguage).toUpperCase(),
      });
      if (request.sourceLanguage && request.sourceLanguage !== "und") {
        body.set("source_lang", normalizeLanguageCode(request.sourceLanguage).toUpperCase());
      }
      const response = await fetch(this.endpoint ?? process.env.DEEPL_API_URL ?? "https://api-free.deepl.com/v2/translate", {
        method: "POST",
        headers: {
          authorization: `DeepL-Auth-Key ${apiKey}`,
          "content-type": "application/x-www-form-urlencoded",
        },
        body,
      });
      if (!response.ok) throw new TranslatorError(`DeepL HTTP ${response.status}`, "PROVIDER_ERROR");
      const payload = (await response.json()) as {
        translations?: Array<{ text?: string; detected_source_language?: string }>;
      };
      const translation = payload.translations?.[0];
      if (!translation?.text) throw new TranslatorError("DeepL no devolvió traducción", "PROVIDER_ERROR");
      this.lastError = null;
      return {
        text: translation.text,
        sourceLanguage: normalizeLanguageCode(translation.detected_source_language ?? request.sourceLanguage ?? "und"),
        targetLanguage: normalizeLanguageCode(request.targetLanguage),
        backend: this.name,
        cached: false,
      };
    } catch (error) {
      this.lastError = error instanceof Error ? error.message : String(error);
      throw error instanceof TranslatorError ? error : new TranslatorError(this.lastError, "NETWORK_ERROR");
    }
  }

  getStatus(): TranslatorStatus {
    return { backend: this.name, kind: this.kind, healthy: this.lastError === null, lastError: this.lastError };
  }
}
