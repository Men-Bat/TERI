import {
  TranslatorError,
  normalizeLanguageCode,
  type TranslationRequest,
  type TranslationResult,
  type TranslatorBackend,
  type TranslatorStatus,
} from "../translator";

export class GoogleTranslateAdapter implements TranslatorBackend {
  readonly name = "google-translate";
  readonly kind = "google" as const;
  private lastError: string | null = null;

  constructor(private readonly apiKey?: string, private readonly endpoint?: string) {}

  async translate(request: TranslationRequest): Promise<TranslationResult> {
    const apiKey = this.apiKey ?? process.env.GOOGLE_TRANSLATE_API_KEY;
    if (!apiKey) throw new TranslatorError("GOOGLE_TRANSLATE_API_KEY no está configurada", "INVALID_CONFIG");
    try {
      const response = await fetch(
        `${this.endpoint ?? process.env.GOOGLE_TRANSLATE_URL ?? "https://translation.googleapis.com/language/translate/v2"}?key=${encodeURIComponent(apiKey)}`,
        {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            q: request.text,
            source: normalizeLanguageCode(request.sourceLanguage ?? "auto"),
            target: normalizeLanguageCode(request.targetLanguage),
            format: "text",
          }),
        }
      );
      if (!response.ok) throw new TranslatorError(`Google Translation HTTP ${response.status}`, "PROVIDER_ERROR");
      const payload = (await response.json()) as {
        data?: { translations?: Array<{ translatedText?: string; detectedSourceLanguage?: string }> };
      };
      const translation = payload.data?.translations?.[0];
      if (!translation?.translatedText) throw new TranslatorError("Google no devolvió traducción", "PROVIDER_ERROR");
      this.lastError = null;
      return {
        text: translation.translatedText,
        sourceLanguage: normalizeLanguageCode(translation.detectedSourceLanguage ?? request.sourceLanguage ?? "und"),
        targetLanguage: normalizeLanguageCode(request.targetLanguage),
        backend: this.name,
        cached: false,
      };
    } catch (error) {
      this.lastError = error instanceof Error ? error.message : String(error);
      throw error instanceof TranslatorError ? error : new TranslatorError(this.lastError, "NETWORK_ERROR");
    }
  }

  getStatus(): TranslatorStatus {
    return { backend: this.name, kind: this.kind, healthy: this.lastError === null, lastError: this.lastError };
  }
}
