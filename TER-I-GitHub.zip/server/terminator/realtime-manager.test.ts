import { describe, expect, it } from "vitest";
import {
  RealtimeBackendError,
  type RealtimeBackend,
  type RealtimeAudioChunk,
  type RealtimeEvent,
  type RealtimeEventHandler,
  type RealtimeMetrics,
  type RealtimeStatus,
} from "./realtime";
import { RealtimeManager } from "./realtime-manager";

class FakeRealtimeBackend implements RealtimeBackend {
  readonly kind = "custom" as const;
  private connected = false;
  private readonly handlers = new Set<RealtimeEventHandler>();
  private readonly metrics: RealtimeMetrics = {
    sentAudioChunks: 0,
    receivedAudioChunks: 0,
    sentTextMessages: 0,
    receivedTranscripts: 0,
    receivedResponses: 0,
    errorCount: 0,
    averageLatencyMs: null,
  };

  constructor(readonly name: string, private readonly failSend = false) {}

  async connect(): Promise<void> {
    this.connected = true;
    this.emit({ type: "connected" });
  }

  async disconnect(): Promise<void> {
    this.connected = false;
    this.emit({ type: "disconnected" });
  }

  async sendAudio(_chunk: RealtimeAudioChunk): Promise<void> {
    if (!this.connected) throw new RealtimeBackendError("not connected", "NOT_CONNECTED");
    if (this.failSend) throw new RealtimeBackendError("send failed", "SEND_FAILED");
    this.metrics.sentAudioChunks += 1;
  }

  async sendText(_text: string): Promise<void> {
    if (!this.connected) throw new RealtimeBackendError("not connected", "NOT_CONNECTED");
    if (this.failSend) throw new RealtimeBackendError("send failed", "SEND_FAILED");
    this.metrics.sentTextMessages += 1;
    this.emit({ type: "response", text: "ok" });
  }

  async interrupt(): Promise<void> {
    if (!this.connected) throw new RealtimeBackendError("not connected", "NOT_CONNECTED");
    this.emit({ type: "interrupted" });
  }

  onEvent(handler: RealtimeEventHandler): () => void {
    this.handlers.add(handler);
    return () => this.handlers.delete(handler);
  }

  getStatus(): RealtimeStatus {
    return {
      state: this.connected ? "connected" : "disconnected",
      backend: this.name,
      latencyMs: null,
      lastError: null,
      connectedAt: this.connected ? 1 : null,
    };
  }

  getMetrics(): RealtimeMetrics {
    return { ...this.metrics };
  }

  private emit(event: RealtimeEvent): void {
    for (const handler of Array.from(this.handlers)) handler(event);
  }
}

describe("RealtimeManager", () => {
  it("registra backends y selecciona el primero por defecto", () => {
    const manager = new RealtimeManager();
    const local = new FakeRealtimeBackend("local");
    manager.registerBackend(local);

    expect(manager.getActiveBackend().name).toBe("local");
    expect(manager.listBackends()).toHaveLength(1);
  });

  it("rechaza registros duplicados y backends desconocidos", () => {
    const manager = new RealtimeManager();
    manager.registerBackend(new FakeRealtimeBackend("local"));

    expect(() => manager.registerBackend(new FakeRealtimeBackend("local"))).toThrow("ya está registrado");
    expect(() => manager.selectBackend("missing")).toThrow("no registrado");
  });

  it("conecta al backend activo", async () => {
    const manager = new RealtimeManager();
    const local = new FakeRealtimeBackend("local");
    manager.registerBackend(local);

    const connected = await manager.connect();

    expect(connected).toBe(local);
    expect(local.getStatus().state).toBe("connected");
  });

  it("no hace fallback automáticamente si está desactivado", async () => {
    const manager = new RealtimeManager({ activeBackend: "primary", fallbackBackends: ["backup"], allowFallback: false });
    const primary = new FakeRealtimeBackend("primary", true);
    const backup = new FakeRealtimeBackend("backup");
    manager.registerBackend(primary);
    manager.registerBackend(backup);
    await primary.connect();
    await backup.connect();

    await expect(manager.sendText("hola")).rejects.toThrow("send failed");
    expect(manager.getStatus().activeBackend).toBe("primary");
  });

  it("usa fallback explícito cuando el backend primario falla", async () => {
    const manager = new RealtimeManager({ activeBackend: "primary", fallbackBackends: ["backup"], allowFallback: true });
    const primary = new FakeRealtimeBackend("primary", true);
    const backup = new FakeRealtimeBackend("backup");
    manager.registerBackend(primary);
    manager.registerBackend(backup);
    await primary.connect();
    await backup.connect();

    await manager.sendText("hola");

    expect(manager.getStatus().activeBackend).toBe("backup");
    expect(manager.getMetrics().sentTextMessages).toBe(1);
  });

  it("propaga eventos y agrega métricas", async () => {
    const manager = new RealtimeManager();
    const local = new FakeRealtimeBackend("local");
    const events: RealtimeEvent[] = [];
    manager.registerBackend(local);
    manager.onEvent(event => events.push(event));
    await manager.connect();
    await manager.sendText("hola");

    expect(events.some(event => event.type === "connected")).toBe(true);
    expect(events.some(event => event.type === "response" && event.text === "ok")).toBe(true);
    expect(events.filter(event => event.type === "response")).toHaveLength(1);
  });
});
