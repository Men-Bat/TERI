import { ElevenLabsRealtimeAdapter } from "./realtime-adapters/elevenlabs-realtime";
import { GeminiLiveAdapter } from "./realtime-adapters/gemini-live";
import { MoshiRealtimeAdapter } from "./realtime-adapters/moshi-realtime";
import { OpenAIRealtimeAdapter } from "./realtime-adapters/openai-realtime";
import { RealtimeManager } from "./realtime-manager";

export function createDefaultRealtimeManager(): RealtimeManager {
  const activeBackend = process.env.TERMINATOR_REALTIME_BACKEND ??
    (process.env.MOSHI_REALTIME_URL ? "moshi-local" : "openai-realtime");
  const fallbackBackends = (process.env.TERMINATOR_REALTIME_FALLBACKS ?? "")
    .split(",")
    .map(value => value.trim())
    .filter(Boolean);
  const allowFallback = process.env.TERMINATOR_REALTIME_ALLOW_FALLBACK === "true";

  const manager = new RealtimeManager({ activeBackend, fallbackBackends, allowFallback });
  manager.registerBackend(new MoshiRealtimeAdapter());
  manager.registerBackend(new OpenAIRealtimeAdapter());
  manager.registerBackend(new GeminiLiveAdapter());
  manager.registerBackend(new ElevenLabsRealtimeAdapter());
  return manager;
}
