export type TenIIIModelKind = "llm" | "tts" | "stt" | "video" | "avatar" | "embedding";
export type TenIIIModelFormat = "gguf" | "safetensors" | "ollama" | "api" | "kokoro" | "coqui" | "silero" | "piper" | "whisper" | "wan" | "ltx" | "cogvideo";

export interface RegisteredModel {
  id: number;
  userId: number;
  name: string;
  kind: TenIIIModelKind;
  format: string;
  endpoint?: string | null;
  modelPath?: string | null;
  languages?: unknown;
  capabilities?: unknown;
  resourceProfile?: unknown;
  enabled: string;
}

export interface ModelLoadDescriptor {
  modelId: number;
  name: string;
  kind: TenIIIModelKind;
  format: TenIIIModelFormat;
  transport: "http" | "local-runtime";
  target: string;
  languages: string[];
  capabilities: string[];
}

export interface ModelConnectivityResult {
  reachable: boolean;
  status?: number;
  latencyMs: number;
  error?: string;
}

const FORMAT_BY_KIND: Record<TenIIIModelKind, TenIIIModelFormat[]> = {
  llm: ["gguf", "safetensors", "ollama", "api"],
  tts: ["kokoro", "coqui", "silero", "piper", "api"],
  stt: ["whisper", "api"],
  video: ["wan", "ltx", "cogvideo", "api"],
  avatar: ["api"],
  embedding: ["safetensors", "api"],
};

function safeStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((entry): entry is string => typeof entry === "string") : [];
}

function isSafeTarget(target: string): boolean {
  return target.length > 0 && !target.includes("\0") && !target.includes("..\\") && !target.includes("../");
}

/** Converts a persisted record into an opaque, runtime-safe inference descriptor. */
export function loadRegisteredModel(model: RegisteredModel): ModelLoadDescriptor {
  if (model.enabled !== "true") throw new Error("Model is disabled");
  if (!Object.prototype.hasOwnProperty.call(FORMAT_BY_KIND, model.kind)) throw new Error("Unsupported model kind");
  if (!FORMAT_BY_KIND[model.kind].includes(model.format as TenIIIModelFormat)) throw new Error(`Format ${model.format} is incompatible with ${model.kind}`);

  const target = model.endpoint ?? model.modelPath;
  if (!target || !isSafeTarget(target)) throw new Error("Model requires a safe endpoint or runtime path");
  if (model.endpoint && !/^https?:\/\/|^ws:\/\//.test(model.endpoint)) throw new Error("Model endpoint must use HTTP(S) or WS(S)");

  return {
    modelId: model.id,
    name: model.name,
    kind: model.kind,
    format: model.format as TenIIIModelFormat,
    transport: model.endpoint ? "http" : "local-runtime",
    target,
    languages: safeStringArray(model.languages),
    capabilities: safeStringArray(model.capabilities),
  };
}

export function supportsLanguage(descriptor: ModelLoadDescriptor, language: string): boolean {
  return descriptor.languages.length === 0 || descriptor.languages.includes("auto") || descriptor.languages.includes(language.toLowerCase().split("-")[0]);
}

export async function checkModelConnectivity(descriptor: ModelLoadDescriptor, timeoutMs = 3_000): Promise<ModelConnectivityResult> {
  if (descriptor.transport !== "http") return { reachable: true, latencyMs: 0 };
  const url = new URL(descriptor.target);
  if (url.hostname === "169.254.169.254" || url.hostname === "metadata.google.internal") return { reachable: false, latencyMs: 0, error: "Endpoint reservado no permitido" };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const started = Date.now();
  try {
    const response = await fetch(url, { method: "HEAD", signal: controller.signal, redirect: "manual" });
    return { reachable: response.status < 500, status: response.status, latencyMs: Date.now() - started };
  } catch (error) {
    return { reachable: false, latencyMs: Date.now() - started, error: error instanceof Error ? error.message : "No disponible" };
  } finally {
    clearTimeout(timer);
  }
}
