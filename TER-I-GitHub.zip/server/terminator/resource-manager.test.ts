import { describe, expect, it } from "vitest";
import { selectInferencePlan } from "./resource-manager";

describe("ResourceManager tenIII", () => {
  it("elige Q2 para CPU limitada y no intenta offload GPU", () => {
    expect(selectInferencePlan({ device: "cpu", ramGb: 2 })).toMatchObject({ quantization: "q2", offloadLayers: 0 });
  });
  it("elige cuantización y offload para CUDA con VRAM declarada", () => {
    expect(selectInferencePlan({ device: "cuda", vramGb: 12 })).toMatchObject({ quantization: "q6", offloadLayers: 32 });
  });
});
