import { describe, expect, it } from "vitest";
import { createRealtimeTicket, consumeRealtimeTicket } from "./realtime-session-store";
import { buildSecureRealtimeConfig } from "./webhooks";

describe("flujo seguro de ticket Realtime", () => {
  it("consume un ticket una sola vez y conserva la credencial y metadata del servidor", () => {
    const ticket = createRealtimeTicket({
      apiKey: "server-only-key",
      endpoint: "ws://localhost:8998/ws",
      metadata: { backend: "moshi-local" },
    });

    const session = consumeRealtimeTicket(ticket);
    const config = buildSecureRealtimeConfig(session, {
      apiKey: "browser-injected-key",
      metadata: { backend: "openai-realtime" },
      model: "user-selected-model",
    });

    expect(config).toMatchObject({
      apiKey: "server-only-key",
      endpoint: "ws://localhost:8998/ws",
      metadata: { backend: "moshi-local" },
      model: "user-selected-model",
    });
    expect(consumeRealtimeTicket(ticket)).toBeNull();
  });
});
