import {
  RealtimeBackendError,
  type RealtimeBackend,
  type RealtimeBackendKind,
  type RealtimeAudioChunk,
  type RealtimeConfig,
  type RealtimeEvent,
  type RealtimeEventHandler,
  type RealtimeMetrics,
  type RealtimeStatus,
} from "./realtime";

export interface RealtimeManagerConfig {
  activeBackend?: string;
  fallbackBackends?: string[];
  allowFallback?: boolean;
}

export interface RealtimeManagerStatus {
  activeBackend: string | null;
  availableBackends: Array<{ name: string; kind: RealtimeBackendKind; status: RealtimeStatus }>;
}

/**
 * Registro y enrutamiento de backends Realtime.
 *
 * El fallback es opt-in para evitar enviar audio a la nube cuando el usuario
 * ha elegido explícitamente un backend local.
 */
export class RealtimeManager {
  private readonly backends = new Map<string, RealtimeBackend>();
  private readonly handlers = new Set<RealtimeEventHandler>();
  private activeBackendName: string | null = null;
  private fallbackBackends: string[] = [];
  private allowFallback = false;

  constructor(config: RealtimeManagerConfig = {}) {
    this.activeBackendName = config.activeBackend ?? null;
    this.fallbackBackends = config.fallbackBackends ?? [];
    this.allowFallback = config.allowFallback ?? false;
  }

  registerBackend(backend: RealtimeBackend): void {
    if (!backend.name.trim()) {
      throw new RealtimeBackendError("El backend Realtime necesita un nombre", "INVALID_CONFIG");
    }
    if (this.backends.has(backend.name)) {
      throw new RealtimeBackendError(`El backend Realtime ya está registrado: ${backend.name}`, "INVALID_CONFIG");
    }
    this.backends.set(backend.name, backend);
    backend.onEvent(event => this.emit({ ...event, data: { backend: backend.name, payload: event.data } }));
    if (!this.activeBackendName) this.activeBackendName = backend.name;
  }

  unregisterBackend(name: string): boolean {
    if (this.activeBackendName === name) this.activeBackendName = null;
    this.fallbackBackends = this.fallbackBackends.filter(candidate => candidate !== name);
    return this.backends.delete(name);
  }

  listBackends(): RealtimeBackend[] {
    return Array.from(this.backends.values());
  }

  selectBackend(name: string): void {
    if (!this.backends.has(name)) {
      throw new RealtimeBackendError(`Backend Realtime no registrado: ${name}`, "INVALID_CONFIG");
    }
    this.activeBackendName = name;
  }

  configureFallback(backends: string[], allowFallback: boolean): void {
    const unknown = backends.filter(name => !this.backends.has(name));
    if (unknown.length > 0) {
      throw new RealtimeBackendError(`Backends de fallback desconocidos: ${unknown.join(", ")}`, "INVALID_CONFIG");
    }
    this.fallbackBackends = [...backends];
    this.allowFallback = allowFallback;
  }

  getActiveBackend(): RealtimeBackend {
    if (!this.activeBackendName) {
      throw new RealtimeBackendError("No hay backend Realtime seleccionado", "INVALID_CONFIG");
    }
    const backend = this.backends.get(this.activeBackendName);
    if (!backend) {
      throw new RealtimeBackendError(`Backend Realtime no disponible: ${this.activeBackendName}`, "INVALID_CONFIG");
    }
    return backend;
  }

  async connect(config?: RealtimeConfig): Promise<RealtimeBackend> {
    const candidates = this.candidateNames();
    let lastError: unknown = null;

    for (const name of Array.from(candidates)) {
      const backend = this.backends.get(name);
      if (!backend) continue;
      try {
        await backend.connect(config);
        this.activeBackendName = name;
        return backend;
      } catch (error) {
        lastError = error;
        if (!this.allowFallback || name === candidates[candidates.length - 1]) break;
      }
    }

    const message = lastError instanceof Error ? lastError.message : "No se pudo conectar a un backend Realtime";
    throw new RealtimeBackendError(message, "CONNECTION_FAILED");
  }

  async disconnect(): Promise<void> {
    const connected = this.listBackends().filter(backend => backend.getStatus().state === "connected");
    await Promise.all(connected.map(backend => backend.disconnect()));
  }

  async sendAudio(chunk: RealtimeAudioChunk): Promise<void> {
    await this.withFallback(backend => backend.sendAudio(chunk));
  }

  async sendText(text: string): Promise<void> {
    await this.withFallback(backend => backend.sendText(text));
  }

  async interrupt(): Promise<void> {
    await this.withFallback(backend => backend.interrupt());
  }

  onEvent(handler: RealtimeEventHandler): () => void {
    this.handlers.add(handler);
    return () => this.handlers.delete(handler);
  }

  getStatus(): RealtimeManagerStatus {
    return {
      activeBackend: this.activeBackendName,
      availableBackends: this.listBackends().map(backend => ({
        name: backend.name,
        kind: backend.kind,
        status: backend.getStatus(),
      })),
    };
  }

  getMetrics(): RealtimeMetrics {
    const metrics = this.listBackends().map(backend => backend.getMetrics());
    const latencyValues = metrics.map(item => item.averageLatencyMs).filter((value): value is number => value !== null);
    return {
      sentAudioChunks: metrics.reduce((sum, item) => sum + item.sentAudioChunks, 0),
      receivedAudioChunks: metrics.reduce((sum, item) => sum + item.receivedAudioChunks, 0),
      sentTextMessages: metrics.reduce((sum, item) => sum + item.sentTextMessages, 0),
      receivedTranscripts: metrics.reduce((sum, item) => sum + item.receivedTranscripts, 0),
      receivedResponses: metrics.reduce((sum, item) => sum + item.receivedResponses, 0),
      errorCount: metrics.reduce((sum, item) => sum + item.errorCount, 0),
      averageLatencyMs: latencyValues.length ? latencyValues.reduce((sum, value) => sum + value, 0) / latencyValues.length : null,
    };
  }

  private candidateNames(): string[] {
    const names = this.activeBackendName ? [this.activeBackendName] : [];
    if (this.allowFallback) names.push(...this.fallbackBackends);
    return Array.from(new Set(names));
  }

  private async withFallback(operation: (backend: RealtimeBackend) => Promise<void>): Promise<void> {
    const candidates = this.candidateNames();
    if (candidates.length === 0) {
      throw new RealtimeBackendError("No hay backend Realtime seleccionado", "INVALID_CONFIG");
    }

    let lastError: unknown = null;
    for (const name of Array.from(candidates)) {
      const backend = this.backends.get(name);
      if (!backend) continue;
      try {
        await operation(backend);
        this.activeBackendName = name;
        return;
      } catch (error) {
        lastError = error;
        if (!this.allowFallback || name === candidates[candidates.length - 1]) break;
      }
    }
    const message = lastError instanceof Error ? lastError.message : "La operación Realtime falló";
    throw new RealtimeBackendError(message, "SEND_FAILED");
  }

  private emit(event: RealtimeEvent): void {
    for (const handler of Array.from(this.handlers)) handler(event);
  }
}
