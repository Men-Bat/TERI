/**
 * Terminator II — Database helpers
 * Query helpers for conversations, messages, and config tables.
 */
import { and, eq, desc } from "drizzle-orm";
import { getDb } from "../db";
import { decryptProviderSecret, decryptTerminatorConfigSecrets, encryptProviderSecret, encryptTerminatorConfigSecrets } from "./provider-secret";
import { conversations, messages, terminatorConfig, customModels, modelAdapters, userProviders } from "../../drizzle/schema";
import type {
  InsertConversation,
  InsertMessage,
  InsertTerminatorConfig,
  Conversation,
  Message,
  TerminatorConfig,
  CustomModel,
  InsertCustomModel,
  ModelAdapter,
  InsertModelAdapter,
  UserProvider,
  InsertUserProvider,
} from "../../drizzle/schema";

// ─── Conversations ────────────────────────────────────────────────────────────

export async function getOrCreateConversation(
  channelId: string,
  channel: InsertConversation["channel"],
  defaults?: Partial<InsertConversation>
): Promise<Conversation | null> {
  const db = await getDb();
  if (!db) return null;

  const existing = await db
    .select()
    .from(conversations)
    .where(eq(conversations.channelId, channelId))
    .limit(1);

  if (existing.length > 0) return existing[0];

  await db.insert(conversations).values({
    channelId,
    channel,
    personaId: defaults?.personaId ?? "default",
    llmBackend: defaults?.llmBackend ?? "auto",
    ttsBackend: defaults?.ttsBackend ?? "auto",
    videoBackend: defaults?.videoBackend ?? "none",
    language: defaults?.language ?? "es",
  });

  const created = await db
    .select()
    .from(conversations)
    .where(eq(conversations.channelId, channelId))
    .limit(1);
  return created[0] ?? null;
}

export async function updateConversation(
  id: number,
  updates: Partial<InsertConversation>
): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(conversations).set(updates).where(eq(conversations.id, id));
}

// ─── Messages ─────────────────────────────────────────────────────────────────

export async function addMessage(data: InsertMessage): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(messages).values(data);
}

export async function getConversationHistory(
  conversationId: number,
  limit = 20
): Promise<Message[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(desc(messages.createdAt))
    .limit(limit);
  return rows.reverse();
}

// ─── Config ───────────────────────────────────────────────────────────────────

export async function getTerminatorConfig(
  userId: number
): Promise<TerminatorConfig | null> {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(terminatorConfig)
    .where(eq(terminatorConfig.userId, userId))
    .limit(1);
  return rows[0] ? decryptTerminatorConfigSecrets(rows[0] as unknown as Record<string, unknown>) as TerminatorConfig : null;
}

export async function upsertTerminatorConfig(
  userId: number,
  data: Partial<InsertTerminatorConfig>
): Promise<void> {
  const db = await getDb();
  if (!db) return;
  const protectedData = encryptTerminatorConfigSecrets(data as Record<string, unknown>) as Partial<InsertTerminatorConfig>;
  const existing = await getTerminatorConfig(userId);
  if (existing) {
    await db
      .update(terminatorConfig)
      .set({ ...protectedData, updatedAt: new Date() })
      .where(eq(terminatorConfig.userId, userId));
  } else {
    await db.insert(terminatorConfig).values({ userId, ...protectedData });
  }
}

// ─── Catálogo opcional de proveedores administrado por cada usuario ───────────

export async function listUserProviders(userId: number): Promise<UserProvider[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userProviders).where(eq(userProviders.userId, userId)).orderBy(desc(userProviders.updatedAt));
}

export async function getUserProvider(userId: number, providerId: number): Promise<UserProvider | null> {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(userProviders).where(and(eq(userProviders.userId, userId), eq(userProviders.id, providerId))).limit(1);
  if (!rows[0]) return null;
  return { ...rows[0], secret: rows[0].secret ? decryptProviderSecret(rows[0].secret) : null };
}

export async function createUserProvider(userId: number, data: Omit<InsertUserProvider, "id" | "userId" | "createdAt" | "updatedAt">): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(userProviders).values({ userId, ...data, secret: data.secret ? encryptProviderSecret(data.secret) : undefined });
  return Number(result[0].insertId);
}

export async function updateUserProvider(userId: number, providerId: number, data: Partial<InsertUserProvider>): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  const result = await db.update(userProviders).set({ ...data, secret: data.secret ? encryptProviderSecret(data.secret) : data.secret, updatedAt: new Date() }).where(and(eq(userProviders.userId, userId), eq(userProviders.id, providerId)));
  return Number(result[0].affectedRows) > 0;
}

export async function deleteUserProvider(userId: number, providerId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  const result = await db.delete(userProviders).where(and(eq(userProviders.userId, userId), eq(userProviders.id, providerId)));
  return Number(result[0].affectedRows) > 0;
}

// ─── tenIII model registry ───────────────────────────────────────────────────

export async function listCustomModels(userId: number): Promise<CustomModel[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(customModels).where(eq(customModels.userId, userId)).orderBy(desc(customModels.updatedAt));
}

export async function getCustomModel(userId: number, modelId: number): Promise<CustomModel | null> {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(customModels).where(and(eq(customModels.userId, userId), eq(customModels.id, modelId))).limit(1);
  return rows[0] ?? null;
}

export async function createCustomModel(userId: number, data: Omit<InsertCustomModel, "id" | "userId" | "createdAt" | "updatedAt">): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(customModels).values({ userId, ...data });
  return Number(result[0].insertId);
}

export async function updateCustomModel(userId: number, modelId: number, data: Partial<InsertCustomModel>): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  const result = await db.update(customModels).set({ ...data, updatedAt: new Date() }).where(and(eq(customModels.userId, userId), eq(customModels.id, modelId)));
  return Number(result[0].affectedRows) > 0;
}

export async function deleteCustomModel(userId: number, modelId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  await db.delete(modelAdapters).where(and(eq(modelAdapters.userId, userId), eq(modelAdapters.modelId, modelId)));
  const result = await db.delete(customModels).where(and(eq(customModels.userId, userId), eq(customModels.id, modelId)));
  return Number(result[0].affectedRows) > 0;
}

export async function listModelAdapters(userId: number, modelId: number): Promise<ModelAdapter[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(modelAdapters).where(and(eq(modelAdapters.userId, userId), eq(modelAdapters.modelId, modelId))).orderBy(desc(modelAdapters.updatedAt));
}

export async function createModelAdapter(userId: number, data: Omit<InsertModelAdapter, "id" | "userId" | "createdAt" | "updatedAt">): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(modelAdapters).values({ userId, ...data });
  return Number(result[0].insertId);
}
