export type TranslatorBackendKind = "local" | "google" | "deepl" | "custom";

export interface TranslationRequest {
  text: string;
  sourceLanguage?: string;
  targetLanguage: string;
  context?: string;
  metadata?: Record<string, unknown>;
}

export interface TranslationResult {
  text: string;
  sourceLanguage: string;
  targetLanguage: string;
  backend: string;
  cached: boolean;
  confidence?: number;
  metadata?: Record<string, unknown>;
}

export interface TranslatorStatus {
  backend: string;
  kind: TranslatorBackendKind;
  healthy: boolean;
  lastError: string | null;
}

export interface TranslatorBackend {
  readonly name: string;
  readonly kind: TranslatorBackendKind;
  translate(request: TranslationRequest): Promise<TranslationResult>;
  detectLanguage?(text: string): Promise<string>;
  getStatus(): TranslatorStatus;
}

export class TranslatorError extends Error {
  readonly code: "INVALID_REQUEST" | "INVALID_CONFIG" | "NETWORK_ERROR" | "PROVIDER_ERROR" | "UNSUPPORTED_LANGUAGE";

  constructor(
    message: string,
    code: "INVALID_REQUEST" | "INVALID_CONFIG" | "NETWORK_ERROR" | "PROVIDER_ERROR" | "UNSUPPORTED_LANGUAGE"
  ) {
    super(message);
    this.name = "TranslatorError";
    this.code = code;
  }
}

export function normalizeLanguageCode(language: string): string {
  return language.trim().replace("_", "-").toLowerCase();
}

export function inferLanguage(text: string): string {
  const value = text.trim();
  if (!value) return "und";
  if (/[\u0400-\u04ff]/.test(value)) return /[іїєґ]/i.test(value) ? "uk" : "ru";
  if (/[\u0600-\u06ff]/.test(value)) return "ar";
  if (/[\u4e00-\u9fff]/.test(value)) return "zh";
  if (/[\u3040-\u30ff]/.test(value)) return "ja";
  if (/[\uac00-\ud7af]/.test(value)) return "ko";
  if (/[\u0d00-\u0d7f]/.test(value)) return "ml";
  return "en";
}
