import { beforeEach, describe, expect, it, vi } from "vitest";
import { createHmac } from "crypto";

const mocks = vi.hoisted(() => ({ getConfig: vi.fn() }));
vi.mock("./db", () => ({ getTerminatorConfig: mocks.getConfig }));

import { registerTelegram, registerWhatsApp, verifyWhatsAppSignature } from "./webhooks";

describe("verificación del webhook Meta/WhatsApp", () => {
  beforeEach(() => { vi.clearAllMocks(); });

  it("solo devuelve el challenge cuando coincide el token de verificación configurado", async () => {
    let handler: ((req: any, res: any) => Promise<void>) | undefined;
    registerWhatsApp({ get: (_path: string, callback: typeof handler) => { handler = callback; }, post: vi.fn() } as any);
    mocks.getConfig.mockResolvedValue({ whatsappVerifyToken: "verify-private" });
    const res = { status: vi.fn(() => res), send: vi.fn(), sendStatus: vi.fn() };
    await handler!({ query: { "hub.mode": "subscribe", "hub.verify_token": "verify-private", "hub.challenge": "challenge-ok" } }, res);
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.send).toHaveBeenCalledWith("challenge-ok");
    expect(res.sendStatus).not.toHaveBeenCalled();
  });

  it("rechaza un token ausente o incorrecto", async () => {
    let handler: ((req: any, res: any) => Promise<void>) | undefined;
    registerWhatsApp({ get: (_path: string, callback: typeof handler) => { handler = callback; }, post: vi.fn() } as any);
    mocks.getConfig.mockResolvedValue({ whatsappVerifyToken: "verify-private" });
    const res = { status: vi.fn(() => res), send: vi.fn(), sendStatus: vi.fn() };
    await handler!({ query: { "hub.mode": "subscribe", "hub.verify_token": "wrong", "hub.challenge": "challenge-no" } }, res);
    expect(res.sendStatus).toHaveBeenCalledWith(403);
  });

  it("valida la firma HMAC de Meta contra el cuerpo crudo", () => {
    const secret = "meta-app-secret";
    const rawBody = Buffer.from('{"entry":[]}');
    const signature = `sha256=${createHmac("sha256", secret).update(rawBody).digest("hex")}`;
    const req = { rawBody, get: (name: string) => name === "x-hub-signature-256" ? signature : undefined } as any;
    expect(verifyWhatsAppSignature(req, secret)).toBe(true);
    expect(verifyWhatsAppSignature({ ...req, get: () => "sha256:invalid" } as any, secret)).toBe(false);
  });

  it("rechaza Telegram si no presenta el secret token configurado", async () => {
    let handler: ((req: any, res: any) => Promise<void>) | undefined;
    registerTelegram({ post: (_path: string, callback: typeof handler) => { handler = callback; } } as any);
    mocks.getConfig.mockResolvedValue({ telegramWebhookSecret: "telegram-private" });
    const res = { sendStatus: vi.fn() };
    await handler!({ get: () => undefined, body: {} }, res);
    expect(res.sendStatus).toHaveBeenCalledWith(401);
  });
});
