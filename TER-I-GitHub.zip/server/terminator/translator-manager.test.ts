import { describe, expect, it } from "vitest";
import {
  inferLanguage,
  type TranslationRequest,
  type TranslationResult,
  type TranslatorBackend,
  type TranslatorStatus,
} from "./translator";
import { TranslatorManager } from "./translator-manager";

class FakeTranslator implements TranslatorBackend {
  readonly kind = "local" as const;
  calls = 0;
  private lastError: string | null = null;

  constructor(readonly name: string, private readonly fail = false) {}

  async translate(request: TranslationRequest): Promise<TranslationResult> {
    this.calls += 1;
    if (this.fail) throw new Error("backend unavailable");
    return {
      text: `[${request.targetLanguage}] ${request.text}`,
      sourceLanguage: request.sourceLanguage ?? "und",
      targetLanguage: request.targetLanguage,
      backend: this.name,
      cached: false,
    };
  }

  async detectLanguage(): Promise<string> {
    return "ru-RU";
  }

  getStatus(): TranslatorStatus {
    return { backend: this.name, kind: this.kind, healthy: this.lastError === null, lastError: this.lastError };
  }
}

describe("TranslatorManager", () => {
  it("detecta ruso, ucraniano, árabe y chino con una heurística local", () => {
    expect(inferLanguage("Привет мир")).toBe("ru");
    expect(inferLanguage("Їжак іде додому")).toBe("uk");
    expect(inferLanguage("مرحبا بالعالم")).toBe("ar");
    expect(inferLanguage("你好世界")).toBe("zh");
  });

  it("traduce y devuelve el resultado desde el backend activo", async () => {
    const manager = new TranslatorManager();
    const local = new FakeTranslator("local");
    manager.registerBackend(local);

    const result = await manager.translate({ text: "Привет", targetLanguage: "es" });

    expect(result.text).toBe("[es] Привет");
    expect(result.sourceLanguage).toBe("ru");
    expect(result.cached).toBe(false);
  });

  it("usa caché por sesión y no vuelve a llamar al backend", async () => {
    const manager = new TranslatorManager({ cacheSize: 10 });
    const local = new FakeTranslator("local");
    manager.registerBackend(local);

    await manager.translate({ text: "hello", targetLanguage: "es" });
    const second = await manager.translate({ text: "hello", targetLanguage: "es" });

    expect(local.calls).toBe(1);
    expect(second.cached).toBe(true);
  });

  it("usa fallback solo cuando está explícitamente activado", async () => {
    const manager = new TranslatorManager({ activeBackend: "primary", fallbackBackends: ["backup"], allowFallback: true });
    const primary = new FakeTranslator("primary", true);
    const backup = new FakeTranslator("backup");
    manager.registerBackend(primary);
    manager.registerBackend(backup);

    const result = await manager.translate({ text: "hello", targetLanguage: "de" });

    expect(result.backend).toBe("backup");
    expect(manager.getActiveBackend()).toBe("backup");
  });

  it("usa la detección del backend cuando está disponible", async () => {
    const manager = new TranslatorManager();
    manager.registerBackend(new FakeTranslator("local"));

    await expect(manager.detectLanguage("texto")).resolves.toBe("ru-ru");
  });
});
