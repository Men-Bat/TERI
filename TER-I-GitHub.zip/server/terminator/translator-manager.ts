import {
  inferLanguage,
  normalizeLanguageCode,
  TranslatorError,
  type TranslationRequest,
  type TranslationResult,
  type TranslatorBackend,
  type TranslatorBackendKind,
  type TranslatorStatus,
} from "./translator";

export interface TranslatorManagerConfig {
  activeBackend?: string;
  fallbackBackends?: string[];
  allowFallback?: boolean;
  cacheSize?: number;
}

export class TranslatorManager {
  private readonly backends = new Map<string, TranslatorBackend>();
  private readonly cache = new Map<string, TranslationResult>();
  private readonly cacheSize: number;
  private activeBackendName: string | null;
  private fallbackBackends: string[];
  private allowFallback: boolean;

  constructor(config: TranslatorManagerConfig = {}) {
    this.activeBackendName = config.activeBackend ?? null;
    this.fallbackBackends = config.fallbackBackends ?? [];
    this.allowFallback = config.allowFallback ?? false;
    this.cacheSize = Math.max(0, config.cacheSize ?? 500);
  }

  registerBackend(backend: TranslatorBackend): void {
    if (!backend.name.trim() || this.backends.has(backend.name)) {
      throw new TranslatorError(`Backend de traducción inválido o duplicado: ${backend.name}`, "INVALID_CONFIG");
    }
    this.backends.set(backend.name, backend);
    if (!this.activeBackendName) this.activeBackendName = backend.name;
  }

  selectBackend(name: string): void {
    if (!this.backends.has(name)) throw new TranslatorError(`Backend de traducción no registrado: ${name}`, "INVALID_CONFIG");
    this.activeBackendName = name;
  }

  configureFallback(backends: string[], allowFallback: boolean): void {
    const unknown = backends.filter(name => !this.backends.has(name));
    if (unknown.length) throw new TranslatorError(`Fallbacks desconocidos: ${unknown.join(", ")}`, "INVALID_CONFIG");
    this.fallbackBackends = Array.from(backends);
    this.allowFallback = allowFallback;
  }

  async translate(request: TranslationRequest): Promise<TranslationResult> {
    const normalized = this.validateRequest(request);
    const cacheKey = this.cacheKey(normalized);
    const cached = this.cache.get(cacheKey);
    if (cached) return { ...cached, cached: true };

    const candidates = this.candidateNames();
    let lastError: unknown = null;
    for (const name of Array.from(candidates)) {
      const backend = this.backends.get(name);
      if (!backend) continue;
      try {
        const result = await backend.translate(normalized);
        if (!result.text.trim()) throw new TranslatorError("El traductor devolvió texto vacío", "PROVIDER_ERROR");
        const finalResult = { ...result, cached: false, backend: backend.name };
        this.storeCache(cacheKey, finalResult);
        this.activeBackendName = backend.name;
        return finalResult;
      } catch (error) {
        lastError = error;
        if (!this.allowFallback || name === candidates[candidates.length - 1]) break;
      }
    }

    if (lastError instanceof TranslatorError) throw lastError;
    throw new TranslatorError(lastError instanceof Error ? lastError.message : "Falló la traducción", "PROVIDER_ERROR");
  }

  async detectLanguage(text: string): Promise<string> {
    if (!text.trim()) return "und";
    const active = this.activeBackendName ? this.backends.get(this.activeBackendName) : undefined;
    if (active?.detectLanguage) {
      try {
        return normalizeLanguageCode(await active.detectLanguage(text));
      } catch {
        // La heurística local evita que la detección bloquee una conversación.
      }
    }
    return inferLanguage(text);
  }

  clearCache(): void {
    this.cache.clear();
  }

  listBackends(): Array<{ name: string; kind: TranslatorBackendKind; status: TranslatorStatus }> {
    return Array.from(this.backends.values()).map(backend => ({
      name: backend.name,
      kind: backend.kind,
      status: backend.getStatus(),
    }));
  }

  getActiveBackend(): string | null {
    return this.activeBackendName;
  }

  private validateRequest(request: TranslationRequest): TranslationRequest {
    if (!request.text.trim()) throw new TranslatorError("El texto a traducir no puede estar vacío", "INVALID_REQUEST");
    if (!request.targetLanguage.trim()) throw new TranslatorError("Falta el idioma destino", "INVALID_REQUEST");
    const sourceLanguage = normalizeLanguageCode(request.sourceLanguage ?? inferLanguage(request.text));
    const targetLanguage = normalizeLanguageCode(request.targetLanguage);
    if (sourceLanguage === targetLanguage) {
      return { ...request, sourceLanguage, targetLanguage };
    }
    return { ...request, sourceLanguage, targetLanguage };
  }

  private candidateNames(): string[] {
    const names = this.activeBackendName ? [this.activeBackendName] : [];
    if (this.allowFallback) names.push(...this.fallbackBackends);
    return Array.from(new Set(names));
  }

  private cacheKey(request: TranslationRequest): string {
    return `${this.activeBackendName ?? "auto"}|${request.sourceLanguage}|${request.targetLanguage}|${request.text}`;
  }

  private storeCache(key: string, value: TranslationResult): void {
    if (this.cacheSize === 0) return;
    this.cache.delete(key);
    this.cache.set(key, value);
    while (this.cache.size > this.cacheSize) {
      const oldest = this.cache.keys().next().value;
      if (typeof oldest !== "string") break;
      this.cache.delete(oldest);
    }
  }
}
