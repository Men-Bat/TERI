import { nanoid } from "nanoid";
import type { RealtimeConfig } from "./realtime";

interface StoredRealtimeSession {
  config: RealtimeConfig;
  expiresAt: number;
}

const sessions = new Map<string, StoredRealtimeSession>();
const DEFAULT_TTL_MS = 60_000;

export function createRealtimeTicket(config: RealtimeConfig, ttlMs = DEFAULT_TTL_MS): string {
  const ticket = nanoid(32);
  sessions.set(ticket, { config, expiresAt: Date.now() + ttlMs });
  return ticket;
}

export function consumeRealtimeTicket(ticket: string): RealtimeConfig | null {
  const session = sessions.get(ticket);
  sessions.delete(ticket);
  if (!session || session.expiresAt <= Date.now()) return null;
  return session.config;
}

export function clearExpiredRealtimeTickets(): void {
  const now = Date.now();
  for (const [ticket, session] of Array.from(sessions.entries())) {
    if (session.expiresAt < now) sessions.delete(ticket);
  }
}
