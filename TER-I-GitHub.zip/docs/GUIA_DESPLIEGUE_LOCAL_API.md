# Guía Práctica: Despliegue Local y Exposición de API en Terminator II

**Autor:** Manus AI  
**Fecha:** 16 de agosto de 2026  
**Versión:** TER I v3.1 — TenIII Generation 3 Inference Runtime  

## 1. Introducción

TER I está diseñado bajo un paradigma **local-first** y descentralizado. Terminator II es la referencia técnica de la implementación multimodal heredada. Permite ejecutar inferencia de modelos, síntesis de voz (Kokoro, Coqui, Silero, Piper), traducción local y gateways de vídeo (Wan2.1, LTX-Video, gateways personalizados) directamente en hardware local o servidores autohospedados, exponiendo una API robusta basada en Express y tRPC bajo `/api/trpc` y endpoints de WebSockets y webhooks.

Esta guía detalla los pasos para levantar el entorno completo de forma local, arrancar los servicios complementarios (como Kokoro-FastAPI) y exponer el servidor y su API hacia Internet o una red privada de forma segura.

---

## 2. Requisitos del Sistema y Arquitectura Local

Para operar el sistema completo en un entorno local, se recomienda la siguiente infraestructura:

| Componente | Requisito Mínimo | Requisito Óptimo / Producción |
|---|---|---|
| **CPU / Memoria** | 4 núcleos, 8 GB RAM | 8+ núcleos, 16 GB+ RAM |
| **GPU (Opcional)** | CPU con offload (Kokoro / LTX / Ollama liviano) | NVIDIA GPU (12GB+ VRAM para Kokoro CUDA, Wan o LTX) |
| **Almacenamiento** | 10 GB libres | 50 GB+ SSD (para pesos de modelos y caché local) |
| **Runtime Software** | Node.js 22+, pnpm, Python 3.11 | Docker y Docker Compose (para contenedores de inferencia) |

---

## 3. Puesta en Marcha Local

### Paso 1: Clonar o extraer el paquete de distribución
Descomprime el archivo ZIP standalone correspondiente (por ejemplo, `Terminator_II_v3_1_VideoLocal.zip`) en tu máquina de destino o servidor local:

```bash
unzip Terminator_II_v3_1_VideoLocal.zip -d /path/to/terminator-ii
cd /path/to/terminator-ii
```

### Paso 2: Instalar dependencias del proyecto web
```bash
pnpm install
```

### Paso 3: Configurar variables de entorno y base de datos
Consulta `deploy/ENVIRONMENT_LOCAL_TEMPLATE.md` y configura las variables de entorno principales con valores propios. Para desarrollo local con MySQL:
```bash
# Configura DATABASE_URL, JWT_SECRET y PROVIDER_ENCRYPTION_KEY mediante tu gestor seguro de secretos.
# Añade claves cloud solo si vas a usar los proveedores correspondientes.
```

Sincroniza el esquema de base de datos:
```bash
pnpm db:push
```

### Paso 4: Levantar el servidor de desarrollo o producción
Para desarrollo local con recarga en vivo:
```bash
pnpm dev
```

Para compilación y ejecución en modo producción:
```bash
pnpm build
node dist/index.js
```

El servidor estará accesible por defecto en `http://localhost:3000`.

---

## 4. Arranque de Servicios de Inferencia Local (Kokoro y Modelos)

Terminator II se conecta de forma nativa a runtimes locales expuestos mediante HTTP o WebSockets.

### Despliegue de Kokoro TTS (Contenedor Docker Oficial / Yoqer)
Para habilitar síntesis de voz local de alta velocidad en 11 idiomas con streaming SSE y control de volumen:

```bash
# Perfil CPU
docker compose --env-file deploy/kokoro.env -f deploy/docker-compose.kokoro.yml --profile cpu up -d

# Perfil NVIDIA CUDA (requiere NVIDIA Container Toolkit)
docker compose --env-file deploy/kokoro.env -f deploy/docker-compose.kokoro.yml --profile cuda up -d
```

El servicio responderá en `http://localhost:8880`, exponiendo los endpoints `/v1/audio/speech`, `/v1/voices` y `/v1/models` que Terminator II consume y proxifica de manera segura.

---

## 5. Exposición de la API y la Web en Internet

Existen dos métodos principales para exponer tu servidor local de Terminator II hacia Internet de forma controlada:

### Opción A: Túneles Seguros (ngrok, Cloudflare Tunnel o Tailscale) — *Recomendado para desarrollo y pruebas rápidas*

Si tu servidor se encuentra detrás de un NAT o un firewall doméstico/empresarial, puedes utilizar un túnel cifrado sin necesidad de abrir puertos públicos en tu router:

1. **Usando Cloudflare Tunnel (`cloudflared`):**
   ```bash
   cloudflared tunnel --url http://localhost:3000
   ```
   Cloudflare te asignará una URL pública temporal (ej. `https://terminator.trycloudflare.com`) que redirige directamente a tu instancia local.

2. **Usando ngrok:**
   ```bash
   ngrok http 3000
   ```

### Opción B: Despliegue en Servidor Dedicado con Reverse Proxy (Nginx + SSL) — *Recomendado para producción local*

Si posees un servidor local con IP pública o un VPS, configura un proxy inverso con Nginx para gestionar las peticiones HTTP, WebSockets y SSE:

```nginx
server {
    listen 80;
    server_name terminator.tu-dominio.com;

    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name terminator.tu-dominio.com;

    ssl_certificate /etc/letsencrypt/live/terminator.tu-dominio.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/terminator.tu-dominio.com/privkey.pem;

    client_max_body_size 50M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Soporte para streaming SSE y WebSockets prolongados
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
    }
}
```

---

## 6. Consumo de la API de Terminator II

Una vez expuesto el servidor, puedes interactuar programáticamente con su API mediante clientes tRPC o peticiones HTTP a los endpoints integrados:

- **Chat multimodal con orquestación:** `POST /api/trpc/terminator.chat`
- **Consulta y guardado de configuración:** `GET/POST /api/trpc/terminator.getConfig` y `saveConfig`
- **Proxy de metadatos Kokoro:** `/api/terminator/kokoro/health`, `/voices`, `/models`
- **Canales y Webhooks:**
  - WhatsApp: `POST /webhook/whatsapp`
  - Telegram: `POST /webhook/telegram`
  - SMS Twilio: `POST /webhook/sms`
  - Voz Twilio (ConversationRelay): `POST /twiml` y WebSocket `/ws/voice`

## 7. Proveedores, cuentas y recursos opcionales del usuario

La instalación local funciona sin proveedores cloud: usa Ollama, LM Studio, Kokoro, Coqui, Silero, Piper y el gateway de vídeo configurado en `localhost`. Cuando una persona desea usar un servicio externo, debe introducir **sus propias credenciales** en Configuración → **Claves API** o registrar un recurso en Configuración → **Proveedores**. Terminator II no incorpora ni comparte claves de un operador central.

| Caso de uso | Qué registra el usuario | Recurso asociado | Cuándo exponer una URL pública |
|---|---|---|---|
| ElevenLabs | API key propia y tipo de autenticación | `voice_id` de una voz autorizada | No es necesario solo para salida TTS desde el servidor local |
| Twilio | SID, token/API key y número propio | Número, sala de vídeo o flujo de voz | Sí, para recibir SMS/voz/video mediante webhook |
| Meta WhatsApp | Token, Phone Number ID y token de verificación propios | Cuenta y número de negocio | Sí, para verificación y eventos webhook |
| Telegram | Token generado por BotFather | Bot del propietario | Sí para webhook; no si se usa sondeo explícito fuera de esta aplicación |
| X u otro proveedor | Identificador, endpoint, auth y secreto propios | Cuenta, modelo, bot o recurso autorizado | Solo si el proveedor envía callbacks hacia Terminator II |
| Gateway privado | URL local/LAN y token opcional | Workflow, voz, modelo o servicio específico | No; mantener en `localhost` o red privada siempre que sea posible |

El panel incluye plantillas de alta rápida para **Meta / WhatsApp Business**, **Telegram Bot**, **X API o gateway compatible**, **Twilio SMS / Voice / Video** y **Gateway privado / otra cuenta**. Estas plantillas solo rellenan categoría, identificador, endpoint y recurso de referencia; el usuario debe sustituir los valores y aportar su propia credencial antes de guardar.

El catálogo no invoca automáticamente a un servicio registrado. Guarda la configuración aislada por usuario, oculta el secreto en las respuestas y permite activar o desactivar cada entrada. Antes de usar una voz, cuenta social o activo de terceros, verifica que tienes el permiso, la licencia y el consentimiento necesarios.

Para usar un entorno de inferencia propio dentro de una conversación, el usuario debe iniciar sesión, registrar un proveedor con categoría **LLM**, URL compatible con OpenAI y, opcionalmente, identificador de modelo. Si permanece habilitado, aparece en el selector **Entorno LLM propio** del chat. Al seleccionarlo, Terminator II resuelve el proveedor solo por el `userId` autenticado, descifra su credencial exclusivamente en el servidor y la transmite al adaptador OpenAI-compatible; nunca la devuelve al navegador. Si el gateway falla, el orquestador conserva el fallback estándar configurado.

El mismo patrón está disponible para una voz personal o autorizada. El usuario registra un proveedor de categoría **TTS** con endpoint OpenAI-compatible y, si lo necesita, el `resourceId` de voz. En el selector **Voz o entorno propio** del chat solo aparecen proveedores TTS activos de ese usuario. El servidor llama a `/v1/audio/speech` usando el recurso y la credencial descifrada en memoria, sin exponerla al cliente; si el proveedor no responde, continúa la cadena de TTS estándar.

Para vídeo, el usuario registra un proveedor de categoría **video** cuyo endpoint implemente el contrato del gateway local (`POST /generate`). El `resourceId` identifica el workflow —por ejemplo Wan, LTX o ComfyUI— y el secreto opcional se envía como Bearer únicamente desde el servidor. Al elegir **Gateway de vídeo propio**, el chat activa vídeo y usa ese gateway aislado por usuario; si falla, se preserva el fallback de vídeo configurado.

Los proveedores de categoría **translation** también se pueden seleccionar mediante el procedimiento de traducción Realtime. El servidor verifica la propiedad y el estado habilitado, registra el endpoint HTTP y usa el secreto solo en memoria para el adaptador `custom-translator`. Esta selección no altera los traductores de otros usuarios ni expone tokens al cliente.

Para voz bidireccional, una cuenta registrada con categoría **realtime** puede usar una de las claves compatibles `openai-realtime`, `moshi-local`, `gemini-live` o `elevenlabs-agents`. La pantalla Realtime muestra las cuentas habilitadas; al elegir una, el ticket efímero incorpora únicamente el backend, endpoint, modelo/recurso y secreto de esa cuenta. El WebSocket comprueba que el backend solicitado coincide con el incluido en el ticket antes de conectar.

El panel de proveedores ofrece **Probar conexión** para entradas que contienen un endpoint HTTP(S). La comprobación utiliza `HEAD`, tiene un límite de tiempo, no sigue redirecciones y no adjunta el secreto almacenado. Se bloquean destinos de metadata reservados; la disponibilidad de red no sustituye la autenticación real, que se valida cuando el adaptador específico use la cuenta.

En producción, los webhooks de canales no aceptan eventos sin autenticación. **Meta/WhatsApp** exige que el challenge coincida con el Verify Token y que los `POST` contengan una firma `X-Hub-Signature-256` válida contra el App Secret. **Telegram** exige que `X-Telegram-Bot-Api-Secret-Token` coincida con el Secret Token configurado. **Twilio** exige una firma `X-Twilio-Signature` válida, calculada sobre la URL pública canónica. Configura el protocolo y host públicos de forma correcta en el proxy inverso para que la validación Twilio use la misma URL registrada en su consola.

Los secretos de los proveedores añadidos al catálogo y las credenciales configuradas en Terminator II se cifran antes de persistirse mediante AES-256-GCM y una clave local (`PROVIDER_ENCRYPTION_KEY` o `JWT_SECRET`). Conserva esa clave en el entorno del servidor; si cambia, los secretos ya cifrados no podrán recuperarse.

## 8. Exposición mínima y segura

Para una instalación personal, mantén la aplicación y todos los gateways en `127.0.0.1` o LAN. Expón un túnel HTTPS o un reverse proxy únicamente para los canales que realmente necesiten webhooks. No publiques ComfyUI, Ollama, Kokoro ni el gateway de vídeo directamente en Internet; publícalos solo detrás de una autenticación de red o VPN. Conserva secretos en el panel del usuario o variables locales, y no los copies a código fuente, archivos ZIP compartidos ni consultas del navegador.

---

## 9. Referencias

[1] [remsky/Kokoro-FastAPI — Documentación oficial y despliegue Docker](https://github.com/remsky/Kokoro-FastAPI)  
[2] [Cloudflare Tunnels — Exposición segura de servicios locales](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/)  
[3] [tRPC 11 — Documentación de contratos end-to-end](https://trpc.io/)
