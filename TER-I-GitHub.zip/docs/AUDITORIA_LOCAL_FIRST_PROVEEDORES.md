# Auditoría local-first — proveedores por usuario en TER I

> TER I es el nombre público del runtime de inferencia de tercera generación. Terminator II permanece como referencia técnica interna de la implementación multimodal. Esta auditoría cubre cuentas propias, aislamiento y canales configurables.

**Fecha:** 16 de agosto de 2026  
**Alcance:** distribución standalone, panel de configuración, canales, modelos locales y catálogo de proveedores opcionales por usuario.  
**Estado de validación:** 136 pruebas Vitest aprobadas en 31 archivos; comprobación TypeScript y build de producción correctos.

## Resumen ejecutivo

Terminator II cuenta con una base sólida para operación **local-first**. Las rutas predeterminadas de Ollama, LM Studio, Kokoro, Coqui, Silero y Piper apuntan a `localhost`; no requieren una cuenta externa y pueden mantenerse dentro de la red privada. Los modelos cloud, canales y proveedores de voz externos son optativos: su uso solo se activa cuando el propietario introduce sus credenciales en la configuración.

El proyecto ya mantenía claves por usuario en navegador y, bajo sesión autenticada, en la configuración del servidor. Esta iteración añade `user_providers`, un catálogo extensible con aislamiento por `userId`, endpoint opcional, tipo de autenticación, recurso asociado y secreto oculto al consultar la API. Ello permite registrar cuentas propias de X, Meta, Telegram, Twilio, ElevenLabs u otros servicios sin incorporar credenciales compartidas ni crear una integración rígida para cada caso.

> **Conclusión:** la rama standalone satisface la separación entre ejecución local y recursos externos opcionales. Aún no ejecuta automáticamente cada proveedor genérico registrado: el catálogo conserva la configuración y los identificadores de recurso; los adaptadores específicos deben habilitarse por categoría y contar con sus pruebas antes de enviar tráfico a dichos servicios.

## Matriz de capacidades y peticiones

| Área | Implementado hoy | Configuración de usuario | Petición o recurso | Estado |
|---|---|---|---|---|
| LLM local | Ollama y LM Studio | URL local, por defecto `localhost` | OpenAI-compatible / API local | Operativo |
| TTS local | Kokoro, Coqui, Silero, Piper | URL y token Kokoro opcional | HTTP/SSE local | Operativo |
| STT | Grok y Whisper con fallback | API xAI u OpenAI opcional | Audio a API cloud | Operativo; no requiere uso cloud si no se configura |
| Vídeo local | Gateway Wan2/LTX/custom | Endpoint y workflow local | `POST /generate` | Operativo y probado |
| LLM/TTS/Vídeo cloud | Grok y OpenAI donde aplica | Claves individuales | HTTPS a proveedor | Opcional |
| Realtime | OpenAI, Moshi, Gemini, ElevenLabs, custom | Claves y endpoint propios | WebSocket/HTTP | Operativo por adaptador |
| Traducción | Google, DeepL, Alia/local/custom | Claves o endpoint local | HTTP | Operativo por adaptador |
| Twilio | SMS, voz y vídeo | SID, token, API key y número propios | REST, webhooks y WebRTC | Operativo; requiere URL pública para webhooks |
| WhatsApp/Meta | Webhook y mensajería Cloud API | Token, Phone Number ID y verify token propios | Graph API + webhook | Operativo; requiere configuración externa |
| Telegram | Bot webhook | Token de BotFather propio | HTTPS Bot API + webhook | Operativo; requiere URL pública para webhook |
| Catálogo extensible | `user_providers` y panel Proveedores | Nombre, categoría, auth, endpoint, secreto, recurso | Prueba HTTP `HEAD` sin secreto | Operativo y aislado |
| Webhooks de canales | Meta/WhatsApp, Telegram y Twilio | Tokens de verificación y firma por operador | HMAC Meta, Secret Token Telegram, firma Twilio | Endurecido y cubierto por pruebas |
| Entorno LLM del usuario | Selector de chat para proveedores LLM habilitados | ID de proveedor propio y modelo opcional | OpenAI-compatible desde servidor | Operativo, aislado y con fallback |
| Voz propia del usuario | Selector de chat para proveedores TTS habilitados | ID de proveedor propio y voz opcional | OpenAI-compatible `/v1/audio/speech` desde servidor | Operativo, aislado y con fallback |
| Gateway de vídeo del usuario | Selector de chat para proveedores de vídeo habilitados | ID de proveedor y workflow opcional | `POST /generate` desde servidor | Operativo, aislado y con fallback |
| Traductor del usuario | Procedimiento de traducción Realtime | ID de proveedor y endpoint propio | HTTP custom desde servidor | Operativo, aislado y probado |
| Backend de voz Realtime del usuario | Selector de Realtime y ticket efímero | Proveedor `realtime` habilitado con clave de backend compatible | WebSocket bloqueado al ticket | Operativo, aislado y probado |
| Voces ElevenLabs | Clave y `resourceId` de voz en catálogo | API key y `voice_id` propios | Preparado para adaptador específico | Configurable; envío automático pendiente |

## Recursos externos y personalización

El catálogo permite guardar un `resourceId` junto con la cuenta. Para ElevenLabs, el usuario puede registrar su clave y el identificador de una voz personal, de espacio de trabajo o autorizada. La API oficial permite listar voces disponibles al usuario y devuelve su `voice_id`; Terminator II no afirma que una voz sea utilizable sin los permisos, la clave y los términos de la cuenta correspondiente [1].

Los canales están igualmente condicionados a recursos del usuario. Meta Cloud API utiliza tokens y webhooks para mensajería, y su documentación exige que el operador configure sus activos de negocio; Terminator II solo guarda y consume dichos valores cuando el propietario lo habilita [2]. Telegram entrega a cada bot un token propio y permite recibir actualizaciones mediante webhook HTTPS; el modo webhook y `getUpdates` son excluyentes [3]. Twilio expone APIs REST y webhooks para comunicaciones y requiere credenciales propias de la cuenta [4].

## Hallazgos de auditoría

| Prioridad | Hallazgo | Evidencia | Acción recomendada |
|---|---|---|---|
| Importante | Los secretos de `user_providers` y las credenciales de `terminator_config` se cifran con AES-256-GCM usando `PROVIDER_ENCRYPTION_KEY` o `JWT_SECRET`. | Pruebas `provider-secret.test.ts`; las respuestas al cliente mantienen masking y solo exponen presencia. | Definir y custodiar una clave de cifrado dedicada y estable para despliegues multiusuario. |
| Crítica | Los webhooks de Meta, Telegram y Twilio requieren una URL pública HTTPS; `localhost` no es alcanzable para esos proveedores. | Naturaleza de los webhooks documentada por Meta, Telegram y Twilio [2] [3] [4]. | Usar túnel HTTPS o reverse proxy TLS únicamente al activar ese canal. |
| Importante | LLM, TTS, vídeo, traducción y Realtime ya se resuelven para recursos propios; los canales aún no se resuelven genéricamente desde el catálogo. | Los IDs se resuelven por `userId`, se descifran solo en servidor y usan fallback estándar. | Extender el resolvedor por categoría con pruebas contractuales antes de activar tráfico adicional. |
| Importante | `localStorage` es conveniente para uso sin inicio de sesión, pero no equivale a un almacén seguro frente a código ejecutado en el mismo origen. | Diseño actual del hook `useApiKeys`. | Ofrecer modo «solo sesión» por defecto en instalación local y advertencia explícita en UI. |
| Resuelto | El panel permite comprobar la disponibilidad HTTP de un proveedor propio sin enviar su credencial. | `testUserProvider` limita HTTP(S), bloquea destinos de metadata, usa timeout y no sigue redirecciones. | Mantener la prueba como verificación de red; la autorización del proveedor se valida en el adaptador que lo use. |
| Mejora | La integración de voces de terceros debe tratarse como recurso autorizado, no como voz de identidad pública. | `resourceId` es genérico y no valida derechos. | Mostrar aviso de consentimiento, licencia y derechos de uso al registrar una voz. |

## Mejoras priorizadas

La prioridad inmediata es **validar URL HTTPS para webhooks y añadir pruebas de conectividad sin exfiltrar claves**. A continuación debe integrarse el resolvedor de proveedores por categoría, empezando por ElevenLabs TTS, un endpoint local/custom de traducción y una cuenta social que haya sido configurada por su propietario. Finalmente, la rama identificada V4 podrá incorporar sincronización, memoria y auditoría de consentimiento, sin alterar la garantía de sesiones efímeras de la rama standalone.

## Referencias

[1] [ElevenLabs — List voices API](https://elevenlabs.io/docs/api-reference/voices/search)  
[2] [Meta for Developers — WhatsApp Business Platform](https://developers.facebook.com/documentation/business-messaging/whatsapp/about-the-platform)  
[3] [Telegram — Bot API](https://core.telegram.org/bots/api)  
[4] [Twilio — API overview](https://www.twilio.com/docs/usage/api)
