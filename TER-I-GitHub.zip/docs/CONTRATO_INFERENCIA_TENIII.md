# Contrato de inferencia tenIII para Terminator II

## Objetivo de la ampliación

Esta fase extiende Terminator II como **orquestador de inferencia local configurable**. No ejecuta pesos tenIII dentro del proceso Node.js; en su lugar registra artefactos y adaptadores, valida su compatibilidad, aplica una política de recursos y delega la inferencia en un runtime local compatible (Ollama, llama.cpp, vLLM, servidor Python tenIII o HTTP personalizado). Este límite evita prometer soporte de formatos binarios que el proceso web no puede cargar de forma segura.

| Módulo | Responsabilidad pública | Dependencias |
|---|---|---|
| `ModelRegistry` | Persistir y listar modelos por usuario, tipo, formato, idioma y endpoint | Drizzle/MySQL |
| `ModelLoader` | Resolver un modelo a un descriptor de carga y comprobar disponibilidad | Registro + HTTP opcional |
| `AdapterManager` | Validar y componer referencias LoRA/QLoRA para un modelo base | Registro + runtime compatible |
| `ResourceManager` | Elegir perfil CPU/GPU y cuantización permitida según límites declarados | Sin GPU obligatoria |
| `LocalInferenceRouter` | Convertir una selección validada en una llamada al backend local | Contrato HTTP local |

## Modelo de datos

Cada `custom_model` pertenece a un usuario y no comparte claves ni rutas privadas entre usuarios. Sus campos mínimos son: `name`, `kind`, `format`, `endpoint`, `modelPath`, `languages`, `capabilities`, `resourceProfile`, `enabled` y `config`. Cada `model_adapter` pertenece a un modelo base y declara `kind`, `format`, `pathOrUrl`, `weight` y `enabled`.

| Tipo de modelo | Formatos aceptados | Runtime esperado |
|---|---|---|
| LLM | `gguf`, `safetensors`, `ollama`, `api` | llama.cpp/Ollama/vLLM/servidor tenIII |
| TTS | `kokoro`, `coqui`, `silero`, `piper`, `api` | Gateway TTS HTTP |
| STT | `whisper`, `api` | Gateway STT HTTP |
| Video | `wan`, `ltx`, `cogvideo`, `api` | Gateway de vídeo HTTP |

## Invariantes de seguridad

El registro no acepta comandos shell, no ejecuta rutas entregadas por el navegador y no concede acceso de archivo al proceso web. Los paths locales representan una referencia que solo puede interpretar un gateway local explícitamente configurado. Las peticiones de inferencia se limitan a modelos habilitados propiedad del usuario autenticado.

## Criterios de aceptación

La implementación debe permitir registrar modelos y adaptadores, resolver una configuración reproducible de inferencia, rechazar formatos incompatibles y producir telemetría de selección. Las pruebas deben cubrir compatibilidad de formato, composición de adaptadores, políticas de recursos y aislamiento por usuario. Cargar pesos reales, gestionar VRAM real, entrenar o sincronizar con Warfare.net requiere un runtime tenIII local o la rama V4 identificada.
