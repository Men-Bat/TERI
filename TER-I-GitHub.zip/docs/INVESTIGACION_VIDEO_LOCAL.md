# Investigación de vídeo local — Terminator II

**Fecha:** 16 de agosto de 2026  
**Autor:** Manus AI

## Decisión de integración

La integración local debe usar un contrato de **gateway configurable**, no acoplar Terminator II a pesos ni flujos internos de un único motor. ComfyUI es una capa de orquestación adecuada para este propósito, ya que permite instalar flujos de vídeo y nodos específicos. El adaptador de Terminator debe recibir un endpoint, un identificador de workflow y parámetros de texto/imagen de referencia; el gateway ejecuta el workflow y devuelve el artefacto.

## Opciones verificadas

| Opción | Integración recomendada | Límite operativo |
|---|---|---|
| LTX-2 mediante ComfyUI | Gateway ComfyUI con workflow T2V/I2V configurado por el operador | El repositorio de nodos declara GPU CUDA de 32 GB+ y almacenamiento amplio para su flujo completo [1] |
| CogVideoX mediante ComfyUI | Mismo contrato de workflow configurable | El modelo, nodos y requisitos dependen del workflow instalado |
| Wan, Mochi o Hunyuan | Adaptador HTTP genérico o workflow ComfyUI | No se deben asumir una imagen Docker ni un endpoint uniforme |

> Terminator II no descarga pesos ni ejecuta modelos de vídeo en el proceso web. El operador configura el gateway local y los workflows que correspondan a sus recursos.

## Referencias

[1] [Lightricks/ComfyUI-LTXVideo — workflows, requisitos y nodos](https://github.com/Lightricks/ComfyUI-LTXVideo)

[2] [Wan-Video/Wan2.1 — modelos, tareas y requisitos de inferencia](https://github.com/Wan-Video/Wan2.1)

[3] [ComfyUI — workflows oficiales Wan2.1](https://docs.comfy.org/tutorials/video/wan/wan-video)

[4] [ComfyUI — workflows oficiales Wan2.2](https://docs.comfy.org/tutorials/video/wan/wan2_2)

[5] [Tencent Hunyuan — HunyuanVideo-1.5](https://github.com/Tencent-Hunyuan/HunyuanVideo-1.5)

[6] [Z.ai — CogVideo y CogVideoX](https://github.com/zai-org/CogVideo)

[7] [Genmo — Mochi 1](https://github.com/genmoai/mochi)

[8] [MiniMax — H3 open source](https://www.minimax.io/news/minimax-h3-open-source)

## Actualización: motores Wan y contrato de gateway

La investigación oficial confirma que Wan2.1 ofrece tareas de texto-a-vídeo, imagen-a-vídeo, primer-último fotograma y edición; su variante T2V 1.3B se orienta a GPU de consumo. Wan2.2 añade flujos TI2V, T2V, I2V y primer-último fotograma documentados por ComfyUI. Por ello, Terminator II mantiene los valores de motor `wan2`, `ltx` y `custom`, mientras que el campo `localVideoWorkflow` debe distinguir la variante concreta, por ejemplo `wan21-t2v-1.3b`, `wan22-ti2v-5b` o un workflow de ComfyUI.

El contrato estable de Terminator II es `POST /generate` en un gateway controlado por el operador. El gateway recibe prompt, imagen o vídeo de referencia opcionales, duración, relación de aspecto y workflow, ejecuta el runtime local y devuelve una URL de salida. Este aislamiento evita que el proceso web descargue pesos o ejecute modelos de GPU y permite sustituir Wan, LTX u otros motores sin alterar el orquestador.

> El endpoint debe permanecer en `127.0.0.1`, una LAN de confianza o una VPN. La exposición pública directa de ComfyUI o de un runtime de vídeo no forma parte del diseño de producción.

## Actualización: matriz de selección operativa

| Motor | Evidencia de ejecución local | Recomendación para el gateway | Consideración principal |
|---|---|---|---|
| **LTX** | El wrapper de ComfyUI está documentado en la referencia [1]. | `ltx` con un workflow versionado por el operador. | Verificar pesos, nodo y memoria del workflow concreto. |
| **Wan 2.1/2.2** | Fuentes oficiales de modelo y flujos nativos en ComfyUI [2] [3] [4]. | `wan2` con workflows como `wan21-t2v-1.3b` o `wan22-ti2v-5b`. | Es la ruta inicial recomendada para el gateway por sus flujos oficiales. |
| **HunyuanVideo 1.5** | Repositorio oficial con T2V/I2V, soporte ComfyUI y mínimo declarado de 14 GB con offload [5]. | `custom` con workflow `hunyuan15-t2v` o `hunyuan15-i2v`. | El HunyuanVideo original requiere mucha más VRAM; se prioriza la variante 1.5. |
| **CogVideoX** | Repositorio oficial con T2V, I2V, continuación, Diffusers y wrapper ComfyUI [6]. | `custom` con workflow `cogvideox-2b`, `5b` o `1.5-i2v`. | La documentación señala prompts en inglés; reutilizar el traductor configurable cuando proceda. |
| **Mochi 1** | Código, pesos locales, CLI/API y nodo ComfyUI disponibles oficialmente [7]. | `custom` con workflow `mochi-t2v`. | El runtime nativo declara ~60 GB VRAM en una GPU; ComfyUI puede reducir ese requisito. |
| **MiniMax H3** | La fuente oficial describe pesos H3 Base ejecutables localmente mediante SGLang, vLLM, Diffusers o ComfyUI [8]. | `custom` con workflow `minimax-h3-base`; separar cualquier flujo híbrido de API. | Las piezas Context-IR y regeneración 2K permanecen hospedadas, así que no se debe etiquetar el flujo 2K completo como local. |

Las opciones **HunyuanVideo, CogVideoX, Mochi y MiniMax H3** se exponen deliberadamente a través de `custom` y no requieren código específico en el orquestador. El administrador selecciona pesos, runtime y workflow en su gateway, mientras Terminator II envía el contrato común y conserva el fallback cloud existente.
