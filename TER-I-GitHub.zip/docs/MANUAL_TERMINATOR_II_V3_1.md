# Manual Operativo — TER I v3.1

> TER I es el modelo/runtime de inferencia de tercera generación para tenIII. En este documento, las referencias históricas a Terminator II identifican la implementación técnica heredada que compone el runtime TER I. Standalone

**Fecha de actualización:** 16 de agosto de 2026  
**Ámbito:** inferencia multimodal independiente, local-first o mediante proveedores configurables.  
**Autor:** Manus AI

## Resumen

Terminator II v3.1 es un orquestador multimodal con chat web, WhatsApp, Telegram, SMS, voz y vídeo. La versión conserva la cadena de TTS con Kokoro, Coqui XTTS, Silero, Grok, OpenAI y Piper; añade una capa Realtime intercambiable, traducción configurable y un modo local explícito. La memoria de una sesión web sigue siendo efímera: el sistema standalone no implementa todavía una memoria persistente de usuario, RAG ni entrenamiento relacional.

| Área | Capacidades disponibles | Configuración requerida |
|---|---|---|
| TTS local | Kokoro, Coqui XTTS, Silero y Piper con fallback por idioma | URL del gateway local; Kokoro puede requerir token Bearer |
| Idiomas | Kokoro: 10 códigos normalizados; Coqui: árabe y ruso incluidos; Silero: ruso y ucraniano incluidos | Seleccionar `auto`, o fijar backend compatible |
| Realtime | OpenAI Realtime, Moshi local, Gemini Live y ElevenLabs Agents | Credencial o endpoint, salvo Moshi local |
| Traducción | Gateway local/Alia/NLLB/Marian, Google Translate, DeepL o HTTP personalizado | Endpoint o clave del proveedor elegido |
| Canales | Web, WhatsApp, Telegram, SMS, Twilio Voice y Twilio Video | Credenciales y webhooks externos por canal |

## TTS, idiomas y fallback

Kokoro es la primera opción local para los idiomas que soporta el gateway. Si el idioma no está disponible —como ruso o árabe— Terminator II omite Kokoro y continúa con Coqui XTTS o Silero si están configurados. Esta regla evita sintetizar en un idioma no soportado y está cubierta por pruebas de regresión de ruso.

| Idioma | Kokoro | Coqui XTTS | Silero | Ruta `auto` esperada |
|---|---:|---:|---:|---|
| Español, inglés, alemán, francés | Sí | Sí | Sí | Kokoro local, después Coqui/Silero |
| Árabe | No | Sí | No | Coqui XTTS |
| Ruso | No | Sí | Sí | Coqui XTTS; Silero como fallback |
| Ucraniano | No | Sí | Sí | Coqui XTTS; Silero como fallback |
| Japonés, coreano, chino | Sí | Sí | No | Kokoro local, después Coqui |

> Kokoro-FastAPI documenta un endpoint compatible con OpenAI para síntesis, imágenes CPU y NVIDIA GPU, y documentación OpenAPI local en el propio servicio. [1]

### Configuración de Kokoro

La sección **TTS / STT local** del panel de claves permite guardar `kokoroUrl` y `kokoroApiKey`. La clave se transporta solo desde el servidor como `Authorization: Bearer …`; la respuesta de configuración está enmascarada y el navegador no recibe el valor persistido.

| Opción | Efecto |
|---|---|
| `KOKORO_URL` | URL por defecto del servidor Kokoro, normalmente `http://localhost:8880` |
| `KOKORO_API_KEY` | Token opcional para un gateway protegido |
| `KOKORO_LOCAL_ONLY=true` | Bloquea síntesis, health y metadata si la URL no es `localhost`, `127.0.0.1`, `::1` o un dominio `.local` |
| `volume_multiplier` | Se limita a `0.1–2.0` antes de enviar la solicitud |
| `stream_format: "sse"` | Habilita el parser de audio SSE cuando el gateway lo expone |

Terminator II detecta ambas rutas de voces usadas por gateways Kokoro: primero consulta `/v1/voices` y, ante un `404`, usa `/v1/audio/voices`, que es la ruta OpenAI-compatible publicada por el upstream. [1]

### Endpoints de capacidad de Kokoro

El servidor Express no asume que Swagger externo esté disponible. Expone sus propios proxies normalizados:

| Endpoint | Resultado |
|---|---|
| `GET /api/terminator/kokoro/health` | Estado, capacidades declaradas y modelos recuperados del gateway |
| `GET /api/terminator/kokoro/models` | Metadata de `/v1/models` |
| `GET /api/terminator/kokoro/voices` | Voces, con compatibilidad de rutas upstream |

Si está activo el modo local y la URL no es local, esos endpoints responden `503` sin intentar una conexión externa. Si el gateway no está disponible, responden `502` y no filtran claves.

## Conversación Realtime y traducción

La ruta `/terminator/realtime` crea un ticket efímero de un solo uso, conecta con `/ws/realtime` y transmite audio PCM16. El ticket expira en 60 segundos, mantiene las credenciales en el servidor y bloquea que el navegador cambie el backend fijado por la sesión. La interfaz permite seleccionar backend, idioma y una cuenta Realtime propia habilitada; el servidor resuelve el proveedor exclusivamente por `userId`, descifra su secreto en memoria y fija endpoint, modelo y backend dentro del ticket.

| Backend | Tipo | Consideración de privacidad |
|---|---|---|
| Moshi local | Gateway open source local | La opción local recomendada; requiere que el usuario opere un gateway compatible |
| OpenAI Realtime | API cloud | Requiere clave OpenAI o endpoint firmado |
| Gemini Live | API cloud | Requiere clave Gemini o endpoint configurado |
| ElevenLabs Agents | API cloud | Requiere clave ElevenLabs o endpoint configurado |

El fallback Realtime está **desactivado por defecto**. Activarlo es una decisión explícita: evita que una conversación configurada para local transfiera audio a un proveedor cloud sin consentimiento. La traducción sigue el mismo patrón mediante `TranslatorManager`, con adaptadores para gateway local (incluido un contrato para Alia/NLLB/Marian), Google, DeepL y un endpoint HTTP personalizado. Un traductor propio de categoría `translation` se resuelve de forma aislada en el procedimiento de traducción Realtime y su secreto nunca vuelve al cliente.

## Despliegue local de Kokoro

El directorio `deploy/` contiene un Compose aislado del hosting web gestionado. No modifica el contenedor de la aplicación ni exige GPU para el perfil CPU.

```bash
cp deploy/kokoro.env.example deploy/kokoro.env

# CPU, sin GPU
docker compose --env-file deploy/kokoro.env \
  -f deploy/docker-compose.kokoro.yml --profile cpu up -d

# NVIDIA CUDA, con NVIDIA Container Toolkit instalado
docker compose --env-file deploy/kokoro.env \
  -f deploy/docker-compose.kokoro.yml --profile cuda up -d

curl http://localhost:8880/v1/models
```

Los perfiles usan las imágenes públicas `ghcr.io/remsky/kokoro-fastapi-cpu` y `ghcr.io/remsky/kokoro-fastapi-gpu`. Definen `DOWNLOAD_MODEL=false` porque las imágenes publicadas incluyen modelos; si se sustituye por un build local o se monta un directorio de modelos vacío, los pesos deben aprovisionarse antes del arranque. El upstream indica que `DOWNLOAD_MODEL` controla la descarga al construir e iniciar y recomienda fijar un tag de versión en despliegues estables. [2]

> Coqui, Silero y Moshi siguen siendo backends HTTP configurables, no contenedores incluidos en este Compose. Sus imágenes, licencias y contratos varían entre wrappers; Terminator II no inventa una imagen no validada para declararla soportada.

## Operación y validación

La suite se ejecuta así:

```bash
pnpm test
pnpm build
pnpm db:push
```

La validación actual cubre **136 pruebas en 31 archivos**, además de comprobación TypeScript y compilación de cliente y servidor. La suite incluye aislamiento de proveedores propios LLM, TTS, vídeo, traducción y Realtime, una comprobación HTTP sin credenciales y la garantía de que sus secretos no se exponen al navegador.

### Iteración tenIII: registro y selección local

El panel **Modelos tenIII** permite registrar, listar, activar/desactivar y eliminar descriptores de modelos aislados por usuario. Los endpoints HTTP registrados se comprueban desde el servidor con un tiempo máximo de espera y bloqueo explícito de endpoints de metadatos reservados. Si un gateway LLM tenIII seleccionado no responde durante la inferencia, Terminator II vuelve al backend estándar configurado sin exponer credenciales al navegador. Los chats web anónimos usan una sesión efímera y no escriben conversación ni mensajes en base de datos; los canales identificados conservan su ruta de persistencia normal.

### Vídeo local y continuación

La preferencia de vídeo permite escoger **Wan2, LTX o gateway personalizado**, configurar un endpoint de confianza y un identificador de workflow. El gateway recibe `POST /generate` con prompt, referencias multimedia opcionales, duración y relación de aspecto. Una respuesta con vídeo puede continuarse desde el chat web activando **Continuar vídeo**; el siguiente mensaje transmite el último vídeo generado como referencia. Grok Video y el gateway local reciben las referencias de imagen y vídeo a través del mismo contrato de orquestación.

### Caché y privacidad standalone

La caché de Terminator II permanece en `localStorage` del navegador y puede limpiarse desde Configuración. No se replica en base de datos en la rama standalone, para preservar el carácter efímero de las sesiones anónimas. La sincronización o cacheo identificado requiere la rama V4/Warfare.net con consentimiento, permisos y retención explícitos.

## Límites reales y siguiente rama

Terminator II v3.1 incorpora ahora un registro de runtime tenIII con `ModelLoader`, composición de adaptadores y una política de recursos. No carga pesos directamente en el proceso web: delega el cálculo en un gateway HTTP o runtime local explícitamente configurado. LM Studio se valida mediante su contrato OpenAI-compatible (`/v1/models` y `/v1/chat/completions`). Siguen fuera de este release la memoria persistente, RAG, memoria relacional, entrenamiento por feedback y sincronización Warfare.net; requieren una rama con identidad, consentimiento, permisos y auditoría separados.

## Referencias

[1] [remsky/Kokoro-FastAPI — README y API OpenAI-compatible](https://github.com/remsky/Kokoro-FastAPI)  
[2] [remsky/Kokoro-FastAPI — configuración de Docker y variables de modelo](https://github.com/remsky/Kokoro-FastAPI/blob/master/docs/configuration.md)
