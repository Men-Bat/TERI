# Notas de auditoría de producción — TER I

## Hallazgos conservados del estado reciente

| Fuente | Hallazgo conservado |
|---|---|
| `todo.md` revisado el 2026-08-16 | Permanecían pendientes externos relacionados con secretos de producción, webhooks, GPU para vídeo local, fine-tuning de voz y la rama V4 de memoria/RAG. |
| `docs/INDEX.md` | La documentación consolidada ya enlaza manual, despliegue local, auditoría de proveedores, plantilla de entorno y companion PyPI. |
| `docs/GUIA_DESPLIEGUE_LOCAL_API.md` | El runtime local-first ya documenta proveedores propios, exposición segura por HTTPS y el uso de `PROVIDER_ENCRYPTION_KEY`. |
| `client/src/components/UserProviderManager.tsx` | El panel de proveedores ya permite cuentas opcionales por usuario, prueba de conectividad sin secreto y ahora se está ampliando con plantillas para Meta/WhatsApp, Telegram, X y Twilio. |

## Criterios de cierre para esta auditoría

Se comprobará que los artefactos finales no incluyan secretos, que los ZIP excluyan `node_modules`, `dist`, `.env` y registros temporales, que la identidad pública sea **TER I**, que la distribución PyPI sea un companion/runtime y no una librería genérica, y que la suite de pruebas y la compilación de producción permanezcan en verde antes del checkpoint final.

