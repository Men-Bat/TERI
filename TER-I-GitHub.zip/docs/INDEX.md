# Índice de documentación — Terminator II v3.1

**Fecha de consolidación:** 16 de agosto de 2026  
**Validación de referencia:** 137 pruebas Vitest en 32 archivos, TypeScript y build de producción aprobados.

> **TER I** es el runtime de inferencia de tercera generación compatible con TenMiNaTor III y TenMiNaTor III-II. El nombre público del proyecto y de sus artefactos es TER I; el companion instalable de PyPI se identifica como `ter-i`.

## Guías principales

| Documento | Propósito | Cuándo usarlo |
|---|---|---|
| [Manual operativo v3.1](./MANUAL_TERMINATOR_II_V3_1.md) | Capacidades multimodales, TTS, Realtime, traducción, tenIII y operación local | Para conocer los flujos disponibles y sus límites |
| [Guía de despliegue local y API](./GUIA_DESPLIEGUE_LOCAL_API.md) | Instalación, variables, Docker Compose y exposición HTTPS | Antes de ejecutar Terminator II fuera de desarrollo |
| [Auditoría local-first de proveedores](./AUDITORIA_LOCAL_FIRST_PROVEEDORES.md) | Estado de proveedores, seguridad, cobertura y brechas | Para revisar qué puede usar cada usuario con sus propias cuentas |
| [Auditoría de producción TER I](./AUDITORIA_PRODUCCION_TER_I.md) | Riesgos corregidos, validación de webhooks y condiciones de lanzamiento | Antes de publicar o exponer canales al exterior |
| [Plantilla de entorno local](../deploy/ENVIRONMENT_LOCAL_TEMPLATE.md) | Variables sin valores secretos | Para crear el entorno de una instalación nueva |
| [Guía Kokoro local](../deploy/README_KOKORO_LOCAL.md) | Perfiles CPU/CUDA de Kokoro | Para habilitar TTS Kokoro en local |
| [Companion PyPI](../ter_i/README.md) | Instalación, identidad y CLI del runtime | Para instalar TER I sin pesos ni secretos |

## Flujos de operación

| Objetivo | Ruta recomendada |
|---|---|
| Chat anónimo local | Usar `/terminator`; la sesión no se persiste tras cerrar el chat |
| Proveedor LLM, TTS o vídeo propio | Registrar el proveedor autenticado en **Configuración → Proveedores** y elegirlo desde el chat |
| Traducción propia | Registrar categoría `translation`; invocar el flujo Realtime con el proveedor seleccionado |
| Voz Realtime propia | Registrar `realtime` con `openai-realtime`, `moshi-local`, `gemini-live` o `elevenlabs-agents`; seleccionarlo en `/terminator/realtime` |
| Verificar un endpoint propio | Usar **Probar conexión**; se hace un `HEAD` sin secreto, con timeout y bloqueo de metadata |
| Exponer canales externos | Seguir la guía local y configurar HTTPS público únicamente para el webhook necesario |

> Los secretos se cifran con AES-256-GCM antes de persistirse y no se devuelven al navegador. Las credenciales, webhooks, GPU y modelos que dependan de una cuenta o hardware externo siguen siendo responsabilidad del operador de cada instalación.

## Validación antes de desplegar

```bash
pnpm install
pnpm test
pnpm build
pnpm db:push
```

Para un entorno de producción, conserva `PROVIDER_ENCRYPTION_KEY` estable y distinta por instalación, no expongas gateways locales directamente a Internet y revisa las licencias de modelos, voces y datasets antes de usarlos.
