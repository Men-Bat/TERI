# Auditoría de producción — TER I v3.1

**Fecha:** 16 de agosto de 2026  
**Ámbito:** runtime web local-first, catálogo de proveedores, canales, webhooks, artefactos TER I y companion PyPI.  
**Resultado:** **apto para despliegue autogestionado de un operador**, condicionado a configurar las credenciales y los secretos de webhook propios antes de abrir rutas públicas.

## Resumen ejecutivo

TER I conserva la arquitectura local-first de la implementación multimodal previa y la presenta como runtime de inferencia compatible con modelos y adaptadores de tenIII de tercera generación. La auditoría confirma que el catálogo de proveedores se aísla por usuario, cifra secretos en reposo y no devuelve esos secretos al navegador. Las plantillas de alta aceleran la incorporación de cuentas propias de Meta/WhatsApp, Telegram, X-compatible, Twilio y gateways adicionales sin incluir claves compartidas.

Durante la revisión se corrigieron riesgos reales en los webhooks. La validación del challenge de Meta/WhatsApp ahora compara el Verify Token configurado; los eventos de Meta exigen HMAC `X-Hub-Signature-256`; Telegram exige un Secret Token de webhook y Twilio valida `X-Twilio-Signature` con una URL canónica. Los secretos añadidos se incorporaron a la capa AES-256-GCM de configuración.

| Área | Estado | Evidencia |
|---|---|---|
| Secretos de proveedores | Conforme | `provider-secret.ts`, pruebas de cifrado y contratos tRPC que enmascaran campos sensibles |
| Cuentas propias | Conforme | `UserProviderManager` con categorías extensibles y plantillas Meta, Telegram, X, Twilio y gateway privado |
| Meta/WhatsApp | Corregido | Verify Token, HMAC de cuerpo crudo y prueba de firma |
| Telegram | Corregido | Se exige `X-Telegram-Bot-Api-Secret-Token` y secreto configurado |
| Twilio SMS/TwiML | Corregido | Firma Twilio sobre URL canónica antes de procesar la petición |
| Artefacto PyPI | Conforme | wheel y sdist `ter-i` construidos; el wheel solo contiene el companion TER I y metadatos |
| Fuente GitHub | Conforme con exclusiones | El empaquetado final excluye dependencias, compilados, entornos y registros temporales |

## Hallazgos y correcciones

| Prioridad | Hallazgo original | Corrección aplicada | Estado |
|---|---|---|---|
| Crítica | El challenge de Meta/WhatsApp aceptaba cualquier Verify Token. | Se compara el valor entrante con `whatsappVerifyToken`. | Corregido |
| Crítica | Los `POST` de Meta y Telegram no autenticaban el origen. | Se añadieron HMAC Meta, `whatsappAppSecret` y `telegramWebhookSecret` cifrados. | Corregido |
| Importante | SMS y TwiML de Twilio podían procesarse sin firma. | Se validan con `twilio.validateRequest`, `X-Twilio-Signature` y URL canónica. | Corregido |
| Importante | La ubicación de `pyproject.toml` cambió al empaquetar TER I y una prueba apuntaba a la ruta anterior. | La prueba de artefactos ahora valida el metadato raíz que realmente genera wheel y sdist. | Corregido |
| Mejora | Las cuentas de canal requerían rellenar campos genéricos manualmente. | Se añadieron plantillas seleccionables, sin credenciales incluidas. | Corregido |

## Validación de lanzamiento

La suite de Vitest se ejecutó correctamente en **35 archivos** tras las correcciones, junto con `pnpm check`, compilación de producción y construcción de wheel/sdist. La distribución `ter_i-3.1.0-py3-none-any.whl` contiene exclusivamente `README`, CLI, metadatos y el módulo de identidad TER I. Un escaneo del contenido del wheel no detectó patrones de claves de API comunes.

> La evidencia de comandos, exclusiones y hallazgos intermedios se conserva en [NOTAS_AUDITORIA_PRODUCCION_TER_I.md](./NOTAS_AUDITORIA_PRODUCCION_TER_I.md). La auditoría no equivale a una certificación externa ni reemplaza pruebas de penetración en la red del operador.

## Condiciones obligatorias del operador

| Acción | Motivo |
|---|---|
| Definir `PROVIDER_ENCRYPTION_KEY` estable y privado | Permite recuperar secretos cifrados y evita que se almacenen en texto claro |
| Configurar Verify Token, App Secret de Meta, Secret Token de Telegram y Auth Token de Twilio | Sin estos valores los webhooks se rechazan deliberadamente |
| Publicar solo el servidor TER I bajo HTTPS | Las firmas dependen de una URL pública coherente y los proveedores requieren TLS |
| Ajustar `X-Forwarded-Proto` y `Host` en el proxy | Garantiza que la URL canónica usada para Twilio coincida con la registrada |
| Mantener Ollama, Kokoro, ComfyUI y gateways en localhost/VPN | Evita exponer runtimes locales y superficies no autenticadas a Internet |
| Revisar licencias y permisos de voces, modelos, cuentas y datos | Los recursos externos pertenecen al usuario u operador que los registra |

## Límite conocido de alcance

La recepción de webhooks incorporada usa la configuración del operador de la instancia. El catálogo `user_providers` permite que cada persona guarde cuentas y endpoints propios, pero el enrutamiento público multiusuario de callbacks de canales requiere un identificador de proveedor no adivinable, verificación específica por proveedor y límites de tasa; se mantiene fuera de este checkpoint para no introducir una ruta pública insegura. La rama V4 de memoria/RAG tampoco forma parte de TER I standalone.

## Conclusión

El checkpoint puede distribuirse como **TER I v3.1** para instalación local y despliegue autogestionado, siempre que el operador complete el checklist anterior. Los canales externos permanecen opcionales y fallan cerrados cuando falta su secreto de verificación.
