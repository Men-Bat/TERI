# Auditoría de producción — Terminator II v3.1 Standalone

**Fecha:** 16 de agosto de 2026  
**Autor:** Manus AI  
**Alcance:** código React/Express/tRPC, capa TTS, Realtime, traducción, migraciones y artefactos de despliegue locales.

## Resumen ejecutivo

Terminator II v3.1 se encuentra en un estado funcional para su objetivo **standalone**: orquestar inferencia y voz mediante backends locales o cloud configurables, con canales ya integrados. La revisión cerró los gaps que impedían declarar la integración Kokoro como completa dentro de este repositorio: autenticación Bearer, política local-first, endpoints de capabilities, compatibilidad de rutas de voces y perfiles Docker CPU/CUDA documentados.

La auditoría también detectó un desfase de Drizzle que hacía fallar `pnpm db:push`. La base de datos ya contenía la mayor parte de las columnas de las migraciones 0005–0007 sin registrar su journal y carecía de `geminiApiKey`. Se añadió dicha columna y se reconciliaron los hashes de migración. La validación posterior de `pnpm db:push` indicó que no existen cambios pendientes.

| Dimensión | Resultado | Evidencia |
|---|---|---|
| Pruebas | Aprobado | 116/116 pruebas Vitest en 24 archivos |
| Compilación | Aprobado con advertencia | `pnpm build` terminó correctamente; Vite avisa de un chunk >500 kB |
| TypeScript/LSP | Aprobado | Sin errores tras reiniciar el servidor |
| Migraciones | Aprobado | `pnpm db:push` sin cambios pendientes |
| Interfaz Realtime | Aprobado visualmente | `/terminator/realtime` carga y muestra sesión, backend, idioma y transcript |
| Docker runtime | Pendiente externo | No hay CLI Docker en el sandbox; perfiles cubiertos por prueba de artefacto |

## Hallazgos resueltos

| Prioridad previa | Hallazgo | Corrección aplicada | Estado |
|---|---|---|---|
| Crítica | Kokoro podía requerir Bearer, pero el proyecto no lo persistía ni enviaba | `kokoroApiKey` en schema, router, hook/UI y cabecera `Authorization` | Resuelto |
| Crítica | Modo local no bloqueaba URL remota ni metadata | Validación de host local en síntesis, health, voces y modelos | Resuelto |
| Importante | Se atribuían al proyecto endpoints externos no expuestos | Proxies `/api/terminator/kokoro/{health,voices,models}` | Resuelto |
| Importante | Gateways Kokoro divergen en la ruta de voces | Fallback `/v1/voices` → `/v1/audio/voices` tras `404` | Resuelto |
| Importante | No existía pantalla Realtime accesible | Página `/terminator/realtime`, ruta, audio PCM16 y acceso desde chat | Resuelto |
| Importante | Chat enviaba audio a una ruta que no coincidía con el endpoint Express | Cambio a `/api/terminator/upload-audio` | Resuelto |
| Crítica | Journal de Drizzle incompleto y `geminiApiKey` ausente en DB | Columna aplicada y journal reconciliado | Resuelto |

## Matriz de capacidades verificada

| Módulo | Implementación verificada | Límite operativo |
|---|---|---|
| Kokoro | SSE, volumen limitado, Bearer, metadata, policy local-only | Idiomas condicionados por el gateway/modelo instalado |
| Ruso y árabe | Ruso por Coqui/Silero; árabe por Coqui | Requieren gateway correspondiente; Kokoro no se selecciona para ruso/árabe |
| Realtime | Contrato común, tickets efímeros, OpenAI/Moshi/Gemini/ElevenLabs, UI PCM16 | Requiere clave o gateway real para una llamada de extremo a extremo |
| Traducción | Local/Alia/NLLB/Marian, Google, DeepL, custom | Endpoint y esquema del gateway local deben ser compatibles |
| Compose Kokoro | Perfil CPU y CUDA, healthcheck, `DOWNLOAD_MODEL=false` | Docker/GPU no disponibles para ejecución dentro del sandbox actual |
| Runtime tenIII | Registro aislado, ModelLoader, adaptadores, recursos, conectividad y fallback | La inferencia efectiva sigue requiriendo gateway HTTP o runtime local del operador |
| Vídeo local | Gateway configurable, endpoint/workflow persistidos y motores Wan2/LTX/Custom | El gateway se instala y protege fuera del proceso web |
| Vídeo con referencias | Grok y gateway local reciben imagen/vídeo previo; control de continuación en el chat web | La generación real requiere credenciales o runtime local del operador |

## Riesgos y prioridades posteriores

Los siguientes elementos no bloquean la entrega standalone, pero impiden llamar a Terminator II un runtime de inferencia completo para modelos entrenados por tenIII. Deben permanecer como trabajo V4 o como una rama de inferencia local especializada.

| Prioridad | Pendiente | Motivo |
|---|---|---|
| Alta | `MemoryManager` y cuantización operativa de pesos | La política de recursos ya existe; la carga física corresponde al runtime externo |
| Alta | Rama de memoria/RAG y Warfare.net | Requiere identidad, consentimiento, permisos y modelo de datos propio |
| Media | Edición avanzada de modelos y adaptadores | El catálogo permite alta, estado y borrado; faltan formularios de edición detallada y pruebas E2E reales |
| Media | Tests de integración con credenciales reales | Deben ejecutarse en entorno aislado aportado por el usuario, nunca con claves simuladas |
| Mejora | Code-splitting de cliente | El build avisa de un bundle minificado superior a 500 kB |

## Conclusión de release

La etiqueta recomendada para el ZIP es **Terminator II v3.1 + tenIII Runtime**. El paquete puede distribuirse para desarrollo y despliegue local, siempre que el operador configure sus claves y gateways. La documentación deja explícito qué funciona con CPU, qué exige NVIDIA CUDA y qué integraciones externas permanecen bajo control del usuario. El proyecto ofrece descriptores y resolución seguros para modelos tenIII; la ejecución de pesos continúa en un runtime que el operador controla.

## Referencias

[1] [Kokoro-FastAPI — imágenes CPU/GPU, endpoints y capacidades](https://github.com/remsky/Kokoro-FastAPI)  
[2] [Kokoro-FastAPI — configuración de Docker y `DOWNLOAD_MODEL`](https://github.com/remsky/Kokoro-FastAPI/blob/master/docs/configuration.md)
