ALTER TABLE `terminator_config` ADD `realtimeBackend` varchar(64) DEFAULT 'openai-realtime';--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `realtimeEndpoint` varchar(500);--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `realtimeModel` varchar(128);--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `realtimeFallbackJson` text;--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `realtimeAllowFallback` varchar(8) DEFAULT 'false';--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `translatorBackend` varchar(64) DEFAULT 'none';--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `translatorEndpoint` varchar(500);--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `translatorFallbackJson` text;--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `translatorAllowFallback` varchar(8) DEFAULT 'false';