ALTER TABLE `terminator_config` ADD `localVideoEndpoint` varchar(500);--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `localVideoWorkflow` varchar(160);