ALTER TABLE `terminator_config` ADD `defaultStt` varchar(64) DEFAULT 'auto';--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `defaultAvatar` varchar(64) DEFAULT 'none';