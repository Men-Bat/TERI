ALTER TABLE `terminator_config` ADD `geminiApiKey` text;--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `elevenlabsApiKey` text;--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `realtimeCustomApiKey` text;--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `googleTranslateApiKey` text;--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `deeplApiKey` text;