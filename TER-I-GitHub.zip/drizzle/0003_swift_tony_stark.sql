ALTER TABLE `terminator_config` ADD `kokoroUrl` varchar(255) DEFAULT 'http://localhost:8880';--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `piperUrl` varchar(255) DEFAULT 'http://localhost:5000';--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `twilioApiKeySid` text;--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `twilioApiKeySecret` text;--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `guestApiKeysJson` text;