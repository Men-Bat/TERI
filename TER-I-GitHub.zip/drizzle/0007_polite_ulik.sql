ALTER TABLE `terminator_config` ADD `kokoroApiKey` text;--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `kokoroLocalOnly` varchar(8) DEFAULT 'false';