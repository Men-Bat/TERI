CREATE TABLE `custom_models` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(160) NOT NULL,
	`kind` enum('llm','tts','stt','video','embedding') NOT NULL,
	`format` varchar(64) NOT NULL,
	`endpoint` varchar(500),
	`modelPath` varchar(1000),
	`languages` json,
	`capabilities` json,
	`resourceProfile` json,
	`config` json,
	`enabled` varchar(8) NOT NULL DEFAULT 'true',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `custom_models_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `model_adapters` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`modelId` int NOT NULL,
	`name` varchar(160) NOT NULL,
	`kind` enum('lora','qlora','steering','custom') NOT NULL,
	`format` varchar(64) NOT NULL,
	`pathOrUrl` varchar(1000) NOT NULL,
	`weight` float NOT NULL DEFAULT 1,
	`config` json,
	`enabled` varchar(8) NOT NULL DEFAULT 'true',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `model_adapters_id` PRIMARY KEY(`id`)
);
