CREATE TABLE `user_providers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(160) NOT NULL,
	`category` enum('llm','tts','stt','video','realtime','translation','channel','social','custom') NOT NULL,
	`providerKey` varchar(96) NOT NULL,
	`authType` enum('api_key','bearer','oauth','none') NOT NULL DEFAULT 'api_key',
	`endpoint` varchar(500),
	`secret` text,
	`resourceId` varchar(255),
	`metadata` json,
	`enabled` varchar(8) NOT NULL DEFAULT 'true',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_providers_id` PRIMARY KEY(`id`)
);
