import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, float } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Training sessions table to track model training
 */
export const trainingSessions = mysqlTable("training_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["pending", "running", "paused", "completed", "failed"]).default("pending").notNull(),
  dataFileUrl: text("dataFileUrl"),
  modelConfig: json("modelConfig"),
  currentEpoch: int("currentEpoch").default(0),
  totalEpochs: int("totalEpochs").default(10),
  currentLoss: float("currentLoss"),
  metrics: json("metrics"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type TrainingSession = typeof trainingSessions.$inferSelect;
export type InsertTrainingSession = typeof trainingSessions.$inferInsert;

/**
 * Uploaded files table
 */
export const uploadedFiles = mysqlTable("uploaded_files", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  filename: varchar("filename", { length: 255 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  fileKey: varchar("fileKey", { length: 500 }).notNull(),
  fileType: varchar("fileType", { length: 50 }),
  fileSize: int("fileSize"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UploadedFile = typeof uploadedFiles.$inferSelect;
export type InsertUploadedFile = typeof uploadedFiles.$inferInsert;

// ─── Terminator II Tables ────────────────────────────────────────────────────

/**
 * Conversations: one row per channel session (web, whatsapp, telegram, sms, voice, video)
 */
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  channelId: varchar("channelId", { length: 128 }).notNull(), // e.g. whatsapp:+34600..., sms:+34600..., call:CA..., web:sessionId
  channel: mysqlEnum("channel", ["web", "whatsapp", "telegram", "sms", "voice", "video"]).notNull(),
  personaId: varchar("personaId", { length: 64 }).default("default").notNull(), // default | ani | valentin
  llmBackend: varchar("llmBackend", { length: 64 }).default("auto").notNull(),
  ttsBackend: varchar("ttsBackend", { length: 64 }).default("auto").notNull(),
  videoBackend: varchar("videoBackend", { length: 64 }).default("none").notNull(),
  language: varchar("language", { length: 16 }).default("es").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

/**
 * Messages: each turn in a conversation
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  text: text("text"),
  audioUrl: text("audioUrl"),
  videoUrl: text("videoUrl"),
  imageUrl: text("imageUrl"),
  videoPrompt: text("videoPrompt"),
  audioPrompt: text("audioPrompt"),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Terminator config: API keys and backend settings per owner
 */
export const terminatorConfig = mysqlTable("terminator_config", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  // LLM backends
  ollamaUrl: varchar("ollamaUrl", { length: 255 }).default("http://localhost:11434"),
  lmstudioUrl: varchar("lmstudioUrl", { length: 255 }).default("http://localhost:1234"),
  xaiApiKey: text("xaiApiKey"),
  openaiApiKey: text("openaiApiKey"),
  moonshotApiKey: text("moonshotApiKey"),
  deepseekApiKey: text("deepseekApiKey"),
  // Optional Realtime and translation provider credentials
  geminiApiKey: text("geminiApiKey"),
  elevenlabsApiKey: text("elevenlabsApiKey"),
  realtimeCustomApiKey: text("realtimeCustomApiKey"),
  googleTranslateApiKey: text("googleTranslateApiKey"),
  deeplApiKey: text("deeplApiKey"),
  // TTS local
  kokoroUrl: varchar("kokoroUrl", { length: 255 }).default("http://localhost:8880"),
  kokoroApiKey: text("kokoroApiKey"),
  kokoroLocalOnly: varchar("kokoroLocalOnly", { length: 8 }).default("false"),
  coquiUrl: varchar("coquiUrl", { length: 255 }).default("http://localhost:5002"),
  sileroUrl: varchar("sileroUrl", { length: 255 }).default("http://localhost:5003"),
  piperUrl: varchar("piperUrl", { length: 255 }).default("http://localhost:5000"),
  // Channels
  twilioAccountSid: text("twilioAccountSid"),
  twilioAuthToken: text("twilioAuthToken"),
  twilioApiKeySid: text("twilioApiKeySid"),       // para AccessToken JWT (recomendado)
  twilioApiKeySecret: text("twilioApiKeySecret"), // para AccessToken JWT (recomendado)
  twilioPhoneNumber: varchar("twilioPhoneNumber", { length: 32 }),
  whatsappToken: text("whatsappToken"),
  whatsappPhoneNumberId: varchar("whatsappPhoneNumberId", { length: 64 }),
  whatsappVerifyToken: varchar("whatsappVerifyToken", { length: 128 }),
  whatsappAppSecret: text("whatsappAppSecret"),
  telegramBotToken: text("telegramBotToken"),
  telegramWebhookSecret: text("telegramWebhookSecret"),
  // Defaults
  defaultPersona: varchar("defaultPersona", { length: 64 }).default("default"),
  defaultLlm: varchar("defaultLlm", { length: 64 }).default("auto"),
  defaultTts: varchar("defaultTts", { length: 64 }).default("auto"),
  defaultStt: varchar("defaultStt", { length: 64 }).default("auto"),
  defaultVideo: varchar("defaultVideo", { length: 64 }).default("none"),
  defaultAvatar: varchar("defaultAvatar", { length: 64 }).default("none"),
  localVideoEndpoint: varchar("localVideoEndpoint", { length: 500 }),
  localVideoWorkflow: varchar("localVideoWorkflow", { length: 160 }),
  defaultLanguage: varchar("defaultLanguage", { length: 16 }).default("es"),
  // Realtime interchangeable backends (OpenAI, Moshi, Gemini, ElevenLabs, custom)
  realtimeBackend: varchar("realtimeBackend", { length: 64 }).default("openai-realtime"),
  realtimeEndpoint: varchar("realtimeEndpoint", { length: 500 }),
  realtimeModel: varchar("realtimeModel", { length: 128 }),
  realtimeFallbackJson: text("realtimeFallbackJson"),
  realtimeAllowFallback: varchar("realtimeAllowFallback", { length: 8 }).default("false"),
  // Optional live translation (local HTTP, Google, DeepL, custom)
  translatorBackend: varchar("translatorBackend", { length: 64 }).default("none"),
  translatorEndpoint: varchar("translatorEndpoint", { length: 500 }),
  translatorFallbackJson: text("translatorFallbackJson"),
  translatorAllowFallback: varchar("translatorAllowFallback", { length: 8 }).default("false"),
  // Guest API keys cache (JSON map: {xai, openai, moonshot, deepseek, ...})
  // Stored encrypted; allows unauthenticated users to save their own keys in the browser
  guestApiKeysJson: text("guestApiKeysJson"),
  // TTS URLs for Coqui/Silero (added in v3 for Arabic/Russian support)
  coquiUrlConfig: varchar("coquiUrlConfig", { length: 255 }),
  sileroUrlConfig: varchar("sileroUrlConfig", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TerminatorConfig = typeof terminatorConfig.$inferSelect;
export type InsertTerminatorConfig = typeof terminatorConfig.$inferInsert;

/**
 * Optional third-party providers registered by each owner. Secrets remain
 * server-side and are never returned by the public tRPC contract.
 */
export const userProviders = mysqlTable("user_providers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  category: mysqlEnum("category", ["llm", "tts", "stt", "video", "realtime", "translation", "channel", "social", "custom"]).notNull(),
  providerKey: varchar("providerKey", { length: 96 }).notNull(),
  authType: mysqlEnum("authType", ["api_key", "bearer", "oauth", "none"]).default("api_key").notNull(),
  endpoint: varchar("endpoint", { length: 500 }),
  secret: text("secret"),
  resourceId: varchar("resourceId", { length: 255 }),
  metadata: json("metadata"),
  enabled: varchar("enabled", { length: 8 }).default("true").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserProvider = typeof userProviders.$inferSelect;
export type InsertUserProvider = typeof userProviders.$inferInsert;

/**
 * Model registry for local or HTTP-backed inference runtimes. Paths are opaque
 * descriptors for a configured gateway and are never executed by the web app.
 */
export const customModels = mysqlTable("custom_models", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  kind: mysqlEnum("kind", ["llm", "tts", "stt", "video", "avatar", "embedding"]).notNull(),
  format: varchar("format", { length: 64 }).notNull(),
  endpoint: varchar("endpoint", { length: 500 }),
  modelPath: varchar("modelPath", { length: 1000 }),
  languages: json("languages"),
  capabilities: json("capabilities"),
  resourceProfile: json("resourceProfile"),
  config: json("config"),
  enabled: varchar("enabled", { length: 8 }).default("true").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CustomModel = typeof customModels.$inferSelect;
export type InsertCustomModel = typeof customModels.$inferInsert;

/**
 * Adapters reference LoRA/QLoRA artifacts which are composed by the selected
 * local runtime. Terminator II validates compatibility but does not load files.
 */
export const modelAdapters = mysqlTable("model_adapters", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  modelId: int("modelId").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  kind: mysqlEnum("kind", ["lora", "qlora", "steering", "custom"]).notNull(),
  format: varchar("format", { length: 64 }).notNull(),
  pathOrUrl: varchar("pathOrUrl", { length: 1000 }).notNull(),
  weight: float("weight").default(1).notNull(),
  config: json("config"),
  enabled: varchar("enabled", { length: 8 }).default("true").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ModelAdapter = typeof modelAdapters.$inferSelect;
export type InsertModelAdapter = typeof modelAdapters.$inferInsert;
