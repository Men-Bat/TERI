ALTER TABLE `terminator_config` ADD `whatsappAppSecret` text;--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `telegramWebhookSecret` text;