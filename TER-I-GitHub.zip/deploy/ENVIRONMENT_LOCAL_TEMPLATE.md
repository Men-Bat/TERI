# Plantilla de entorno local de Terminator II

Este documento enumera las variables que una instalación local puede configurar. **No contiene secretos reales**. Crea tus valores mediante el gestor seguro de secretos de tu despliegue o en el panel de configuración de Terminator II; no copies este documento con valores de producción a un repositorio.

| Variable | Valor local recomendado | Uso |
|---|---|---|
| `JWT_SECRET` | Cadena larga y aleatoria propia | Sesiones; también puede proteger credenciales si no se define una clave dedicada. |
| `PROVIDER_ENCRYPTION_KEY` | Cadena larga, estable y distinta de `JWT_SECRET` | Cifrado AES-256-GCM de credenciales guardadas. |
| `DATABASE_URL` | MySQL en `127.0.0.1` o LAN privada | Persistencia de configuración y modelos. |
| `OLLAMA_URL` | `http://127.0.0.1:11434` | LLM local. |
| `LMSTUDIO_URL` | `http://127.0.0.1:1234` | LLM local compatible con OpenAI. |
| `KOKORO_URL` | `http://127.0.0.1:8880` | Síntesis Kokoro local. |
| `COQUI_URL` | `http://127.0.0.1:5002` | Coqui XTTS local. |
| `SILERO_URL` | `http://127.0.0.1:5003` | Silero TTS local. |
| `PIPER_URL` | `http://127.0.0.1:5000` | Piper TTS local. |
| `LOCAL_VIDEO_ENDPOINT` | `http://127.0.0.1:8188` | Gateway local de Wan, LTX o ComfyUI. |
| `XAI_API_KEY`, `OPENAI_API_KEY`, `ELEVENLABS_API_KEY` | Vacío salvo uso explícito | Servicios cloud opcionales por usuario. |
| `TWILIO_*`, `WHATSAPP_*`, `TELEGRAM_BOT_TOKEN` | Vacío salvo activación de canal | Cuentas propias y webhooks opcionales. |

> Mantén todos los servicios locales en `127.0.0.1` o una VPN/LAN de confianza. La exposición HTTPS solo es necesaria para los webhooks que el usuario habilite.
