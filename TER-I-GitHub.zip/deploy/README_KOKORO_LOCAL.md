# Kokoro local para Terminator II

Este directorio proporciona perfiles separados para ejecutar **un único servicio Kokoro local**. El perfil `cpu` funciona sin GPU; el perfil `cuda` requiere una GPU NVIDIA, un controlador compatible y NVIDIA Container Toolkit. Ambos exponen el endpoint OpenAI-compatible en `http://localhost:8880`.

| Caso | Comando | Requisito |
|---|---|---|
| CPU local | `docker compose --env-file deploy/kokoro.env -f deploy/docker-compose.kokoro.yml --profile cpu up -d` | Docker Engine o Docker Desktop |
| NVIDIA CUDA | `docker compose --env-file deploy/kokoro.env -f deploy/docker-compose.kokoro.yml --profile cuda up -d` | Docker y NVIDIA Container Toolkit |
| Verificación | `curl http://localhost:8880/v1/models` | Servicio iniciado |

Primero copie `deploy/kokoro.env.example` a `deploy/kokoro.env`. Para un entorno estable, reemplace las etiquetas `latest` por una versión de imagen validada en sus propios tests. Tras iniciar el perfil, configure en Terminator II la URL `http://localhost:8880` y active **Modo Kokoro solo local** si no desea tráfico hacia un gateway remoto.

Los perfiles usan imágenes publicadas que incorporan modelos y definen `DOWNLOAD_MODEL=false`; por ello no intentan descargar pesos al iniciarse. Si se sustituye la imagen por un build propio o se monta un `MODEL_DIR` vacío, el administrador debe aprovisionar los pesos previamente: el modo local de Terminator II no puede convertir un contenedor sin pesos en un servicio de síntesis funcional.

> El paquete no incluye imágenes de Coqui XTTS, Silero ni Moshi porque sus servidores HTTP y contratos varían según el wrapper elegido. Terminator II los admite mediante sus URLs/gateways configurables, pero no debe aparentar que un contenedor no probado del repositorio está incluido. La matriz de despliegue documenta cómo conectarlos sin modificar este Compose.

El perfil CUDA emplea `gpus: all` y no debe usarse en el hosting gestionado de esta aplicación: se ejecuta en un equipo local o un servidor con Docker y GPU NVIDIA. El modo CPU es el fallback portable recomendado.
