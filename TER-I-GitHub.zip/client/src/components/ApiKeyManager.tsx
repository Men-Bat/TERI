/**
 * ApiKeyManager — Terminator II
 *
 * Componente reutilizable para gestionar claves API del usuario.
 * Las claves se guardan en:
 *   1. localStorage del navegador (inmediato, sin login)
 *   2. BD del servidor (persistente, requiere login)
 *
 * Nunca se muestran los valores completos una vez guardados.
 * El servidor devuelve solo indicadores de presencia (✓ / ✗).
 */

import { useState } from "react";
import { useApiKeys, type ApiKeyName } from "@/hooks/useApiKeys";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Eye,
  EyeOff,
  Save,
  Trash2,
  ChevronDown,
  CheckCircle2,
  XCircle,
  Cloud,
  HardDrive,
  AlertCircle,
  Loader2,
} from "lucide-react";

// ─── Definición de grupos de claves ──────────────────────────────────────────

interface KeyDef {
  key: ApiKeyName;
  label: string;
  placeholder: string;
  hint?: string;
  isUrl?: boolean;
}

interface KeyGroup {
  title: string;
  description: string;
  icon: string;
  keys: KeyDef[];
}

const KEY_GROUPS: KeyGroup[] = [
  {
    title: "LLM en la nube",
    description: "Modelos de lenguaje remotos como Grok, OpenAI, Kimi y DeepSeek",
    icon: "☁️",
    keys: [
      {
        key: "xaiApiKey",
        label: "xAI Grok API Key",
        placeholder: "xai-...",
        hint: "Obtener en console.x.ai — activa Grok LLM, TTS Aurora y generación de video",
      },
      {
        key: "openaiApiKey",
        label: "OpenAI API Key",
        placeholder: "sk-...",
        hint: "Obtener en platform.openai.com — activa GPT-4o, TTS y Whisper STT",
      },
      {
        key: "moonshotApiKey",
        label: "Kimi (Moonshot) API Key",
        placeholder: "sk-...",
        hint: "Obtener en platform.moonshot.cn — LLM chino multilingüe de alta calidad",
      },
      {
        key: "deepseekApiKey",
        label: "DeepSeek API Key",
        placeholder: "sk-...",
        hint: "Obtener en platform.deepseek.com — LLM de razonamiento avanzado",
      },
    ],
  },
  {
    title: "Realtime y voz cloud",
    description: "Conversación de voz intercambiable: Gemini Live y ElevenLabs Agents",
    icon: "🔊",
    keys: [
      {
        key: "geminiApiKey",
        label: "Gemini Live API Key",
        placeholder: "AIza...",
        hint: "Clave de Google AI Studio o Google Cloud. Se usa solo desde el servidor.",
      },
      {
        key: "elevenlabsApiKey",
        label: "ElevenLabs API Key",
        placeholder: "xi-...",
        hint: "Clave para ElevenAgents; nunca se expone al navegador.",
      },
      {
        key: "realtimeCustomApiKey",
        label: "API Key Realtime personalizada",
        placeholder: "Token opcional",
        hint: "Para un gateway WebSocket/HTTP compatible configurado por el usuario.",
      },
    ],
  },
  {
    title: "LLM local",
    description: "Backends locales: Ollama y LM Studio (sin coste, sin internet)",
    icon: "🖥️",
    keys: [
      {
        key: "ollamaUrl",
        label: "URL de Ollama",
        placeholder: "http://localhost:11434",
        hint: "URL del servidor Ollama local. Por defecto: http://localhost:11434",
        isUrl: true,
      },
      {
        key: "lmstudioUrl",
        label: "URL de LM Studio",
        placeholder: "http://localhost:1234",
        hint: "URL del servidor LM Studio local. Por defecto: http://localhost:1234",
        isUrl: true,
      },
    ],
  },
  {
    title: "TTS / STT local",
    description: "Síntesis y reconocimiento de voz sin internet",
    icon: "🎙️",
    keys: [
      {
        key: "kokoroUrl",
        label: "URL de Kokoro TTS",
        placeholder: "http://localhost:8880",
        hint: "Docker: docker run -p 8880:8880 ghcr.io/remsky/kokoro-fastapi-cpu:v0.2.2",
        isUrl: true,
      },
      {
        key: "kokoroApiKey",
        label: "Bearer token de Kokoro (opcional)",
        placeholder: "Token del gateway Kokoro",
        hint: "Se envía como Authorization: Bearer ... cuando el gateway exige autenticación.",
      },
      {
        key: "piperUrl",
        label: "URL de Piper TTS",
        placeholder: "http://localhost:5000",
        hint: "Servidor REST de Piper TTS local (30+ idiomas, solo CPU)",
        isUrl: true,
      },
    ],
  },
  {
    title: "Traducción en tiempo real",
    description: "Google, DeepL o un endpoint local/custom como Alia, NLLB o Marian",
    icon: "文",
    keys: [
      {
        key: "googleTranslateApiKey",
        label: "Google Translate API Key",
        placeholder: "AIza...",
        hint: "Opcional; se usa únicamente si se selecciona Google Translate.",
      },
      {
        key: "deeplApiKey",
        label: "DeepL API Key",
        placeholder: "Token de DeepL",
        hint: "Opcional; admite endpoint free o pro según DEEPL_API_URL.",
      },
    ],
  },
  {
    title: "Twilio (SMS, voz, videollamada)",
    description: "Canal de llamadas, SMS/MMS y videollamadas WebRTC",
    icon: "📞",
    keys: [
      {
        key: "twilioAccountSid",
        label: "Account SID",
        placeholder: "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
        hint: "Obtener en console.twilio.com",
      },
      {
        key: "twilioAuthToken",
        label: "Auth Token",
        placeholder: "••••••••••••••••••••••••••••••••",
        hint: "Auth Token de tu cuenta Twilio (para webhooks)",
      },
      {
        key: "twilioApiKeySid",
        label: "API Key SID (recomendado para video)",
        placeholder: "SKxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
        hint: "Crear en console.twilio.com > API Keys — más seguro que usar Auth Token",
      },
      {
        key: "twilioApiKeySecret",
        label: "API Key Secret",
        placeholder: "••••••••••••••••••••••••••••••••",
        hint: "Secret de la API Key de Twilio (solo se muestra al crear)",
      },
      {
        key: "twilioPhoneNumber",
        label: "Número de teléfono Twilio",
        placeholder: "+34900000000",
        hint: "Número en formato E.164 para SMS y llamadas",
      },
    ],
  },
  {
    title: "WhatsApp Business",
    description: "Canal de WhatsApp mediante Meta Cloud API",
    icon: "💬",
    keys: [
      {
        key: "whatsappToken",
        label: "Token de acceso permanente",
        placeholder: "EAAxxxxxxx...",
        hint: "Token de la app de Meta en developers.facebook.com",
      },
      {
        key: "whatsappPhoneNumberId",
        label: "Phone Number ID",
        placeholder: "1234567890123456",
        hint: "ID numérico del número de WhatsApp Business (no el número en sí)",
      },
      {
        key: "whatsappVerifyToken",
        label: "Verify Token del webhook",
        placeholder: "mi-token-secreto",
        hint: "Cadena arbitraria que defines tú y configuras también en Meta Developers",
      },
      {
        key: "whatsappAppSecret",
        label: "App Secret para firma de Meta",
        placeholder: "Secreto de la app de Meta",
        hint: "Obligatorio en producción: valida X-Hub-Signature-256 de las entradas de WhatsApp.",
      },
    ],
  },
  {
    title: "Telegram",
    description: "Canal de Telegram Bot",
    icon: "✈️",
    keys: [
      {
        key: "telegramBotToken",
        label: "Bot Token",
        placeholder: "123456789:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
        hint: "Obtener hablando con @BotFather en Telegram",
      },
      {
        key: "telegramWebhookSecret",
        label: "Secret Token del webhook",
        placeholder: "token-secreto-de-webhook",
        hint: "Obligatorio en producción: debe coincidir con X-Telegram-Bot-Api-Secret-Token enviado por Telegram.",
      },
    ],
  },
];

// ─── Componente de un campo de clave ─────────────────────────────────────────

interface KeyFieldProps {
  def: KeyDef;
  value: string;
  isPresent: boolean;
  onChange: (val: string) => void;
}

function KeyField({ def, value, isPresent, onChange }: KeyFieldProps) {
  const [visible, setVisible] = useState(false);

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-slate-300">{def.label}</label>
        <div className="flex items-center gap-1.5">
          {isPresent ? (
            <span className="flex items-center gap-1 text-xs text-green-400">
              <CheckCircle2 className="w-3 h-3" />
              Guardada en servidor
            </span>
          ) : (
            <span className="flex items-center gap-1 text-xs text-slate-500">
              <XCircle className="w-3 h-3" />
              No configurada
            </span>
          )}
        </div>
      </div>
      <div className="relative">
        <Input
          type={visible || def.isUrl ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={def.placeholder}
          className="bg-slate-900 border-slate-700 text-slate-200 placeholder:text-slate-600 pr-10 font-mono text-sm"
          autoComplete="off"
          spellCheck={false}
        />
        {!def.isUrl && (
          <button
            type="button"
            onClick={() => setVisible((v) => !v)}
            className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
          >
            {visible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        )}
      </div>
      {def.hint && (
        <p className="text-xs text-slate-500">{def.hint}</p>
      )}
    </div>
  );
}

// ─── Componente principal ─────────────────────────────────────────────────────

interface ApiKeyManagerProps {
  /** Si true, muestra solo los grupos especificados */
  groups?: string[];
  /** Callback cuando se guardan las claves */
  onSaved?: () => void;
  className?: string;
}

export function ApiKeyManager({ groups, onSaved, className = "" }: ApiKeyManagerProps) {
  const { keys, presence, setKeys, saveToServer, clearAll, isDirty, isSaving, error } =
    useApiKeys();
  const [openGroups, setOpenGroups] = useState<Set<string>>(new Set());

  const visibleGroups = groups
    ? KEY_GROUPS.filter((g) => groups.includes(g.title))
    : KEY_GROUPS;

  const toggleGroup = (title: string) => {
    setOpenGroups((prev) => {
      const next = new Set(prev);
      if (next.has(title)) next.delete(title);
      else next.add(title);
      return next;
    });
  };

  const handleSave = async () => {
    await saveToServer();
    onSaved?.();
  };

  return (
    <div className={`space-y-3 ${className}`}>
      {/* Storage info banner */}
      <div className="flex items-start gap-3 bg-slate-800/60 border border-slate-700 rounded-lg p-3 text-xs text-slate-400">
        <AlertCircle className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="flex items-center gap-1.5">
            <HardDrive className="w-3 h-3" />
            <strong className="text-slate-300">Local (navegador):</strong> Las claves se guardan en localStorage de este navegador automáticamente al escribirlas.
          </p>
          <p className="flex items-center gap-1.5">
            <Cloud className="w-3 h-3" />
            <strong className="text-slate-300">Servidor (cuenta):</strong> Pulsa "Guardar en servidor" para sincronizar con tu cuenta y acceder desde cualquier dispositivo.
          </p>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-900/30 border border-red-700 rounded-lg p-3 text-sm text-red-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {/* Key groups */}
      {visibleGroups.map((group) => {
        const isOpen = openGroups.has(group.title);
        const configuredCount = group.keys.filter(
          (k) => presence?.[k.key] || keys[k.key]
        ).length;

        return (
          <Collapsible
            key={group.title}
            open={isOpen}
            onOpenChange={() => toggleGroup(group.title)}
          >
            <Card className="bg-slate-900/60 border-slate-700">
              <CollapsibleTrigger asChild>
                <CardHeader className="cursor-pointer hover:bg-slate-800/40 transition-colors rounded-t-lg py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-xl">{group.icon}</span>
                      <div>
                        <CardTitle className="text-sm text-slate-200">{group.title}</CardTitle>
                        <CardDescription className="text-xs text-slate-500 mt-0.5">
                          {group.description}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {configuredCount > 0 && (
                        <Badge className="bg-green-900/50 text-green-400 border-green-700 text-xs">
                          {configuredCount}/{group.keys.length}
                        </Badge>
                      )}
                      <ChevronDown
                        className={`w-4 h-4 text-slate-500 transition-transform ${isOpen ? "rotate-180" : ""}`}
                      />
                    </div>
                  </div>
                </CardHeader>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <CardContent className="pt-0 pb-4 space-y-4">
                  {group.keys.map((def) => (
                    <KeyField
                      key={def.key}
                      def={def}
                      value={(keys[def.key] as string) ?? ""}
                      isPresent={presence?.[def.key] ?? false}
                      onChange={(val) => setKeys({ [def.key]: val })}
                    />
                  ))}
                  {group.title === "TTS / STT local" && (
                    <label className="flex items-start gap-3 rounded-lg border border-slate-700 bg-slate-950/50 p-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={keys.kokoroLocalOnly ?? false}
                        onChange={(event) => setKeys({ kokoroLocalOnly: event.target.checked })}
                        className="mt-1 h-4 w-4 accent-orange-600"
                      />
                      <span>
                        <span className="block text-sm font-medium text-slate-300">Modo Kokoro solo local</span>
                        <span className="block text-xs text-slate-500 mt-1">Bloquea la síntesis y metadata cuando la URL no es localhost o un dominio .local. Úsalo para impedir tráfico externo.</span>
                      </span>
                    </label>
                  )}
                </CardContent>
              </CollapsibleContent>
            </Card>
          </Collapsible>
        );
      })}

      {/* Action buttons */}
      <div className="flex items-center gap-3 pt-2">
        <Button
          onClick={handleSave}
          disabled={isSaving || !isDirty}
          className="bg-orange-600 hover:bg-orange-700 disabled:opacity-50 flex-1"
        >
          {isSaving ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Guardando...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              {isDirty ? "Guardar en servidor" : "Guardado ✓"}
            </>
          )}
        </Button>
        <Button
          onClick={clearAll}
          variant="outline"
          className="border-red-800 text-red-400 hover:bg-red-900/20"
          title="Borrar todas las claves del navegador y del servidor"
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      <p className="text-xs text-slate-600 text-center">
        Las claves se almacenan en localStorage de este navegador y opcionalmente en tu cuenta del servidor.
        Nunca se envían a terceros ni se muestran en texto plano una vez guardadas.
      </p>
    </div>
  );
}

export default ApiKeyManager;
