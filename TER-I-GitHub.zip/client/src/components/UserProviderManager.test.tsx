// @vitest-environment jsdom
import React from "react";
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  refetch: vi.fn(),
  create: vi.fn(async () => ({ id: 31 })),
  remove: vi.fn(),
  update: vi.fn(),
  testProvider: vi.fn(async () => ({ reachable: true, status: 204, latencyMs: 12 })),
  providers: [] as Array<Record<string, unknown>>,
}));

vi.mock("@/lib/trpc", () => ({
  trpc: { terminator: {
    listUserProviders: { useQuery: () => ({ data: mocks.providers, refetch: mocks.refetch }) },
    registerUserProvider: { useMutation: () => ({ mutateAsync: mocks.create, isPending: false }) },
    deleteUserProvider: { useMutation: () => ({ mutate: mocks.remove }) },
    updateUserProvider: { useMutation: () => ({ mutate: mocks.update }) },
    testUserProvider: { useMutation: () => ({ mutateAsync: mocks.testProvider, isPending: false }) },
  } },
}));

import { UserProviderManager } from "./UserProviderManager";

describe("UserProviderManager", () => {
  beforeEach(() => { vi.clearAllMocks(); mocks.providers = []; });
  afterEach(() => cleanup());

  it("registra una API opcional propia con endpoint y recurso sin exponer el secreto", async () => {
    const user = userEvent.setup();
    render(<UserProviderManager />);
    await user.type(screen.getByPlaceholderText(/Nombre visible/), "ElevenLabs de Ana");
    await user.type(screen.getByPlaceholderText(/Clave\/identificador/), "elevenlabs");
    await user.type(screen.getByPlaceholderText(/Endpoint opcional/), "http://localhost:9000");
    await user.type(screen.getByPlaceholderText(/Recurso opcional/), "voice_personalizada");
    await user.type(screen.getByPlaceholderText(/API key, token/), "secret-private");
    await user.click(screen.getByRole("button", { name: "Añadir proveedor opcional" }));
    await waitFor(() => expect(mocks.create).toHaveBeenCalledWith(expect.objectContaining({ name: "ElevenLabs de Ana", providerKey: "elevenlabs", endpoint: "http://localhost:9000", resourceId: "voice_personalizada", secret: "secret-private" })));
    expect(screen.getByRole("status").textContent).toContain("La credencial no se volverá a mostrar");
  });

  it("carga plantillas para Meta, Telegram, X, Twilio y cuentas personalizadas", async () => {
    const user = userEvent.setup();
    render(<UserProviderManager />);
    const preset = screen.getByLabelText("Plantilla de cuenta propia");
    await user.selectOptions(preset, "meta-whatsapp");
    expect((screen.getByPlaceholderText(/Nombre visible/) as HTMLInputElement).value).toBe("Meta / WhatsApp Business");
    expect((screen.getByPlaceholderText(/Clave\/identificador/) as HTMLInputElement).value).toBe("meta-whatsapp");
    expect((screen.getByPlaceholderText(/Recurso opcional/) as HTMLInputElement).value).toBe("PHONE_NUMBER_ID");
    await user.selectOptions(preset, "telegram");
    expect((screen.getByPlaceholderText(/Clave\/identificador/) as HTMLInputElement).value).toBe("telegram");
    await user.selectOptions(preset, "x");
    expect((screen.getByPlaceholderText(/Clave\/identificador/) as HTMLInputElement).value).toBe("x");
    await user.selectOptions(preset, "twilio");
    expect((screen.getByPlaceholderText(/Clave\/identificador/) as HTMLInputElement).value).toBe("twilio");
  });

  it("permite comprobar la conexión sin presentar ni transmitir la credencial en la interfaz", async () => {
    const user = userEvent.setup();
    mocks.providers = [{ id: 41, name: "Gateway local", category: "custom", providerKey: "local", endpoint: "http://127.0.0.1:8100/health", hasSecret: true, enabled: "true" }];
    render(<UserProviderManager />);
    await user.click(screen.getByRole("button", { name: "Probar conexión" }));
    await waitFor(() => expect(mocks.testProvider).toHaveBeenCalledWith({ providerId: 41 }));
    expect(screen.getByRole("status").textContent).toContain("No se envió su credencial");
  });
});
