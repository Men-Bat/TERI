import React, { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";

type ModelKind = "llm" | "tts" | "stt" | "video" | "avatar" | "embedding";

function ConnectivityBadge({ modelId, endpoint }: { modelId: number; endpoint: string | null }) {
  const result = trpc.terminator.checkModelConnectivity.useQuery({ modelId }, { enabled: Boolean(endpoint), retry: false, staleTime: 30_000 });
  if (!endpoint) return <span className="text-xs text-slate-500">Runtime local</span>;
  if (result.isLoading) return <span className="text-xs text-slate-500">Verificando…</span>;
  return <span className={`text-xs ${result.data?.reachable ? "text-emerald-400" : "text-red-400"}`}>{result.data?.reachable ? `Conectado (${result.data.latencyMs} ms)` : "No disponible"}</span>;
}

function isHttpReference(value: string) {
  return /^https?:\/\//i.test(value.trim());
}

export function CustomModelManager() {
  const models = trpc.terminator.listModels.useQuery(undefined, { retry: false });
  const register = trpc.terminator.registerModel.useMutation({ onSuccess: () => models.refetch() });
  const update = trpc.terminator.updateModel.useMutation({ onSuccess: () => models.refetch() });
  const remove = trpc.terminator.deleteModel.useMutation({ onSuccess: () => models.refetch() });
  const [name, setName] = useState("");
  const [kind, setKind] = useState<ModelKind>("llm");
  const [format, setFormat] = useState("gguf");
  const [target, setTarget] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editName, setEditName] = useState("");
  const [editFormat, setEditFormat] = useState("");
  const [editTarget, setEditTarget] = useState("");
  const [editError, setEditError] = useState("");
  const [savedModelId, setSavedModelId] = useState<number | null>(null);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    const reference = target.trim();
    if (!name.trim() || !reference) return;
    await register.mutateAsync({ name: name.trim(), kind, format: format.trim() || "custom", ...(isHttpReference(reference) ? { endpoint: reference } : { modelPath: reference }) });
    setName("");
    setTarget("");
  };

  const beginEdit = (model: NonNullable<typeof models.data>[number]) => {
    setEditingId(model.id);
    setEditName(model.name);
    setEditFormat(model.format);
    setEditTarget(model.endpoint ?? model.modelPath ?? "");
    setEditError("");
    setSavedModelId(null);
  };

  const saveEdit = async (modelId: number) => {
    const reference = editTarget.trim();
    if (!editName.trim() || !editFormat.trim()) {
      setEditError("El nombre y el formato son obligatorios.");
      return;
    }
    try {
      await update.mutateAsync({ modelId, name: editName.trim(), format: editFormat.trim(), ...(reference ? (isHttpReference(reference) ? { endpoint: reference, modelPath: undefined } : { modelPath: reference, endpoint: undefined }) : {}) });
      setEditingId(null);
      setSavedModelId(modelId);
      setEditError("");
    } catch {
      setEditError("No se pudo guardar la edición. Reintenta la operación.");
    }
  };

  return <div className="space-y-4">
    <p className="text-sm text-slate-400">Registra referencias para un gateway local. Las rutas no se ejecutan desde el navegador; una URL HTTP se comprueba desde el servidor.</p>
    <form onSubmit={submit} className="grid gap-2 sm:grid-cols-2">
      <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Nombre" className="rounded border border-slate-700 bg-slate-950 px-3 py-2" />
      <select value={kind} onChange={(event) => setKind(event.target.value as ModelKind)} className="rounded border border-slate-700 bg-slate-950 px-3 py-2"><option value="llm">LLM</option><option value="tts">TTS</option><option value="stt">STT</option><option value="video">Vídeo</option><option value="avatar">Avatar</option><option value="embedding">Embedding</option></select>
      <input value={format} onChange={(event) => setFormat(event.target.value)} placeholder="Formato" className="rounded border border-slate-700 bg-slate-950 px-3 py-2" />
      <input value={target} onChange={(event) => setTarget(event.target.value)} placeholder="Ruta de runtime o URL HTTP" className="rounded border border-slate-700 bg-slate-950 px-3 py-2" />
      <Button type="submit" disabled={register.isPending} className="sm:col-span-2">Registrar modelo</Button>
    </form>
    <div className="space-y-2">
      {models.data?.map((model) => <div key={model.id} className="rounded border border-slate-800 bg-slate-950/60 p-3 text-sm">
        {editingId === model.id ? <div className="space-y-2"><div className="grid gap-2 sm:grid-cols-[1fr_1fr_1fr_auto_auto]">
          <input value={editName} onChange={(event) => setEditName(event.target.value)} aria-label={`Nombre de ${model.name}`} className="rounded border border-slate-700 bg-slate-950 px-2 py-1" />
          <input value={editFormat} onChange={(event) => setEditFormat(event.target.value)} aria-label={`Formato de ${model.name}`} className="rounded border border-slate-700 bg-slate-950 px-2 py-1" />
          <input value={editTarget} onChange={(event) => setEditTarget(event.target.value)} aria-label={`Runtime de ${model.name}`} className="rounded border border-slate-700 bg-slate-950 px-2 py-1" />
          <Button size="sm" onClick={() => saveEdit(model.id)} disabled={update.isPending}>Guardar</Button>
          <Button size="sm" variant="outline" onClick={() => { setEditingId(null); setEditError(""); }}>Cancelar</Button>
        </div>{editError && <p className="text-xs text-red-400" role="alert">{editError}</p>}</div> : <div className="flex items-center gap-3">
          <div className="min-w-0 flex-1"><strong>{model.name}</strong><span className="ml-2 text-slate-400">{model.kind} · {model.format}</span><ConnectivityBadge modelId={model.id} endpoint={model.endpoint} /></div>
          <Button size="sm" variant="outline" onClick={() => beginEdit(model)}>Editar</Button>
          <Button size="sm" variant="outline" onClick={() => update.mutate({ modelId: model.id, enabled: model.enabled === "true" ? "false" : "true" })}>{model.enabled === "true" ? "Desactivar" : "Activar"}</Button>
          <Button size="sm" variant="destructive" onClick={() => remove.mutate({ modelId: model.id })}>Eliminar</Button>
        </div>}{savedModelId === model.id && <p className="mt-2 text-xs text-emerald-400" role="status">Modelo actualizado.</p>}
      </div>)}
      {!models.data?.length && <p className="text-sm text-slate-500">No hay modelos registrados.</p>}
    </div>
  </div>;
}
