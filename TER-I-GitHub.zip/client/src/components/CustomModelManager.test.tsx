// @vitest-environment jsdom
import React from "react";
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  refetch: vi.fn(),
  updateMutate: vi.fn(),
  updateMutateAsync: vi.fn(async () => ({ success: true })),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    terminator: {
      listModels: { useQuery: () => ({ data: [{ id: 7, name: "Modelo local", kind: "llm", format: "gguf", endpoint: null, modelPath: "/models/a.gguf", enabled: "true" }], refetch: mocks.refetch }) },
      registerModel: { useMutation: () => ({ mutateAsync: vi.fn(), isPending: false }) },
      updateModel: { useMutation: () => ({ mutate: mocks.updateMutate, mutateAsync: mocks.updateMutateAsync, isPending: false }) },
      deleteModel: { useMutation: () => ({ mutate: vi.fn() }) },
      checkModelConnectivity: { useQuery: () => ({ isLoading: false, data: null }) },
    },
  },
}));

import { CustomModelManager } from "./CustomModelManager";

describe("CustomModelManager", () => {
  beforeEach(() => vi.clearAllMocks());
  afterEach(() => cleanup());

  it("edita nombre, formato y runtime; guarda y muestra confirmación", async () => {
    const user = userEvent.setup();
    render(<CustomModelManager />);
    await user.click(screen.getByRole("button", { name: "Editar" }));
    await user.clear(screen.getByLabelText("Nombre de Modelo local"));
    await user.type(screen.getByLabelText("Nombre de Modelo local"), "Modelo ajustado");
    await user.clear(screen.getByLabelText("Formato de Modelo local"));
    await user.type(screen.getByLabelText("Formato de Modelo local"), "safetensors");
    await user.clear(screen.getByLabelText("Runtime de Modelo local"));
    await user.type(screen.getByLabelText("Runtime de Modelo local"), "http://127.0.0.1:8000");
    await user.click(screen.getByRole("button", { name: "Guardar" }));

    await waitFor(() => expect(mocks.updateMutateAsync).toHaveBeenCalledWith({ modelId: 7, name: "Modelo ajustado", format: "safetensors", endpoint: "http://127.0.0.1:8000", modelPath: undefined }));
    expect(screen.getByRole("status").textContent).toContain("Modelo actualizado.");
  });

  it("cancela la edición y muestra un error de validación sin guardar", async () => {
    const user = userEvent.setup();
    render(<CustomModelManager />);
    await user.click(screen.getByRole("button", { name: "Editar" }));
    await user.click(screen.getByRole("button", { name: "Cancelar" }));
    expect(screen.queryByRole("button", { name: "Guardar" })).toBeNull();

    await user.click(screen.getByRole("button", { name: "Editar" }));
    await user.clear(screen.getByLabelText("Nombre de Modelo local"));
    await user.click(screen.getByRole("button", { name: "Guardar" }));
    expect(screen.getByRole("alert").textContent).toContain("El nombre y el formato son obligatorios.");
    expect(mocks.updateMutateAsync).not.toHaveBeenCalled();
  });
});
