import { useI18n, LANGUAGES } from "@/lib/i18n";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Globe } from "lucide-react";

export function LanguageSelector() {
  const { lang, setLang, t, langInfo } = useI18n();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="text-slate-400 hover:text-white hover:bg-slate-800 gap-1.5 px-2"
          title={t("lang.select")}
        >
          <Globe className="w-4 h-4" />
          <span className="text-base leading-none">{langInfo.flag}</span>
          <span className="hidden sm:inline text-xs font-medium uppercase tracking-wide">
            {lang}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        className="w-52 max-h-80 overflow-y-auto bg-slate-900 border-slate-700"
      >
        {LANGUAGES.map((language) => (
          <DropdownMenuItem
            key={language.code}
            onClick={() => setLang(language.code)}
            className={`flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white hover:bg-slate-800 ${
              lang === language.code ? "bg-slate-800 text-white font-medium" : ""
            }`}
          >
            <span className="text-base">{language.flag}</span>
            <span className="flex-1 text-sm">{language.nativeName}</span>
            {lang === language.code && (
              <span className="text-blue-400 text-xs">✓</span>
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
