import React, { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";

const CATEGORIES = ["llm", "tts", "stt", "video", "realtime", "translation", "channel", "social", "custom"] as const;
const AUTH_TYPES = ["api_key", "bearer", "oauth", "none"] as const;

const PROVIDER_PRESETS = [
  { id: "meta-whatsapp", label: "Meta / WhatsApp Business", category: "channel", providerKey: "meta-whatsapp", authType: "bearer", endpoint: "https://graph.facebook.com/v20.0", resourceHint: "PHONE_NUMBER_ID" },
  { id: "telegram", label: "Telegram Bot", category: "channel", providerKey: "telegram", authType: "bearer", endpoint: "https://api.telegram.org", resourceHint: "BOT_ID" },
  { id: "x", label: "X API / gateway compatible", category: "social", providerKey: "x", authType: "oauth", endpoint: "", resourceHint: "ACCOUNT_OR_APP_ID" },
  { id: "twilio", label: "Twilio SMS / Voice / Video", category: "channel", providerKey: "twilio", authType: "api_key", endpoint: "https://api.twilio.com", resourceHint: "PHONE_OR_SERVICE_ID" },
  { id: "custom", label: "Gateway privado / otra cuenta", category: "custom", providerKey: "custom", authType: "api_key", endpoint: "", resourceHint: "RESOURCE_ID" },
] as const;

export function UserProviderManager() {
  const providers = trpc.terminator.listUserProviders.useQuery(undefined, { retry: false });
  const create = trpc.terminator.registerUserProvider.useMutation({ onSuccess: () => providers.refetch() });
  const remove = trpc.terminator.deleteUserProvider.useMutation({ onSuccess: () => providers.refetch() });
  const update = trpc.terminator.updateUserProvider.useMutation({ onSuccess: () => providers.refetch() });
  const testProvider = trpc.terminator.testUserProvider.useMutation();
  const [name, setName] = useState("");
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>("custom");
  const [providerKey, setProviderKey] = useState("");
  const [authType, setAuthType] = useState<(typeof AUTH_TYPES)[number]>("api_key");
  const [endpoint, setEndpoint] = useState("");
  const [secret, setSecret] = useState("");
  const [resourceId, setResourceId] = useState("");
  const [message, setMessage] = useState("");

  const applyPreset = (presetId: string) => {
    const preset = PROVIDER_PRESETS.find((candidate) => candidate.id === presetId);
    if (!preset) return;
    setName(preset.label);
    setCategory(preset.category);
    setProviderKey(preset.providerKey);
    setAuthType(preset.authType);
    setEndpoint(preset.endpoint);
    setResourceId(preset.resourceHint);
    setMessage(`Plantilla ${preset.label} cargada. Sustituye el recurso y añade tu credencial antes de guardar.`);
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!name.trim() || !providerKey.trim()) { setMessage("Indica un nombre y una clave de proveedor."); return; }
    try {
      await create.mutateAsync({ name: name.trim(), category, providerKey: providerKey.trim(), authType, endpoint: endpoint.trim() || undefined, secret: secret || undefined, resourceId: resourceId.trim() || undefined });
      setName(""); setProviderKey(""); setEndpoint(""); setSecret(""); setResourceId("");
      setMessage("Proveedor registrado. La credencial no se volverá a mostrar.");
    } catch { setMessage("No se pudo registrar el proveedor."); }
  };

  const testConnectivity = async (providerId: number) => {
    try {
      const result = await testProvider.mutateAsync({ providerId });
      setMessage(result.reachable ? `Proveedor disponible${result.status ? ` (HTTP ${result.status})` : ""}. No se envió su credencial.` : `Proveedor no disponible: ${result.error ?? "sin respuesta"}`);
    } catch {
      setMessage("No se pudo comprobar el proveedor.");
    }
  };

  return <div className="space-y-4">
    <div className="rounded-lg border border-cyan-900/60 bg-cyan-950/20 p-3 text-xs text-slate-300">
      Este catálogo es opcional. Añade solo cuentas propias que quieras usar, por ejemplo X, Meta, Telegram, Twilio, ElevenLabs o un gateway privado. El secreto se guarda por usuario y nunca vuelve al navegador después de enviarlo.
    </div>
    <div className="rounded-lg border border-slate-800 bg-slate-950/50 p-3">
      <label className="mb-1 block text-xs font-medium text-slate-300" htmlFor="provider-preset">Plantilla de cuenta propia</label>
      <select id="provider-preset" defaultValue="" onChange={(event) => applyPreset(event.target.value)} className="w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-sm">
        <option value="">Selecciona Meta, Telegram, X, Twilio u otra cuenta</option>
        {PROVIDER_PRESETS.map((preset) => <option key={preset.id} value={preset.id}>{preset.label}</option>)}
      </select>
      <p className="mt-2 text-xs text-slate-500">Las plantillas solo rellenan metadatos; no contienen credenciales compartidas ni hacen llamadas automáticas.</p>
    </div>
    <form onSubmit={submit} className="grid gap-2 sm:grid-cols-2">
      <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Nombre visible (p. ej., ElevenLabs personal)" className="rounded border border-slate-700 bg-slate-950 px-3 py-2" />
      <input value={providerKey} onChange={(event) => setProviderKey(event.target.value)} placeholder="Clave/identificador (p. ej., elevenlabs)" className="rounded border border-slate-700 bg-slate-950 px-3 py-2" />
      <select value={category} onChange={(event) => setCategory(event.target.value as typeof category)} className="rounded border border-slate-700 bg-slate-950 px-3 py-2">{CATEGORIES.map((value) => <option key={value} value={value}>{value.toUpperCase()}</option>)}</select>
      <select value={authType} onChange={(event) => setAuthType(event.target.value as typeof authType)} className="rounded border border-slate-700 bg-slate-950 px-3 py-2">{AUTH_TYPES.map((value) => <option key={value} value={value}>{value}</option>)}</select>
      <input value={endpoint} onChange={(event) => setEndpoint(event.target.value)} placeholder="Endpoint opcional (localhost por defecto)" className="rounded border border-slate-700 bg-slate-950 px-3 py-2" />
      <input value={resourceId} onChange={(event) => setResourceId(event.target.value)} placeholder="Recurso opcional: voz, número, bot o modelo" className="rounded border border-slate-700 bg-slate-950 px-3 py-2" />
      <input type="password" value={secret} onChange={(event) => setSecret(event.target.value)} placeholder="API key, token o secreto opcional" autoComplete="off" className="rounded border border-slate-700 bg-slate-950 px-3 py-2 sm:col-span-2" />
      <Button type="submit" disabled={create.isPending} className="sm:col-span-2">Añadir proveedor opcional</Button>
    </form>
    {message && <p role="status" className="text-xs text-slate-300">{message}</p>}
    <div className="space-y-2">
      {providers.data?.map((provider) => <div key={provider.id} className="flex flex-wrap items-center gap-2 rounded border border-slate-800 bg-slate-950/60 p-3 text-sm">
        <div className="min-w-0 flex-1"><strong>{provider.name}</strong><span className="ml-2 text-slate-400">{provider.category} · {provider.providerKey}</span>{provider.endpoint && <p className="truncate text-xs text-slate-500">{provider.endpoint}</p>}{provider.resourceId && <p className="text-xs text-cyan-400">Recurso: {provider.resourceId}</p>}</div>
        <span className="text-xs text-slate-500">{provider.hasSecret ? "Credencial guardada" : "Sin credencial"}</span>
        {provider.endpoint && <Button size="sm" variant="outline" disabled={testProvider.isPending} onClick={() => void testConnectivity(provider.id)}>Probar conexión</Button>}
        <Button size="sm" variant="outline" onClick={() => update.mutate({ providerId: provider.id, enabled: provider.enabled === "true" ? "false" : "true" })}>{provider.enabled === "true" ? "Desactivar" : "Activar"}</Button>
        <Button size="sm" variant="destructive" onClick={() => remove.mutate({ providerId: provider.id })}>Eliminar</Button>
      </div>)}
      {!providers.data?.length && <p className="text-sm text-slate-500">No hay proveedores adicionales registrados. Los servicios locales no requieren una cuenta externa.</p>}
    </div>
  </div>;
}
