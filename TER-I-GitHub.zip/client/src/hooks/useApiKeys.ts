/**
 * useApiKeys — Terminator II
 *
 * Gestión de claves API por usuario con tres capas de almacenamiento:
 *
 * 1. localStorage (inmediato, sin login)  — clave: "terminator_api_keys"
 * 2. sessionStorage (sesión actual)       — clave: "terminator_api_keys_session"
 * 3. BD del servidor (persistente, por usuario autenticado)
 *
 * Prioridad de lectura: BD > localStorage > sessionStorage > env (servidor)
 *
 * Las claves nunca se envían en texto plano al cliente desde el servidor;
 * el servidor devuelve solo un mapa de booleanos {xai: true, openai: false, ...}
 * para indicar qué claves están configuradas.
 */

import { useState, useEffect, useCallback } from "react";
import { trpc } from "@/lib/trpc";

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface ApiKeys {
  // LLM cloud
  xaiApiKey?: string;       // Grok xAI
  openaiApiKey?: string;    // OpenAI
  moonshotApiKey?: string;  // Kimi (Moonshot)
  deepseekApiKey?: string;  // DeepSeek
  geminiApiKey?: string;    // Gemini Live
  elevenlabsApiKey?: string; // ElevenLabs Agents
  realtimeCustomApiKey?: string;
  googleTranslateApiKey?: string;
  deeplApiKey?: string;
  // TTS local
  kokoroUrl?: string;       // Kokoro Docker URL
  kokoroApiKey?: string;    // Kokoro Bearer token
  kokoroLocalOnly?: boolean; // Bloquear endpoints remotos
  coquiUrl?: string;        // Coqui XTTS URL (17 idiomas + árabe)
  sileroUrl?: string;       // Silero TTS URL (rápido)
  piperUrl?: string;        // Piper TTS URL
  // LLM local
  ollamaUrl?: string;       // Ollama URL
  lmstudioUrl?: string;     // LM Studio URL
  // Channels
  twilioAccountSid?: string;
  twilioAuthToken?: string;
  twilioApiKeySid?: string;
  twilioApiKeySecret?: string;
  twilioPhoneNumber?: string;
  whatsappToken?: string;
  whatsappPhoneNumberId?: string;
  whatsappVerifyToken?: string;
  whatsappAppSecret?: string;
  telegramBotToken?: string;
  telegramWebhookSecret?: string;
}

export type ApiKeyName = keyof ApiKeys;

/** Mapa de booleanos: qué claves están configuradas (sin exponer valores) */
export type ApiKeysPresence = Record<ApiKeyName, boolean>;

const LS_KEY = "terminator_api_keys";
const SS_KEY = "terminator_api_keys_session";

// ─── Helpers de almacenamiento local ─────────────────────────────────────────

function loadFromStorage(): ApiKeys {
  try {
    const ls = localStorage.getItem(LS_KEY);
    const ss = sessionStorage.getItem(SS_KEY);
    const lsData: ApiKeys = ls ? JSON.parse(ls) : {};
    const ssData: ApiKeys = ss ? JSON.parse(ss) : {};
    // sessionStorage tiene menor prioridad que localStorage
    return { ...ssData, ...lsData };
  } catch {
    return {};
  }
}

function saveToStorage(keys: ApiKeys, session = false): void {
  try {
    const storageKey = session ? SS_KEY : LS_KEY;
    const storage = session ? sessionStorage : localStorage;
    storage.setItem(storageKey, JSON.stringify(keys));
  } catch {
    // storage full or unavailable — silently ignore
  }
}

function clearFromStorage(): void {
  try {
    localStorage.removeItem(LS_KEY);
    sessionStorage.removeItem(SS_KEY);
  } catch {
    // ignore
  }
}

// ─── Hook principal ───────────────────────────────────────────────────────────

export interface UseApiKeysReturn {
  /** Claves actuales (solo las que el usuario ha introducido en este cliente) */
  keys: ApiKeys;
  /** Mapa de presencia: qué claves están guardadas en el servidor */
  presence: ApiKeysPresence | null;
  /** Actualizar una o varias claves (persiste en localStorage + BD si está autenticado) */
  setKeys: (partial: Partial<ApiKeys>, opts?: { sessionOnly?: boolean }) => void;
  /** Guardar todas las claves actuales en la BD del servidor */
  saveToServer: () => Promise<void>;
  /** Borrar todas las claves locales y del servidor */
  clearAll: () => Promise<void>;
  /** Si hay claves sin guardar en el servidor */
  isDirty: boolean;
  isSaving: boolean;
  error: string | null;
}

export function useApiKeys(): UseApiKeysReturn {
  const [keys, setKeysState] = useState<ApiKeys>(() => loadFromStorage());
  const [isDirty, setIsDirty] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const saveConfigMutation = trpc.terminator.saveConfig.useMutation();
  const configQuery = trpc.terminator.getConfig.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  // Presencia de claves en el servidor (solo booleanos, sin valores)
  const presence: ApiKeysPresence | null = configQuery.data
    ? {
        xaiApiKey:            !!configQuery.data.xaiApiKey,
        openaiApiKey:         !!configQuery.data.openaiApiKey,
        moonshotApiKey:       !!configQuery.data.moonshotApiKey,
        deepseekApiKey:       !!configQuery.data.deepseekApiKey,
        geminiApiKey:          !!configQuery.data.geminiApiKey,
        elevenlabsApiKey:      !!configQuery.data.elevenlabsApiKey,
        realtimeCustomApiKey:  !!configQuery.data.realtimeCustomApiKey,
        googleTranslateApiKey: !!configQuery.data.googleTranslateApiKey,
        deeplApiKey:           !!configQuery.data.deeplApiKey,
        kokoroUrl:            !!configQuery.data.kokoroUrl,
        kokoroApiKey:         !!configQuery.data.kokoroApiKey,
        kokoroLocalOnly:      configQuery.data.kokoroLocalOnly === "true",
        coquiUrl:             !!configQuery.data.coquiUrl,
        sileroUrl:            !!configQuery.data.sileroUrl,
        piperUrl:             !!configQuery.data.piperUrl,
        ollamaUrl:            !!configQuery.data.ollamaUrl,
        lmstudioUrl:          !!configQuery.data.lmstudioUrl,
        twilioAccountSid:     !!configQuery.data.twilioAccountSid,
        twilioAuthToken:      !!configQuery.data.twilioAuthToken,
        twilioApiKeySid:      !!configQuery.data.twilioApiKeySid,
        twilioApiKeySecret:   !!configQuery.data.twilioApiKeySecret,
        twilioPhoneNumber:    !!configQuery.data.twilioPhoneNumber,
        whatsappToken:        !!configQuery.data.whatsappToken,
        whatsappPhoneNumberId: !!configQuery.data.whatsappPhoneNumberId,
        whatsappVerifyToken:  !!configQuery.data.whatsappVerifyToken,
        whatsappAppSecret:    !!configQuery.data.whatsappAppSecret,
        telegramBotToken:     !!configQuery.data.telegramBotToken,
        telegramWebhookSecret: !!configQuery.data.telegramWebhookSecret,
      }
    : null;

  // Sync localStorage on mount
  useEffect(() => {
    const stored = loadFromStorage();
    if (Object.keys(stored).length > 0) {
      setKeysState(stored);
    }
  }, []);

  const setKeys = useCallback(
    (partial: Partial<ApiKeys>, opts?: { sessionOnly?: boolean }) => {
      setKeysState((prev) => {
        const next = { ...prev, ...partial };
        // Remove empty strings
        (Object.keys(next) as ApiKeyName[]).forEach((k) => {
          if (next[k] === "") delete next[k];
        });
        saveToStorage(next, opts?.sessionOnly ?? false);
        return next;
      });
      setIsDirty(true);
      setError(null);
    },
    []
  );

  const saveToServer = useCallback(async () => {
    setIsSaving(true);
    setError(null);
    try {
      await saveConfigMutation.mutateAsync({
        xaiApiKey:            keys.xaiApiKey,
        openaiApiKey:         keys.openaiApiKey,
        moonshotApiKey:       keys.moonshotApiKey,
        deepseekApiKey:       keys.deepseekApiKey,
        geminiApiKey:          keys.geminiApiKey,
        elevenlabsApiKey:      keys.elevenlabsApiKey,
        realtimeCustomApiKey:  keys.realtimeCustomApiKey,
        googleTranslateApiKey: keys.googleTranslateApiKey,
        deeplApiKey:           keys.deeplApiKey,
        kokoroUrl:             keys.kokoroUrl,
        kokoroApiKey:          keys.kokoroApiKey,
        kokoroLocalOnly:       keys.kokoroLocalOnly === undefined ? undefined : keys.kokoroLocalOnly ? "true" : "false",
        coquiUrl:              keys.coquiUrl,
        sileroUrl:             keys.sileroUrl,
        piperUrl:              keys.piperUrl,
        ollamaUrl:            keys.ollamaUrl,
        lmstudioUrl:          keys.lmstudioUrl,
        twilioAccountSid:     keys.twilioAccountSid,
        twilioAuthToken:      keys.twilioAuthToken,
        twilioApiKeySid:      keys.twilioApiKeySid,
        twilioApiKeySecret:   keys.twilioApiKeySecret,
        twilioPhoneNumber:    keys.twilioPhoneNumber,
        whatsappToken:        keys.whatsappToken,
        whatsappPhoneNumberId: keys.whatsappPhoneNumberId,
        whatsappVerifyToken:  keys.whatsappVerifyToken,
        telegramBotToken:     keys.telegramBotToken,
      });
      setIsDirty(false);
      // Invalidate presence cache
      await configQuery.refetch();
    } catch (err) {
      setError((err as Error).message ?? "Error al guardar en el servidor");
    } finally {
      setIsSaving(false);
    }
  }, [keys, saveConfigMutation, configQuery]);

  const clearAll = useCallback(async () => {
    clearFromStorage();
    setKeysState({});
    setIsDirty(false);
    setError(null);
    try {
      // Clear server-side too (send empty strings to reset)
      await saveConfigMutation.mutateAsync({});
      await configQuery.refetch();
    } catch {
      // ignore — local clear is done
    }
  }, [saveConfigMutation, configQuery]);

  return { keys, presence, setKeys, saveToServer, clearAll, isDirty, isSaving, error };
}
