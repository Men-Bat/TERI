import { Toaster } from "@/components/ui/sonner";
import React from "react";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Training from "./pages/Training";
import Downloads from "./pages/Downloads";
import Resources from "./pages/Resources";
import TerminatorChat from "./pages/TerminatorChat";
import TerminatorConfig from "./pages/TerminatorConfig";
import TerminatorVideoCall from "./pages/TerminatorVideoCall";
import TerminatorRealtime from "./pages/TerminatorRealtime";

export function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/training"} component={Training} />
      <Route path={"/downloads"} component={Downloads} />
      <Route path={"/resources"} component={Resources} />
      <Route path={"/terminator"} component={TerminatorChat} />
      <Route path={"/terminator/config"} component={TerminatorConfig} />
      <Route path={"/terminator/settings"} component={TerminatorConfig} />
      <Route path={"/terminator/video-call"} component={TerminatorVideoCall} />
      <Route path={"/terminator/realtime"} component={TerminatorRealtime} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
