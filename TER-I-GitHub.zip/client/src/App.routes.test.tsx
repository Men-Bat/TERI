import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";

vi.mock("wouter", () => ({
  Route: ({ path }: { path?: string }) => <span data-route={path ?? "fallback"} />,
  Switch: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

import { Router } from "./App";

describe("rutas de Terminator II", () => {
  it("expone el panel centralizado bajo config y settings", () => {
    const html = renderToStaticMarkup(<Router />);
    expect(html).toContain('data-route="/terminator/config"');
    expect(html).toContain('data-route="/terminator/settings"');
  });
});
