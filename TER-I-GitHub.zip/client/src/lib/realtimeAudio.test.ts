import { describe, expect, it } from "vitest";
import {
  base64ToBytes,
  bytesToBase64,
  float32ToPcm16,
  pcm16ToFloat32,
  realtimeWebSocketUrl,
} from "./realtimeAudio";

describe("realtimeAudio", () => {
  it("convierte PCM Float32 a PCM16 y conserva las muestras dentro de una tolerancia", () => {
    const source = new Float32Array([-1, -0.25, 0, 0.25, 1]);
    const pcm16 = float32ToPcm16(source);
    const restored = pcm16ToFloat32(pcm16);

    expect(pcm16.byteLength).toBe(source.length * 2);
    restored.forEach((value, index) => {
      expect(value).toBeCloseTo(source[index], 2);
    });
  });

  it("codifica y decodifica la carga de audio base64", () => {
    const source = Uint8Array.from([0, 1, 127, 128, 255]);
    expect(Array.from(base64ToBytes(bytesToBase64(source)))).toEqual(Array.from(source));
  });

  it("convierte orígenes http y https al endpoint WebSocket Realtime", () => {
    expect(realtimeWebSocketUrl("http://localhost:3000")).toBe("ws://localhost:3000/ws/realtime");
    expect(realtimeWebSocketUrl("https://terminator.example")).toBe("wss://terminator.example/ws/realtime");
  });
});
