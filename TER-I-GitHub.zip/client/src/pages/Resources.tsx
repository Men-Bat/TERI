import React, { useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, BookOpen, Database, Laptop, Menu, PanelLeftClose, PlayCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

type ResourceSection = "notebooks" | "datasets" | "runtimes";

export const RESOURCE_GROUPS: Record<ResourceSection, { title: string; description: string; entries: Array<{ name: string; detail: string; url: string }> }> = {
  notebooks: {
    title: "Notebooks y entornos",
    description: "Entornos para experimentar, entrenar y reproducir modelos tenIII sin acoplar credenciales al servidor.",
    entries: [
      { name: "Unsloth", detail: "Ajuste fino eficiente de LLMs", url: "https://unsloth.ai/" },
      { name: "Google Colab", detail: "Notebooks gestionados con aceleración opcional", url: "https://colab.research.google.com/" },
      { name: "Jupyter", detail: "Ejecución local y kernels reproducibles", url: "https://jupyter.org/" },
      { name: "Conda", detail: "Aislamiento de entornos de Python", url: "https://docs.conda.io/" },
      { name: "NVIDIA CUDA", detail: "Documentación de aceleración NVIDIA", url: "https://docs.nvidia.com/cuda/" },
      { name: "AMD ROCm", detail: "Stack de cálculo para GPU AMD", url: "https://rocm.docs.amd.com/" },
      { name: "IBM watsonx", detail: "Recursos de IA empresarial y gobernanza", url: "https://www.ibm.com/watsonx" },
    ],
  },
  datasets: {
    title: "Datasets y fuentes",
    description: "Fuentes para preparar datos con licencias, procedencia y consentimiento revisados antes del entrenamiento.",
    entries: [
      { name: "Hugging Face Datasets", detail: "Catálogo versionado de conjuntos de datos", url: "https://huggingface.co/datasets" },
      { name: "Kaggle", detail: "Datasets y cuadernos de la comunidad", url: "https://www.kaggle.com/datasets" },
      { name: "Google Dataset Search", detail: "Índice de conjuntos de datos públicos", url: "https://datasetsearch.research.google.com/" },
      { name: "Zenodo", detail: "Repositorio científico con DOI", url: "https://zenodo.org/" },
      { name: "Archivo local", detail: "Importación privada mediante la página de entrenamiento", url: "/training" },
    ],
  },
  runtimes: {
    title: "Probar modelos",
    description: "Runtimes de inferencia local o web que Terminator II puede usar mediante endpoints configurados por cada usuario.",
    entries: [
      { name: "LM Studio", detail: "Servidor local OpenAI-compatible", url: "https://lmstudio.ai/" },
      { name: "Ollama", detail: "Ejecución local de modelos", url: "https://ollama.com/" },
      { name: "llama.cpp", detail: "Inferencia eficiente con GGUF", url: "https://github.com/ggerganov/llama.cpp" },
      { name: "vLLM", detail: "Servidor de inferencia de alto rendimiento", url: "https://docs.vllm.ai/" },
      { name: "Chat Terminator II", detail: "Prueba los proveedores propios configurados", url: "/terminator" },
    ],
  },
};

const NAVIGATION: Array<{ id: ResourceSection; label: string; icon: typeof Laptop }> = [
  { id: "notebooks", label: "Notebooks", icon: Laptop },
  { id: "datasets", label: "Datasets", icon: Database },
  { id: "runtimes", label: "Probar modelo", icon: PlayCircle },
];

export default function Resources() {
  const [active, setActive] = useState<ResourceSection>("notebooks");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const group = useMemo(() => RESOURCE_GROUPS[active], [active]);

  return <main className="min-h-screen bg-slate-950 px-4 py-5 text-slate-100 sm:px-8">
    <div className="mx-auto max-w-6xl">
      <header className="mb-6 flex items-center justify-between border-b border-slate-800 pb-5">
        <div className="flex items-center gap-3"><Link href="/"><Button variant="ghost" size="icon" aria-label="Volver al inicio"><ArrowLeft className="h-4 w-4" /></Button></Link><div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-400">TenMiNaTor</p><h1 className="text-2xl font-semibold">Recursos de desarrollo</h1></div></div>
        <Button variant="outline" size="sm" onClick={() => setSidebarOpen((value) => !value)} aria-label="Alternar navegación de recursos">{sidebarOpen ? <PanelLeftClose className="mr-2 h-4 w-4" /> : <Menu className="mr-2 h-4 w-4" />}{sidebarOpen ? "Contraer" : "Mostrar"}</Button>
      </header>
      <div className="grid gap-6 md:grid-cols-[14rem_minmax(0,1fr)]">
        <aside className={`${sidebarOpen ? "block" : "hidden md:block md:w-14"} rounded-xl border border-slate-800 bg-slate-900/60 p-3`} aria-label="Categorías de recursos">
          <p className={`${sidebarOpen ? "block" : "hidden"} mb-3 px-2 text-xs font-semibold uppercase tracking-wide text-slate-500`}>Biblioteca</p>
          <nav className="space-y-1">{NAVIGATION.map(({ id, label, icon: Icon }) => <Button key={id} variant="ghost" className={`w-full justify-start ${active === id ? "bg-cyan-950/70 text-cyan-200 hover:bg-cyan-950" : "text-slate-300"}`} onClick={() => setActive(id)} aria-current={active === id ? "page" : undefined}><Icon className="mr-2 h-4 w-4 shrink-0" /><span className={sidebarOpen ? "" : "hidden"}>{label}</span></Button>)}</nav>
        </aside>
        <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 sm:p-7">
          <div className="mb-6"><div className="mb-2 flex items-center gap-2 text-cyan-300"><BookOpen className="h-5 w-5" /><span className="text-sm font-semibold">Catálogo curado</span></div><h2 className="text-2xl font-semibold">{group.title}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">{group.description}</p></div>
          <div className="grid gap-3 sm:grid-cols-2">{group.entries.map((entry) => <a key={entry.name} href={entry.url} target={entry.url.startsWith("http") ? "_blank" : undefined} rel={entry.url.startsWith("http") ? "noreferrer" : undefined} className="group rounded-lg border border-slate-800 bg-slate-950/60 p-4 transition hover:-translate-y-0.5 hover:border-cyan-800 hover:bg-slate-950"><h3 className="font-medium text-slate-100 group-hover:text-cyan-300">{entry.name}</h3><p className="mt-1 text-sm text-slate-400">{entry.detail}</p></a>)}</div>
          <p className="mt-6 rounded-lg border border-amber-900/50 bg-amber-950/20 p-3 text-xs leading-5 text-amber-100">Revisa licencias, condiciones de uso y consentimiento de datos antes de descargar modelos o datasets. Las claves de proveedores se registran individualmente en Terminator II y no se añaden a estas herramientas externas.</p>
        </section>
      </div>
    </div>
  </main>;
}
