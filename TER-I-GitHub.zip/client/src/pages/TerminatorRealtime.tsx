import React, { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, AudioLines, Mic, MicOff, Send, Square, Volume2 } from "lucide-react";
import {
  base64ToBytes,
  float32ToPcm16,
  pcm16ToFloat32,
  bytesToBase64,
  realtimeWebSocketUrl,
} from "@/lib/realtimeAudio";

type RealtimeBackend = "openai-realtime" | "moshi-local" | "gemini-live" | "elevenlabs-agents";
type GatewayEvent = {
  type?: string;
  text?: string;
  error?: string;
  audio?: { data: string; encoding?: string; sampleRate?: number };
  backend?: string;
  status?: string;
};

export const REALTIME_BACKENDS: Array<{ value: RealtimeBackend; label: string; description: string }> = [
  { value: "openai-realtime", label: "OpenAI Realtime", description: "Voz bidireccional mediante credencial OpenAI" },
  { value: "moshi-local", label: "Moshi local", description: "Gateway open source local configurado por endpoint" },
  { value: "gemini-live", label: "Gemini Live", description: "Conversación de baja latencia mediante Gemini" },
  { value: "elevenlabs-agents", label: "ElevenLabs Agents", description: "Agente de voz cloud opcional" },
];

function appendTranscript(current: string[], text?: string): string[] {
  if (!text?.trim()) return current;
  const last = current.at(-1);
  if (last === text) return current;
  return [...current.slice(-79), text];
}

export default function TerminatorRealtime() {
  const { user } = useAuth();
  const createSession = trpc.terminator.createRealtimeSession.useMutation();
  const configQuery = trpc.terminator.getConfig.useQuery(undefined, { retry: false, refetchOnWindowFocus: false });
  const providersQuery = trpc.terminator.listUserProviders.useQuery(undefined, { enabled: !!user, retry: false, refetchOnWindowFocus: false });
  const [backend, setBackend] = useState<RealtimeBackend>("openai-realtime");
  const [userRealtimeProviderId, setUserRealtimeProviderId] = useState<number | undefined>();
  const [language, setLanguage] = useState("es");
  const [status, setStatus] = useState<"idle" | "connecting" | "ready" | "recording" | "error">("idle");
  const [error, setError] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<string[]>([]);
  const [textInput, setTextInput] = useState("");
  const socketRef = useRef<WebSocket | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const contextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sinkRef = useRef<GainNode | null>(null);

  useEffect(() => {
    const config = configQuery.data;
    if (!config) return;
    if (REALTIME_BACKENDS.some((item) => item.value === config.realtimeBackend)) {
      setBackend(config.realtimeBackend as RealtimeBackend);
    }
    if (config.defaultLanguage) setLanguage(config.defaultLanguage);
  }, [configQuery.data]);

  const teardownAudio = useCallback(() => {
    processorRef.current?.disconnect();
    sinkRef.current?.disconnect();
    contextRef.current?.close().catch(() => undefined);
    streamRef.current?.getTracks().forEach((track) => track.stop());
    processorRef.current = null;
    sinkRef.current = null;
    contextRef.current = null;
    streamRef.current = null;
  }, []);

  const playPcm16 = useCallback((base64: string, sampleRate = 24_000) => {
    const context = contextRef.current ?? new AudioContext();
    contextRef.current = context;
    const samples = pcm16ToFloat32(base64ToBytes(base64));
    const buffer = context.createBuffer(1, samples.length, sampleRate);
    const normalizedSamples = new Float32Array(samples.length);
    normalizedSamples.set(samples);
    buffer.copyToChannel(normalizedSamples, 0);
    const source = context.createBufferSource();
    source.buffer = buffer;
    source.connect(context.destination);
    source.start();
  }, []);

  const startMicrophone = useCallback(async () => {
    const socket = socketRef.current;
    if (!socket || socket.readyState !== WebSocket.OPEN) throw new Error("El gateway Realtime no está listo");
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true } });
    const context = contextRef.current ?? new AudioContext();
    contextRef.current = context;
    await context.resume();
    const source = context.createMediaStreamSource(stream);
    const processor = context.createScriptProcessor(4096, 1, 1);
    const mutedSink = context.createGain();
    mutedSink.gain.value = 0;
    processor.onaudioprocess = (event) => {
      if (socket.readyState !== WebSocket.OPEN) return;
      const pcm16 = float32ToPcm16(event.inputBuffer.getChannelData(0));
      socket.send(JSON.stringify({
        type: "audio",
        data: bytesToBase64(pcm16),
        encoding: "pcm16",
        sampleRate: context.sampleRate,
        final: false,
      }));
    };
    source.connect(processor);
    processor.connect(mutedSink);
    mutedSink.connect(context.destination);
    streamRef.current = stream;
    processorRef.current = processor;
    sinkRef.current = mutedSink;
    setStatus("recording");
  }, []);

  const disconnect = useCallback(() => {
    teardownAudio();
    const socket = socketRef.current;
    if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ type: "interrupt" }));
    socket?.close();
    socketRef.current = null;
    setStatus("idle");
  }, [teardownAudio]);

  const stopMicrophone = useCallback(() => {
    teardownAudio();
    setStatus("ready");
  }, [teardownAudio]);

  const connect = useCallback(async () => {
    if (!user) {
      window.location.href = getLoginUrl();
      return;
    }
    setError(null);
    setStatus("connecting");
    try {
      const session = await createSession.mutateAsync({ backend, language, userRealtimeProviderId });
      const socket = new WebSocket(realtimeWebSocketUrl(window.location.origin));
      socketRef.current = socket;
      socket.onopen = () => socket.send(JSON.stringify({ type: "start", ticket: session.ticket, backend }));
      socket.onmessage = (event) => {
        const payload = JSON.parse(event.data) as GatewayEvent;
        if (payload.type === "ready") {
          setStatus("ready");
          setTranscript((current) => appendTranscript(current, `Conectado a ${payload.backend ?? backend}`));
        } else if (payload.type === "error") {
          setError(payload.error ?? "Error en el gateway Realtime");
          setStatus("error");
        } else {
          setTranscript((current) => appendTranscript(current, payload.text));
          if (payload.audio?.data && payload.audio.encoding === "pcm16") {
            playPcm16(payload.audio.data, payload.audio.sampleRate);
          }
        }
      };
      socket.onerror = () => {
        setError("No se pudo establecer la conexión WebSocket Realtime");
        setStatus("error");
      };
      socket.onclose = () => {
        teardownAudio();
        setStatus((current) => current === "error" ? current : "idle");
      };
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "No se pudo crear la sesión Realtime");
      setStatus("error");
    }
  }, [backend, createSession, language, playPcm16, teardownAudio, user, userRealtimeProviderId]);

  const sendText = useCallback(() => {
    const text = textInput.trim();
    if (!text || socketRef.current?.readyState !== WebSocket.OPEN) return;
    socketRef.current.send(JSON.stringify({ type: "text", text }));
    setTranscript((current) => appendTranscript(current, `Tú: ${text}`));
    setTextInput("");
  }, [textInput]);

  useEffect(() => () => disconnect(), [disconnect]);

  const isConnected = status === "ready" || status === "recording";
  const isRecording = status === "recording";
  const activeBackend = REALTIME_BACKENDS.find((item) => item.value === backend);
  const realtimeProviders = (providersQuery.data ?? []).filter((provider) => provider.category === "realtime" && provider.enabled === "true" && REALTIME_BACKENDS.some((item) => item.value === provider.providerKey));

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 p-4 sm:p-8">
      <div className="mx-auto max-w-5xl space-y-5">
        <header className="flex items-start justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex gap-3">
            <Link href="/terminator"><Button variant="ghost" size="icon" aria-label="Volver al chat"><ArrowLeft className="h-4 w-4" /></Button></Link>
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-400">Terminator II</p>
              <h1 className="text-2xl font-semibold">Conversación Realtime</h1>
              <p className="mt-1 text-sm text-slate-400">Audio PCM16 por un gateway seguro con ticket efímero de un solo uso.</p>
            </div>
          </div>
          <Badge variant="outline" className={isConnected ? "border-emerald-700 text-emerald-400" : "border-slate-700 text-slate-400"}>{status}</Badge>
        </header>

        {!user && <Card className="border-amber-700/60 bg-amber-950/20"><CardContent className="pt-6 text-sm text-amber-200">Inicia sesión para generar un ticket Realtime seguro. Las credenciales nunca se exponen al navegador.</CardContent></Card>}
        {error && <Card className="border-red-800 bg-red-950/25"><CardContent className="pt-6 text-sm text-red-200">{error}</CardContent></Card>}

        <section className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
          <Card className="border-slate-800 bg-slate-900/60">
            <CardHeader><CardTitle className="flex items-center gap-2 text-base"><AudioLines className="h-4 w-4 text-cyan-400" /> Sesión</CardTitle><CardDescription>{activeBackend?.description}</CardDescription></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5"><label className="text-sm text-slate-300">Backend</label><Select value={backend} disabled={isConnected || status === "connecting"} onValueChange={(value) => setBackend(value as RealtimeBackend)}><SelectTrigger className="border-slate-700 bg-slate-950"><SelectValue /></SelectTrigger><SelectContent className="border-slate-700 bg-slate-950">{REALTIME_BACKENDS.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select></div>
              {realtimeProviders.length > 0 && <div className="space-y-1.5"><label className="text-sm text-slate-300">Cuenta Realtime propia</label><Select value={userRealtimeProviderId?.toString() ?? "default"} disabled={isConnected || status === "connecting"} onValueChange={(value) => { const provider = realtimeProviders.find((item) => item.id === Number(value)); setUserRealtimeProviderId(value === "default" ? undefined : Number(value)); if (provider && REALTIME_BACKENDS.some((item) => item.value === provider.providerKey)) setBackend(provider.providerKey as RealtimeBackend); }}><SelectTrigger className="border-slate-700 bg-slate-950"><SelectValue placeholder="Configuración del servidor" /></SelectTrigger><SelectContent className="border-slate-700 bg-slate-950"><SelectItem value="default">Configuración del servidor</SelectItem>{realtimeProviders.map((provider) => <SelectItem key={provider.id} value={provider.id.toString()}>{provider.name}</SelectItem>)}</SelectContent></Select></div>}
              <div className="space-y-1.5"><label className="text-sm text-slate-300">Idioma</label><Select value={language} disabled={isConnected || status === "connecting"} onValueChange={setLanguage}><SelectTrigger className="border-slate-700 bg-slate-950"><SelectValue /></SelectTrigger><SelectContent className="border-slate-700 bg-slate-950"><SelectItem value="es">Español</SelectItem><SelectItem value="en">English</SelectItem><SelectItem value="ru">Русский</SelectItem><SelectItem value="ar">العربية</SelectItem></SelectContent></Select></div>
              {!isConnected ? <Button className="w-full bg-cyan-600 hover:bg-cyan-700" disabled={status === "connecting" || !user} onClick={connect}>{status === "connecting" ? "Conectando…" : "Crear sesión segura"}</Button> : <Button variant="outline" className="w-full border-red-800 text-red-300 hover:bg-red-950/40" onClick={disconnect}><Square className="mr-2 h-4 w-4" /> Terminar sesión</Button>}
              {isConnected && <Button className={isRecording ? "w-full bg-red-600 hover:bg-red-700" : "w-full bg-orange-600 hover:bg-orange-700"} onClick={isRecording ? stopMicrophone : startMicrophone}>{isRecording ? <><MicOff className="mr-2 h-4 w-4" /> Detener micrófono</> : <><Mic className="mr-2 h-4 w-4" /> Activar micrófono</>}</Button>}
            </CardContent>
          </Card>

          <Card className="border-slate-800 bg-slate-900/60">
            <CardHeader><CardTitle className="flex items-center gap-2 text-base"><Volume2 className="h-4 w-4 text-orange-400" /> Transcripción y respuesta</CardTitle><CardDescription>Los eventos de texto y audio recibidos se muestran durante la sesión.</CardDescription></CardHeader>
            <CardContent className="space-y-4"><div className="h-64 overflow-y-auto rounded-lg border border-slate-800 bg-slate-950 p-3 font-mono text-sm text-slate-300">{transcript.length ? transcript.map((item, index) => <p key={`${index}-${item}`} className="mb-2 last:mb-0">{item}</p>) : <p className="text-slate-600">Esperando una sesión Realtime…</p>}</div><div className="flex gap-2"><input value={textInput} disabled={!isConnected} onChange={(event) => setTextInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") sendText(); }} placeholder="Enviar texto al backend Realtime" className="min-w-0 flex-1 rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /><Button size="icon" disabled={!isConnected || !textInput.trim()} onClick={sendText}><Send className="h-4 w-4" /></Button></div></CardContent>
          </Card>
        </section>
      </div>
    </main>
  );
}
