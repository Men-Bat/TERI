import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { vi } from "vitest";

vi.mock("wouter", () => ({ Link: ({ children }: { children: React.ReactNode }) => <a href="/">{children}</a> }));

import Resources, { RESOURCE_GROUPS } from "./Resources";

describe("página Resources", () => {
  it("presenta las categorías, recursos locales y acceso al chat", () => {
    const html = renderToStaticMarkup(<Resources />);
    expect(html).toContain("Recursos de desarrollo");
    expect(html).toContain("Notebooks");
    expect(html).toContain("Datasets");
    expect(html).toContain("Probar modelo");
    expect(RESOURCE_GROUPS.datasets.entries.map((entry) => entry.name)).toEqual(expect.arrayContaining(["Hugging Face Datasets", "Kaggle", "Google Dataset Search", "Archivo local"]));
    expect(RESOURCE_GROUPS.runtimes.entries.map((entry) => entry.name)).toEqual(expect.arrayContaining(["LM Studio", "Ollama", "llama.cpp", "vLLM", "Chat Terminator II"]));
  });
});
