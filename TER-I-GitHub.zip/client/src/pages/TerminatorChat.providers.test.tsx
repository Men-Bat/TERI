import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const componentPath = fileURLToPath(new URL("./TerminatorChat.tsx", import.meta.url));

describe("TerminatorChat con proveedores propios", () => {
  it("incluye un selector visible que transmite el proveedor LLM habilitado al chat", () => {
    const source = readFileSync(componentPath, "utf8");
    expect(source).toContain("Entorno LLM propio");
    expect(source).toContain("usableLlmProviders");
    expect(source).toContain("userProviderId: userProviderId === \"none\" ? undefined : Number(userProviderId)");
    expect(source).toContain("Solo se muestran proveedores LLM propios y habilitados");
    expect(source).toContain("Voz o entorno propio");
    expect(source).toContain("userTtsProviderId: userTtsProviderId === \"none\" ? undefined : Number(userTtsProviderId)");
    expect(source).toContain("Gateway de vídeo propio");
    expect(source).toContain("userVideoProviderId: userVideoProviderId === \"none\" ? undefined : Number(userVideoProviderId)");
  });
});
