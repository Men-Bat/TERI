import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";

vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: null }) }));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    terminator: {
      createRealtimeSession: { useMutation: () => ({ mutateAsync: vi.fn() }) },
      getConfig: { useQuery: () => ({ data: null }) },
      listUserProviders: { useQuery: () => ({ data: [] }) },
    },
  },
}));
vi.mock("wouter", () => ({
  Link: ({ children }: { children: React.ReactNode }) => <a href="/terminator">{children}</a>,
}));

import TerminatorRealtime, { REALTIME_BACKENDS } from "./TerminatorRealtime";

describe("página TerminatorRealtime", () => {
  it("renderiza el estado de sesión, los cuatro backends y el aviso de ticket seguro", () => {
    const html = renderToStaticMarkup(<TerminatorRealtime />);

    expect(html).toContain("Conversación Realtime");
    expect(REALTIME_BACKENDS.map((backend) => backend.value)).toEqual([
      "openai-realtime",
      "moshi-local",
      "gemini-live",
      "elevenlabs-agents",
    ]);
    expect(html).toContain("Voz bidireccional mediante credencial OpenAI");
    expect(html).toContain("Inicia sesión para generar un ticket Realtime seguro");
  });
});
