/**
 * Terminator II — Página de Configuración
 *
 * Gestión de APIs, canales y preferencias del sistema Terminator II.
 * Las claves API se almacenan en localStorage del navegador (sin login)
 * y opcionalmente en la BD del servidor (con login).
 */

import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ApiKeyManager } from "@/components/ApiKeyManager";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useApiKeys } from "@/hooks/useApiKeys";
import { CustomModelManager } from "@/components/CustomModelManager";
import { UserProviderManager } from "@/components/UserProviderManager";
import {
  ArrowLeft,
  Bot,
  Settings,
  Webhook,
  Sliders,
  CheckCircle2,
  XCircle,
  Loader2,
  Copy,
  ExternalLink,
  RefreshCw,
} from "lucide-react";
import { getLoginUrl } from "@/const";

// ─── Webhook URL helper ───────────────────────────────────────────────────────

function WebhookUrl({ path, label }: { path: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const url = `${window.location.origin}${path}`;

  const copy = () => {
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="space-y-1">
      <label className="text-xs font-medium text-slate-400">{label}</label>
      <div className="flex items-center gap-2 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2">
        <code className="text-xs text-green-400 flex-1 truncate">{url}</code>
        <button
          onClick={copy}
          className="text-slate-500 hover:text-slate-300 flex-shrink-0"
          title="Copiar URL"
        >
          {copied ? (
            <CheckCircle2 className="w-4 h-4 text-green-400" />
          ) : (
            <Copy className="w-4 h-4" />
          )}
        </button>
      </div>
    </div>
  );
}

// ─── Tab: Preferencias ────────────────────────────────────────────────────────

function PreferencesTab() {
  const { user } = useAuth();
  const loginUrl = getLoginUrl();
  const [prefs, setPrefs] = useState({
    defaultPersona: "default",
    defaultLanguage: "es",
    defaultLlm: "auto",
    defaultTts: "auto",
    defaultStt: "auto",
    defaultVideo: "none",
    defaultAvatar: "none",
    localVideoEndpoint: "",
    localVideoWorkflow: "",
    kokoroVolumeMultiplier: 1.0,
    kokoroUseStreaming: false,
    kokoroLocalOnly: "false" as "true" | "false",
    realtimeBackend: "openai-realtime",
    realtimeEndpoint: "",
    realtimeModel: "gpt-realtime-2.1",
    realtimeAllowFallback: "false",
    translatorBackend: "none",
    translatorEndpoint: "",
    translatorAllowFallback: "false",
  });
  const configQuery = trpc.terminator.getConfig.useQuery(undefined, { retry: false, refetchOnWindowFocus: false });
  const saveConfigMutation = trpc.terminator.saveConfig.useMutation();
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const config = configQuery.data;
    if (!config) return;
    setPrefs((current) => ({
      ...current,
      defaultPersona: config.defaultPersona ?? current.defaultPersona,
      defaultLanguage: config.defaultLanguage ?? current.defaultLanguage,
      defaultLlm: config.defaultLlm ?? current.defaultLlm,
      defaultTts: config.defaultTts ?? current.defaultTts,
      defaultStt: config.defaultStt ?? current.defaultStt,
      defaultVideo: config.defaultVideo ?? current.defaultVideo,
      defaultAvatar: config.defaultAvatar ?? current.defaultAvatar,
      localVideoEndpoint: config.localVideoEndpoint ?? current.localVideoEndpoint,
      localVideoWorkflow: config.localVideoWorkflow ?? current.localVideoWorkflow,
      kokoroLocalOnly: config.kokoroLocalOnly === "true" ? "true" : "false",
      realtimeBackend: config.realtimeBackend ?? current.realtimeBackend,
      realtimeEndpoint: config.realtimeEndpoint ?? current.realtimeEndpoint,
      realtimeModel: config.realtimeModel ?? current.realtimeModel,
      realtimeAllowFallback: config.realtimeAllowFallback ?? current.realtimeAllowFallback,
      translatorBackend: config.translatorBackend ?? current.translatorBackend,
      translatorEndpoint: config.translatorEndpoint ?? current.translatorEndpoint,
      translatorAllowFallback: config.translatorAllowFallback ?? current.translatorAllowFallback,
    }));
  }, [configQuery.data]);

  const handleSave = async () => {
    await saveConfigMutation.mutateAsync(prefs);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-4">
      <Card className="bg-slate-900/60 border-slate-700">
        <CardHeader>
          <CardTitle className="text-sm text-slate-200 flex items-center gap-2">
            <Bot className="w-4 h-4 text-orange-400" />
            Preferencias del sistema
          </CardTitle>
          <CardDescription className="text-xs text-slate-500">
            Configura el comportamiento por defecto del Terminator II
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">Persona por defecto</label>
              <Select value={prefs.defaultPersona} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultPersona: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="default">🤖 Terminator (neutro)</SelectItem>
                  <SelectItem value="ani">🌸 Ani (cálida, empática)</SelectItem>
                  <SelectItem value="valentin">💼 Valentín (profesional)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">Idioma por defecto</label>
              <Select value={prefs.defaultLanguage} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultLanguage: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="ar">🇸🇦 العربية (Árabe)</SelectItem>
                  <SelectItem value="es">🇪🇸 Español</SelectItem>
                  <SelectItem value="en">🇺🇸 English</SelectItem>
                  <SelectItem value="de">🇩🇪 Deutsch</SelectItem>
                  <SelectItem value="fr">🇫🇷 Français</SelectItem>
                  <SelectItem value="it">🇮🇹 Italiano</SelectItem>
                  <SelectItem value="pt">🇧🇷 Português</SelectItem>
                  <SelectItem value="ru">🇷🇺 Русский (Ruso)</SelectItem>
                  <SelectItem value="ja">🇯🇵 日本語</SelectItem>
                  <SelectItem value="ko">🇰🇷 한국어</SelectItem>
                  <SelectItem value="zh">🇨🇳 中文</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">LLM preferido</label>
              <Select value={prefs.defaultLlm} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultLlm: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="auto">🔄 Automático (mejor disponible)</SelectItem>
                  <SelectItem value="ollama">🖥️ Ollama (local)</SelectItem>
                  <SelectItem value="lmstudio">🖥️ LM Studio (local)</SelectItem>
                  <SelectItem value="grok">☁️ Grok xAI</SelectItem>
                  <SelectItem value="openai">☁️ OpenAI GPT-4o</SelectItem>
                  <SelectItem value="kimi">☁️ Kimi (Moonshot)</SelectItem>
                  <SelectItem value="deepseek">☁️ DeepSeek</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">TTS preferido</label>
              <Select value={prefs.defaultTts} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultTts: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="auto">🔄 Automático (mejor disponible)</SelectItem>
                  <SelectItem value="kokoro">🎙️ Kokoro (local, 11 idiomas)</SelectItem>
                  <SelectItem value="coqui">🎙️ Coqui XTTS (local, 17 idiomas + árabe)</SelectItem>
                  <SelectItem value="silero">🎙️ Silero TTS (local, rápido)</SelectItem>
                  <SelectItem value="piper">🎙️ Piper (local, 30+ idiomas)</SelectItem>
                  <SelectItem value="grok">☁️ Grok Aurora</SelectItem>
                  <SelectItem value="openai">☁️ OpenAI TTS</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">Generación de video</label>
              <Select value={prefs.defaultVideo} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultVideo: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="none">❌ Desactivado</SelectItem>
                  <SelectItem value="grok">☁️ Grok Video (xAI)</SelectItem>
                  <SelectItem value="wan2">🖥️ Wan2.1 (local, 8GB VRAM)</SelectItem>
                  <SelectItem value="ltx">🖥️ LTX-Video (local, 4GB VRAM)</SelectItem>
                  <SelectItem value="custom">⚙️ Gateway local personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">STT preferido</label>
              <Select value={prefs.defaultStt} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultStt: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700"><SelectItem value="auto">🔄 Automático</SelectItem><SelectItem value="grok">☁️ Grok STT</SelectItem><SelectItem value="openai">☁️ OpenAI Whisper</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">Avatar/modelo visual</label>
              <Select value={prefs.defaultAvatar} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultAvatar: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700"><SelectItem value="none">❌ Sin avatar</SelectItem><SelectItem value="custom">⚙️ Runtime avatar registrado</SelectItem></SelectContent>
              </Select>
            </div>
          </div>

          {(prefs.defaultVideo === "wan2" || prefs.defaultVideo === "ltx" || prefs.defaultVideo === "custom") && (
            <div className="mt-5 space-y-4 rounded-lg border border-cyan-900/60 bg-cyan-950/20 p-4">
              <div>
                <h3 className="text-sm font-semibold text-cyan-100">Gateway de vídeo local</h3>
                <p className="mt-1 text-xs text-slate-400">El gateway debe exponer <code className="text-cyan-300">POST /generate</code>. Mantén este endpoint en una red de confianza.</p>
              </div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-sm text-slate-300">Endpoint local</label>
                  <input
                    type="url"
                    maxLength={500}
                    value={prefs.localVideoEndpoint}
                    onChange={(event) => setPrefs((p) => ({ ...p, localVideoEndpoint: event.target.value }))}
                    className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-200"
                    placeholder="http://127.0.0.1:8188"
                  />
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-sm text-slate-300">Workflow / identificador del modelo</label>
                  <input
                    maxLength={160}
                    value={prefs.localVideoWorkflow}
                    onChange={(event) => setPrefs((p) => ({ ...p, localVideoWorkflow: event.target.value }))}
                    className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-200"
                    placeholder="wan2-t2v, ltx-t2v o workflow de ComfyUI"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Realtime y traducción */}
          <div className="mt-6 pt-6 border-t border-slate-700 space-y-4">
            <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
              <Settings className="w-4 h-4 text-cyan-400" />
              Conversación Realtime y traducción opcional
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-sm text-slate-300">Backend Realtime</label>
                <Select value={prefs.realtimeBackend} onValueChange={(v) => setPrefs((p) => ({ ...p, realtimeBackend: v }))}>
                  <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-700">
                    <SelectItem value="openai-realtime">OpenAI Realtime</SelectItem>
                    <SelectItem value="moshi-local">Moshi local (open source)</SelectItem>
                    <SelectItem value="gemini-live">Gemini Live</SelectItem>
                    <SelectItem value="elevenlabs-agents">ElevenLabs Agents</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm text-slate-300">Modelo Realtime</label>
                <input
                  value={prefs.realtimeModel}
                  onChange={(event) => setPrefs((p) => ({ ...p, realtimeModel: event.target.value }))}
                  className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-200"
                  placeholder="gpt-realtime-2.1 / gemini-3.1-flash-live-preview"
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-sm text-slate-300">Endpoint Realtime personalizado (opcional)</label>
                <input
                  value={prefs.realtimeEndpoint}
                  onChange={(event) => setPrefs((p) => ({ ...p, realtimeEndpoint: event.target.value }))}
                  className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-200"
                  placeholder="ws://localhost:8998/ws o signed URL del proveedor"
                />
              </div>
              <div className="flex items-center justify-between sm:col-span-2">
                <div className="space-y-1">
                  <label className="text-sm text-slate-300">Permitir fallback Realtime</label>
                  <p className="text-xs text-slate-500">Desactivado por defecto para no enviar audio local a la nube sin consentimiento.</p>
                </div>
                <Switch checked={prefs.realtimeAllowFallback === "true"} onCheckedChange={(checked) => setPrefs((p) => ({ ...p, realtimeAllowFallback: checked ? "true" : "false" }))} />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm text-slate-300">Traductor</label>
                <Select value={prefs.translatorBackend} onValueChange={(v) => setPrefs((p) => ({ ...p, translatorBackend: v }))}>
                  <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-700">
                    <SelectItem value="none">Desactivado</SelectItem>
                    <SelectItem value="local-translator">Local / Alia / NLLB / Marian</SelectItem>
                    <SelectItem value="google-translate">Google Translate</SelectItem>
                    <SelectItem value="deepl">DeepL</SelectItem>
                    <SelectItem value="custom-translator">Endpoint personalizado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm text-slate-300">Endpoint de traducción (opcional)</label>
                <input
                  value={prefs.translatorEndpoint}
                  onChange={(event) => setPrefs((p) => ({ ...p, translatorEndpoint: event.target.value }))}
                  className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-200"
                  placeholder="http://localhost:8000/translate"
                />
              </div>
              <div className="flex items-center justify-between sm:col-span-2">
                <div className="space-y-1">
                  <label className="text-sm text-slate-300">Permitir fallback de traducción</label>
                  <p className="text-xs text-slate-500">Se conserva la selección local salvo que el usuario lo active.</p>
                </div>
                <Switch checked={prefs.translatorAllowFallback === "true"} onCheckedChange={(checked) => setPrefs((p) => ({ ...p, translatorAllowFallback: checked ? "true" : "false" }))} />
              </div>
            </div>
          </div>

          {/* Kokoro TTS Advanced Settings */}
          <div className="mt-6 pt-6 border-t border-slate-700 space-y-4">
            <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-purple-400" />
              Configuración avanzada de Kokoro TTS
            </h3>

            <div className="space-y-2">
              <label className="text-sm text-slate-300">
                Volumen: {prefs.kokoroVolumeMultiplier.toFixed(1)}x
              </label>
              <Slider
                value={[prefs.kokoroVolumeMultiplier]}
                onValueChange={(v) => setPrefs((p) => ({ ...p, kokoroVolumeMultiplier: v[0] }))}
                min={0.1}
                max={2.0}
                step={0.1}
                className="w-full"
              />
              <p className="text-xs text-slate-500">Rango: 0.1 (muy bajo) a 2.0 (muy alto)</p>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <label className="text-sm text-slate-300">Streaming SSE (Kokoro)</label>
                <p className="text-xs text-slate-500">Recibir audio mientras se sintetiza (más rápido)</p>
              </div>
              <Switch
                checked={prefs.kokoroUseStreaming}
                onCheckedChange={(v) => setPrefs((p) => ({ ...p, kokoroUseStreaming: v }))}
              />
            </div>

            <div className="flex items-center justify-between border-t border-slate-700 pt-4">
              <div className="space-y-1">
                <label className="text-sm text-slate-300">Modo Kokoro solo local</label>
                <p className="text-xs text-slate-500">Impide síntesis, comprobaciones y metadata para una URL que no sea localhost o un dominio .local.</p>
              </div>
              <Switch
                checked={prefs.kokoroLocalOnly === "true"}
                onCheckedChange={(checked) => setPrefs((p) => ({ ...p, kokoroLocalOnly: checked ? "true" : "false" }))}
              />
            </div>
          </div>

          {user && (
            <Button
              onClick={handleSave}
              disabled={saveConfigMutation.isPending}
              className="bg-orange-600 hover:bg-orange-700 w-full sm:w-auto"
            >
              {saveConfigMutation.isPending ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Guardando...</>
              ) : saved ? (
                <><CheckCircle2 className="w-4 h-4 mr-2" /> Guardado</>
              ) : (
                <><Settings className="w-4 h-4 mr-2" /> Guardar preferencias</>
              )}
            </Button>
          )}
          {!user && (
            <p className="text-xs text-slate-500">Inicia sesión para guardar las preferencias en tu cuenta.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function CacheTab() {
  const [bytes, setBytes] = useState(0);
  const refresh = () => setBytes(Object.entries(localStorage).reduce((total, [key, value]) => total + key.length + value.length, 0));
  useEffect(() => { refresh(); }, []);
  const clear = () => { Object.keys(localStorage).filter((key) => key.startsWith("terminator_") || key.startsWith("apiKeys")).forEach((key) => localStorage.removeItem(key)); refresh(); };
  return <Card className="bg-slate-900/60 border-slate-700"><CardHeader><CardTitle className="text-sm text-slate-200">Caché local</CardTitle><CardDescription className="text-xs text-slate-500">Datos de configuración almacenados exclusivamente en este navegador.</CardDescription></CardHeader><CardContent className="flex items-center justify-between gap-3"><span className="text-sm text-slate-300">Uso estimado: {(bytes / 1024).toFixed(1)} KB</span><Button variant="outline" onClick={clear}>Limpiar caché Terminator</Button></CardContent></Card>;
}

// ─── Tab: Webhooks ────────────────────────────────────────────────────────────

function WebhooksTab() {
  return (
    <div className="space-y-4">
      <Card className="bg-slate-900/60 border-slate-700">
        <CardHeader>
          <CardTitle className="text-sm text-slate-200 flex items-center gap-2">
            <Webhook className="w-4 h-4 text-blue-400" />
            URLs de webhooks
          </CardTitle>
          <CardDescription className="text-xs text-slate-500">
            Configura estas URLs en cada plataforma para recibir mensajes en el Terminator II
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">WhatsApp Business</h3>
            <WebhookUrl path="/api/webhooks/whatsapp" label="Webhook URL (Meta Developers → Webhooks)" />
            <p className="text-xs text-slate-500">
              En Meta Developers → tu app → WhatsApp → Configuración → Webhook:
              pega la URL de arriba y el mismo Verify Token que configuraste en las claves API.
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Telegram</h3>
            <WebhookUrl path="/api/webhooks/telegram" label="Webhook URL (setWebhook)" />
            <p className="text-xs text-slate-500">
              Ejecuta en tu navegador (sustituyendo TOKEN):
            </p>
            <code className="block mt-1 bg-slate-950 rounded p-2 text-green-400 text-xs break-all">
              {`https://api.telegram.org/bot<TOKEN>/setWebhook?url=${window.location.origin}/api/webhooks/telegram`}
            </code>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Twilio SMS / MMS</h3>
            <WebhookUrl path="/api/webhooks/sms" label="Webhook URL (Twilio Console → Phone Numbers)" />
            <p className="text-xs text-slate-500">
              En Twilio Console → Phone Numbers → tu número → Messaging → Webhook:
              pega la URL y selecciona método HTTP POST.
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Twilio Voice (ConversationRelay)</h3>
            <WebhookUrl path="/api/webhooks/voice" label="Webhook URL (Twilio Console → Voice)" />
            <p className="text-xs text-slate-500">
              En Twilio Console → Phone Numbers → tu número → Voice → Webhook:
              pega la URL. El sistema responderá con TwiML que conecta al WebSocket del Terminator.
            </p>
          </div>

          <div className="p-3 bg-blue-900/20 border border-blue-800 rounded-lg text-xs text-blue-300 flex items-start gap-2">
            <ExternalLink className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>
              <strong>Nota:</strong> Para que los webhooks funcionen, esta app debe estar publicada.
              Usa el botón <strong>Publish</strong> del panel de gestión.
              En desarrollo local, usa <a href="https://ngrok.com" target="_blank" rel="noreferrer" className="underline">ngrok</a> para exponer el puerto 3000.
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Componente principal ─────────────────────────────────────────────────────

export default function TerminatorConfig() {
  const { user } = useAuth();
  const loginUrl = getLoginUrl();
  const { keys } = useApiKeys();

  const backendsQuery = trpc.terminator.checkBackends.useQuery(
    {
      ollamaUrl: keys.ollamaUrl ?? "http://localhost:11434",
      lmstudioUrl: keys.lmstudioUrl ?? "http://localhost:1234",
      kokoroUrl: keys.kokoroUrl ?? "http://localhost:8880",
    },
    { retry: false, refetchInterval: 30_000 }
  );
  const backends = backendsQuery.data;

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-900/80 backdrop-blur px-4 py-3 flex items-center gap-3">
        <Link href="/terminator">
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Volver al chat
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5 text-orange-400" />
          <span className="font-semibold">Terminator II — Configuración</span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => backendsQuery.refetch()}
          className="ml-auto text-slate-400 hover:text-white"
        >
          <RefreshCw className="w-3.5 h-3.5 mr-1" />
          Verificar
        </Button>
        {!user && (
          <a href={loginUrl}>
            <Button size="sm" className="bg-orange-600 hover:bg-orange-700 text-xs">
              Iniciar sesión
            </Button>
          </a>
        )}
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
        {/* Backend status */}
        <Card className="bg-slate-900/60 border-slate-700">
          <CardHeader className="py-3">
            <CardTitle className="text-sm text-slate-200">Estado de backends</CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {backendsQuery.isLoading ? (
              <div className="flex items-center gap-2 text-slate-400 text-sm">
                <Loader2 className="w-4 h-4 animate-spin" />
                Verificando backends...
              </div>
            ) : (
              <div className="flex flex-wrap gap-2">
                {[
                  { key: "ollama", label: "Ollama" },
                  { key: "lmstudio", label: "LM Studio" },
                  { key: "kokoro", label: "Kokoro TTS" },
                  { key: "grok", label: "Grok xAI" },
                  { key: "openai", label: "OpenAI" },
                  { key: "kimi", label: "Kimi" },
                  { key: "deepseek", label: "DeepSeek" },
                ].map(({ key, label }) => {
                  const active = backends?.[key as keyof typeof backends];
                  return (
                    <Badge
                      key={key}
                      className={`flex items-center gap-1 text-xs ${
                        active
                          ? "bg-green-900/50 text-green-400 border-green-700"
                          : "bg-slate-800 text-slate-500 border-slate-700"
                      }`}
                    >
                      {active ? (
                        <CheckCircle2 className="w-3 h-3" />
                      ) : (
                        <XCircle className="w-3 h-3" />
                      )}
                      {label}
                    </Badge>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Main tabs */}
        <Tabs defaultValue="apis">
          <TabsList className="bg-slate-900 border border-slate-700 w-full">
            <TabsTrigger
              value="apis"
              className="flex-1 data-[state=active]:bg-orange-600 data-[state=active]:text-white text-slate-400"
            >
              🔑 Claves API
            </TabsTrigger>
            <TabsTrigger
              value="prefs"
              className="flex-1 data-[state=active]:bg-orange-600 data-[state=active]:text-white text-slate-400"
            >
              <Sliders className="w-3.5 h-3.5 mr-1.5" />
              Preferencias
            </TabsTrigger>
            <TabsTrigger
              value="models"
              className="flex-1 data-[state=active]:bg-orange-600 data-[state=active]:text-white text-slate-400"
            >Modelos tenIII</TabsTrigger>
            <TabsTrigger value="providers" className="flex-1 data-[state=active]:bg-orange-600 data-[state=active]:text-white text-slate-400">Proveedores</TabsTrigger>
            <TabsTrigger value="cache" className="flex-1 data-[state=active]:bg-orange-600 data-[state=active]:text-white text-slate-400">Caché local</TabsTrigger>
            <TabsTrigger
              value="webhooks"
              className="flex-1 data-[state=active]:bg-orange-600 data-[state=active]:text-white text-slate-400"
            >
              <Webhook className="w-3.5 h-3.5 mr-1.5" />
              Webhooks
            </TabsTrigger>
          </TabsList>

          <TabsContent value="apis" className="mt-4">
            {!user && (
              <div className="mb-4 p-3 bg-yellow-900/20 border border-yellow-800 rounded-lg text-xs text-yellow-300 flex items-center gap-2">
                <ExternalLink className="w-4 h-4 flex-shrink-0" />
                Sin iniciar sesión, las claves se guardan solo en este navegador.{" "}
                <a href={loginUrl} className="underline font-medium">
                  Inicia sesión
                </a>{" "}
                para sincronizarlas con tu cuenta.
              </div>
            )}
            <ApiKeyManager onSaved={() => backendsQuery.refetch()} />
          </TabsContent>

          <TabsContent value="prefs" className="mt-4">
            <PreferencesTab />
          </TabsContent>

          <TabsContent value="models" className="mt-4"><CustomModelManager /></TabsContent>
          <TabsContent value="providers" className="mt-4"><UserProviderManager /></TabsContent>
          <TabsContent value="cache" className="mt-4"><CacheTab /></TabsContent>

          <TabsContent value="webhooks" className="mt-4">
            <WebhooksTab />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
